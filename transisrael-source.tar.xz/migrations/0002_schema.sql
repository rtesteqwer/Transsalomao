create table if not exists drivers (
  id text primary key,
  name text not null,
  phone text not null default '',
  category text not null default 'E',
  status text not null default 'ativo',
  commission_pct double precision not null default 0.10
);

create table if not exists fleets (
  id text primary key,
  name text not null,
  tractor_plate text not null,
  trailer_plate text not null,
  model text not null default '',
  status text not null default 'ativo'
);

create table if not exists trips (
  id text primary key,
  code text not null unique,
  date date not null,
  client text not null default '',
  origin text not null default '',
  destination text not null default '',
  driver_id text not null references drivers(id),
  fleet_id text not null references fleets(id),
  loaded_tons double precision not null default 0,
  gross_weight double precision not null default 0,
  net_weight double precision not null default 0,
  price_per_ton double precision not null default 0,
  km_start double precision not null default 0,
  km_end double precision not null default 0,
  diesel_liters double precision not null default 0,
  diesel_price double precision not null default 0
);

create table if not exists reports (
  id text primary key,
  ticket text not null,
  driver_id text not null references drivers(id),
  fleet_id text not null references fleets(id),
  km double precision not null,
  tons double precision not null,
  status text not null default 'pendente',
  created_at timestamptz not null default now(),
  trip_id text references trips(id)
);

create index if not exists trips_date_idx on trips (date desc);
create index if not exists trips_driver_idx on trips (driver_id);
create index if not exists trips_fleet_idx on trips (fleet_id);
create index if not exists reports_status_idx on reports (status, created_at desc);

