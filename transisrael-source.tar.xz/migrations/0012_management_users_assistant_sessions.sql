-- Israel IA v4: usuários de gerenciamento editáveis e sessões de dispositivo revogáveis.
create table if not exists management_users (
  id text primary key,
  username text not null,
  password_hash text not null,
  role text not null default 'admin',
  status text not null default 'ativo',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists management_users_username_lower_uq
  on management_users ((lower(username)));

-- Initial admin credentials are provisioned outside source control.

create table if not exists assistant_sessions (
  token_hash text primary key,
  username text not null,
  device_label text not null default '',
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  last_used_at timestamptz not null default now(),
  revoked_at timestamptz
);
create index if not exists assistant_sessions_expiry_idx on assistant_sessions (expires_at);
create index if not exists assistant_sessions_user_idx on assistant_sessions ((lower(username)));
