-- Lançamentos do motorista: somente motorista e conjunto são obrigatórios.
-- O modo de frete pode ser definido posteriormente pela gerência.
alter table reports alter column freight_mode drop not null;
alter table reports alter column freight_mode drop default;
