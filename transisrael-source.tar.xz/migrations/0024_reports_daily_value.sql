-- Manual reports store the driver's daily freight amount before Caixa review.
alter table reports add column if not exists daily_value double precision not null default 0;
