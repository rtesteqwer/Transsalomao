update trips
set freight_mode = 'ton'
where freight_mode is null or freight_mode not in ('ton', 'trip', 'cegonha', 'caixinha');

update reports
set freight_mode = 'ton'
where freight_mode is null or freight_mode not in ('ton', 'trip', 'cegonha', 'caixinha');

create table if not exists expenses (
  id text primary key,
  date date not null default current_date,
  fleet_id text not null references fleets(id),
  asset_type text not null default 'tractor',
  category text not null default 'Outros',
  description text not null default '',
  amount double precision not null default 0,
  notes text not null default '',
  created_at timestamptz not null default now(),
  constraint expenses_asset_type_check check (asset_type in ('tractor', 'trailer'))
);

create index if not exists expenses_date_idx on expenses (date desc);
create index if not exists expenses_fleet_idx on expenses (fleet_id);
create index if not exists expenses_asset_idx on expenses (asset_type, date desc);
