-- Security hardening 2026-09-28
alter table management_users add column if not exists must_change_password boolean not null default false;
update management_users set must_change_password=true where password_hash ~ '^[0-9a-fA-F]{64}$';
create table if not exists auth_login_attempts(identity_hash text primary key,window_start timestamptz not null default now(),failures integer not null default 0,blocked_until timestamptz,updated_at timestamptz not null default now());
create table if not exists driver_accounts(username text primary key,driver_id text not null references drivers(id),password_hash text not null,status text not null default 'ativo',must_change_password boolean not null default true,created_at timestamptz not null default now(),updated_at timestamptz not null default now());
create unique index if not exists driver_accounts_username_lower_uq on driver_accounts((lower(username)));
create sequence if not exists transisrael_ticket_seq start 1;
select setval('transisrael_ticket_seq',greatest(coalesce((select max(code::bigint) from trips where code ~ '^[0-9]+$'),0),coalesce((select max(ticket::bigint) from reports where ticket ~ '^[0-9]+$'),0),1),true);
do $$ begin
  if not exists(select 1 from reports where length(ticket)>0 group by ticket having count(*)>1) then execute 'create unique index if not exists reports_ticket_uq on reports(ticket) where length(ticket)>0'; end if;
  if not exists(select 1 from trips where length(code)>0 group by code having count(*)>1) then execute 'create unique index if not exists trips_code_uq on trips(code) where length(code)>0'; end if;
end $$;
