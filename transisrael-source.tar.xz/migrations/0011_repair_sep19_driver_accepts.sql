-- No historical company data in this independent instance.
SELECT 1;
