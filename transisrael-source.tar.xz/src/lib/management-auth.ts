import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const loginSchema = z.object({
  username: z.string().trim().min(1, "Informe o login"),
  password: z.string().min(1, "Informe a senha"),
  remember: z.boolean().optional().default(false),
});

export const getManagementSession = createServerFn({ method: "GET" }).handler(async () => {
  const { managementSession } = await import("@/lib/management-auth.server");
  const session = managementSession();
  return session
    ? { authenticated: true as const, username: session.username, role: "admin" as const }
    : { authenticated: false as const, username: null, role: null };
});

export const managementLogin = createServerFn({ method: "POST" })
  .validator(loginSchema)
  .handler(async ({ data }) => {
    const { loginManagement } = await import("@/lib/management-auth.server");
    return loginManagement(data.username, data.password, data.remember);
  });

const managementLogoutServer = createServerFn({ method: "POST" }).handler(async () => {
  const { logoutManagement } = await import("@/lib/management-auth.server");
  return logoutManagement();
});

export async function managementLogout() {
  const result = await managementLogoutServer();
  if (typeof window !== "undefined") {
    try {
      if ("serviceWorker" in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map((registration) => registration.unregister()));
      }
      if ("caches" in window) {
        const keys = await caches.keys();
        await Promise.all(keys.map((key) => caches.delete(key)));
      }
    } catch {}
    window.location.replace("/");
  }
  return result;
}

const passwordChangeSchema = z.object({
  newPassword: z.string().min(10, "Use pelo menos 10 caracteres"),
});

export const completeRequiredPasswordChange = createServerFn({ method: "POST" })
  .validator(passwordChangeSchema)
  .handler(async ({ data }) => {
    const { completeManagementPasswordChange } = await import("@/lib/management-auth.server");
    const management = await completeManagementPasswordChange(data.newPassword);
    if (management) return management;
    const { completeDriverPasswordChange } = await import("@/lib/klebersom-access.server");
    const driver = await completeDriverPasswordChange(data.newPassword);
    if (driver) return driver;
    throw new Error("A autorização para trocar a senha expirou. Entre novamente.");
  });
