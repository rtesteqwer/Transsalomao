import type {
  ComputedTrip,
  DashboardKpis,
  Driver,
  DriverTotals,
  Fleet,
  FleetTotals,
  FreightMode,
  Fueling,
  PeriodKey,
  Trip,
  TripMetrics,
} from "./types";

export function freightOf(
  trip: Pick<Trip, "freightMode" | "netWeight" | "pricePerTon" | "pricePerTrip">,
) {
  return trip.freightMode === "ton"
    ? trip.netWeight * trip.pricePerTon
    : trip.pricePerTrip;
}

export function freightModeLabel(mode: FreightMode | null | undefined) {
  if (!mode) return "A definir";
  if (mode === "trip") return "Diária";
  if (mode === "cegonha") return "Cegonha";
  if (mode === "caixinha") return "Caixinha";
  return "Por tonelada";
}

export function freightModeBreakdown(trips: ComputedTrip[]) {
  const ton = trips.filter((t) => t.freightMode === "ton");
  const trip = trips.filter((t) => t.freightMode === "trip");
  const cegonha = trips.filter((t) => t.freightMode === "cegonha");
  const caixinha = trips.filter((t) => t.freightMode === "caixinha");
  return {
    tonTripCount: ton.length,
    tonTons: sum(ton, (t) => t.netWeight),
    tonFreight: sum(ton, (t) => t.freight),
    tripModeCount: trip.length,
    tripFreight: sum(trip, (t) => t.freight),
    cegonhaCount: cegonha.length,
    cegonhaFreight: sum(cegonha, (t) => t.freight),
    caixinhaCount: caixinha.length,
    caixinhaFreight: sum(caixinha, (t) => t.freight),
    fixedTripCount: trip.length + cegonha.length + caixinha.length,
    fixedFreight:
      sum(trip, (t) => t.freight) +
      sum(cegonha, (t) => t.freight) +
      sum(caixinha, (t) => t.freight),
  };
}

export type FuelingConsumptionRow = Fueling & {
  kmSincePrevious: number | null;
  kmPerLiter: number | null;
};

/**
 * KM/L is calculated only from fueling records for the same fleet.
 * The distance is the odometer difference between consecutive fuelings and
 * the liters are the liters entered on the ending fueling record.
 */
export function fuelingConsumptionRows(fuelings: Fueling[]): FuelingConsumptionRow[] {
  const byFleet = new Map<string, Fueling[]>();
  for (const fueling of fuelings) {
    const list = byFleet.get(fueling.fleetId) ?? [];
    list.push(fueling);
    byFleet.set(fueling.fleetId, list);
  }

  const out: FuelingConsumptionRow[] = [];
  for (const list of byFleet.values()) {
    const sorted = [...list].sort(
      (a, b) =>
        a.date.localeCompare(b.date) ||
        a.createdAt.localeCompare(b.createdAt) ||
        a.km - b.km,
    );
    let previous: Fueling | null = null;
    for (const current of sorted) {
      const distance = previous && current.km > previous.km ? current.km - previous.km : null;
      out.push({
        ...current,
        kmSincePrevious: distance,
        kmPerLiter: distance != null && current.liters > 0 ? distance / current.liters : null,
      });
      previous = current;
    }
  }

  return out.sort(
    (a, b) =>
      b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt),
  );
}

export function fuelingConsumptionStats(rows: Array<Pick<FuelingConsumptionRow, "kmSincePrevious" | "liters">>) {
  const valid = rows.filter((row) => row.kmSincePrevious != null && row.kmSincePrevious > 0 && row.liters > 0);
  const kmDriven = valid.reduce((acc, row) => acc + (row.kmSincePrevious ?? 0), 0);
  const litersUsed = valid.reduce((acc, row) => acc + row.liters, 0);
  return {
    intervals: valid.length,
    kmDriven,
    litersUsed,
    kmPerLiter: litersUsed > 0 ? kmDriven / litersUsed : null,
  };
}

export function computeMetrics(
  trip: Pick<
    Trip,
    | "freightMode"
    | "netWeight"
    | "pricePerTon"
    | "pricePerTrip"
    | "kmStart"
    | "kmEnd"
    | "dieselLiters"
    | "dieselPrice"
  >,
  commissionPct: number,
): TripMetrics {
  const freight = freightOf(trip);
  const kmDriven = Math.max(0, trip.kmEnd - trip.kmStart);
  // Intencionalmente não calculamos KM/L pela viagem. A média vem somente dos abastecimentos.
  const kmPerLiter = null;
  const dieselCost = trip.dieselLiters * trip.dieselPrice;
  const grossResult = freight - dieselCost;
  const commissionValue = freight * commissionPct;
  const afterCommission = grossResult - commissionValue;
  return {
    freight,
    kmDriven,
    kmPerLiter,
    dieselCost,
    grossResult,
    commissionPct,
    commissionValue,
    afterCommission,
  };
}

export function enrichTrip(
  trip: Trip,
  drivers: Driver[],
  fleets: Fleet[],
): ComputedTrip {
  const driver = drivers.find((d) => d.id === trip.driverId);
  const fleet = fleets.find((f) => f.id === trip.fleetId);
  const commissionPct = driver?.commissionPct ?? 0;
  return {
    ...trip,
    ...computeMetrics(trip, commissionPct),
    driverName: driver?.name ?? "Motorista removido",
    fleetName: fleet?.name ?? "Conjunto removido",
    tractorPlate: fleet?.tractorPlate ?? "—",
    trailerPlate: fleet?.trailerPlate ?? "—",
  };
}

export function periodStart(key: PeriodKey, now = new Date()): Date | null {
  if (key === "all") return null;
  const d = new Date(now);
  d.setHours(0, 0, 0, 0);
  if (key === "7d") {
    d.setDate(d.getDate() - 6);
    return d;
  }
  if (key === "30d") {
    d.setDate(d.getDate() - 29);
    return d;
  }
  d.setDate(1);
  return d;
}

export function inPeriod(isoDate: string, key: PeriodKey, now = new Date()) {
  const start = periodStart(key, now);
  if (!start) return true;
  return isoDate >= toIsoDate(start);
}

export function toIsoDate(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function previousPeriodRange(key: PeriodKey, now = new Date()) {
  if (key === "all") return null;
  const currentStart = periodStart(key, now);
  if (!currentStart) return null;
  const end = new Date(currentStart);
  end.setDate(end.getDate() - 1);
  const start = new Date(currentStart);
  if (key === "7d") start.setDate(start.getDate() - 7);
  else if (key === "30d") start.setDate(start.getDate() - 30);
  else start.setMonth(start.getMonth() - 1);
  return { start: toIsoDate(start), end: toIsoDate(end) };
}

export function aggregateKpis(trips: ComputedTrip[]): DashboardKpis {
  const tripCount = trips.length;
  const totalKm = sum(trips, (t) => t.kmDriven);
  const loadedTons = sum(trips, (t) => t.loadedTons);
  const grossWeight = sum(trips, (t) => t.grossWeight);
  const netWeight = sum(trips, (t) => t.netWeight);
  const revenue = sum(trips, (t) => t.freight);
  const dieselLiters = sum(trips, (t) => t.dieselLiters);
  const dieselCost = sum(trips, (t) => t.dieselCost);
  const commissions = sum(trips, (t) => t.commissionValue);
  const grossResult = sum(trips, (t) => t.grossResult);
  const afterCommission = sum(trips, (t) => t.afterCommission);
  const tonRows = trips.filter((t) => t.freightMode === "ton");
  const tonWeight = sum(tonRows, (t) => t.netWeight);
  const tonFreight = sum(tonRows, (t) => t.freight);
  const modes = freightModeBreakdown(trips);
  return {
    tripCount,
    tonTripCount: modes.tonTripCount,
    tonTons: modes.tonTons,
    tonFreight: modes.tonFreight,
    tripModeCount: modes.tripModeCount,
    tripFreight: modes.tripFreight,
    cegonhaCount: modes.cegonhaCount,
    cegonhaFreight: modes.cegonhaFreight,
    caixinhaCount: modes.caixinhaCount,
    caixinhaFreight: modes.caixinhaFreight,
    fixedTripCount: modes.fixedTripCount,
    fixedFreight: modes.fixedFreight,
    totalKm,
    loadedTons,
    grossWeight,
    netWeight,
    revenue,
    dieselLiters,
    dieselCost,
    commissions,
    grossResult,
    afterCommission,
    avgKmL: null,
    avgPerTon: tonWeight > 0 ? tonFreight / tonWeight : null,
  };
}

export function totalsByDriver(
  trips: ComputedTrip[],
  drivers: Driver[],
): DriverTotals[] {
  return drivers.map((driver) => {
    const rows = trips.filter((t) => t.driverId === driver.id);
    const tonRows = rows.filter((t) => t.freightMode === "ton");
    const modes = freightModeBreakdown(rows);
    const totalKm = sum(rows, (t) => t.kmDriven);
    const netWeight = sum(rows, (t) => t.netWeight);
    const tonWeight = sum(tonRows, (t) => t.netWeight);
    const netTimesPrice = sum(tonRows, (t) => t.netWeight * t.pricePerTon);
    const freight = sum(rows, (t) => t.freight);
    const dieselLiters = sum(rows, (t) => t.dieselLiters);
    const commissionValue = freight * driver.commissionPct;
    return {
      driverId: driver.id,
      driverName: driver.name,
      tripCount: rows.length,
      tonTripCount: modes.tonTripCount,
      tonTons: modes.tonTons,
      tonFreight: modes.tonFreight,
      tripModeCount: modes.tripModeCount,
      tripFreight: modes.tripFreight,
      cegonhaCount: modes.cegonhaCount,
      cegonhaFreight: modes.cegonhaFreight,
      caixinhaCount: modes.caixinhaCount,
      caixinhaFreight: modes.caixinhaFreight,
      fixedTripCount: modes.fixedTripCount,
      fixedFreight: modes.fixedFreight,
      totalKm,
      netWeight,
      avgPricePerTon: tonWeight > 0 ? netTimesPrice / tonWeight : null,
      netTimesPrice,
      freight,
      commissionPct: driver.commissionPct,
      commissionValue,
      freightAfterCommission: freight - commissionValue,
      dieselLiters,
      kmPerLiter: null,
    };
  });
}

export function totalsByFleet(
  trips: ComputedTrip[],
  fleets: Fleet[],
): FleetTotals[] {
  return fleets.map((fleet) => {
    const rows = trips.filter((t) => t.fleetId === fleet.id);
    const tonRows = rows.filter((t) => t.freightMode === "ton");
    const modes = freightModeBreakdown(rows);
    const totalKm = sum(rows, (t) => t.kmDriven);
    const netWeight = sum(rows, (t) => t.netWeight);
    const tonWeight = sum(tonRows, (t) => t.netWeight);
    const netTimesPrice = sum(tonRows, (t) => t.netWeight * t.pricePerTon);
    const freight = sum(rows, (t) => t.freight);
    const dieselLiters = sum(rows, (t) => t.dieselLiters);
    return {
      fleetId: fleet.id,
      fleetName: fleet.name,
      tractorPlate: fleet.tractorPlate,
      trailerPlate: fleet.trailerPlate,
      tripCount: rows.length,
      tonTripCount: modes.tonTripCount,
      tonTons: modes.tonTons,
      tonFreight: modes.tonFreight,
      tripModeCount: modes.tripModeCount,
      tripFreight: modes.tripFreight,
      cegonhaCount: modes.cegonhaCount,
      cegonhaFreight: modes.cegonhaFreight,
      caixinhaCount: modes.caixinhaCount,
      caixinhaFreight: modes.caixinhaFreight,
      fixedTripCount: modes.fixedTripCount,
      fixedFreight: modes.fixedFreight,
      totalKm,
      netWeight,
      avgPricePerTon: tonWeight > 0 ? netTimesPrice / tonWeight : null,
      netTimesPrice,
      freight,
      dieselLiters,
      kmPerLiter: null,
    };
  });
}

export function nextTripCode(trips: Trip[]) {
  const max = trips.reduce((acc, t) => {
    const n = Number.parseInt(t.code.replace(/\D/g, ""), 10);
    return Number.isFinite(n) ? Math.max(acc, n) : acc;
  }, 0);
  return String(max + 1);
}

export function lastKmForFleet(trips: Trip[], fleetId: string) {
  const row = [...trips]
    .filter((t) => t.fleetId === fleetId)
    .sort((a, b) => b.date.localeCompare(a.date) || b.kmEnd - a.kmEnd)[0];
  return row?.kmEnd ?? null;
}

export function lastDieselPrice(trips: Trip[]) {
  const row = [...trips].sort((a, b) => b.date.localeCompare(a.date))[0];
  return row?.dieselPrice ?? 6.1;
}

export function deltaPct(current: number, previous: number) {
  if (previous === 0) return current === 0 ? 0 : null;
  return (current - previous) / previous;
}

function sum<T>(rows: T[], fn: (row: T) => number) {
  return rows.reduce((acc, row) => acc + fn(row), 0);
}

export function groupRevenueByDate(trips: ComputedTrip[]) {
  const map = new Map<
    string,
    { date: string; freight: number; diesel: number; result: number }
  >();
  for (const t of trips) {
    const cur = map.get(t.date) ?? {
      date: t.date,
      freight: 0,
      diesel: 0,
      result: 0,
    };
    cur.freight += t.freight;
    cur.diesel += t.dieselCost;
    cur.result += t.grossResult;
    map.set(t.date, cur);
  }
  return [...map.values()].sort((a, b) => a.date.localeCompare(b.date));
}
