import { createHmac, timingSafeEqual } from "node:crypto";
import { deleteCookie, getCookie, setCookie } from "@tanstack/react-start/server";
import { getSql } from "@/lib/db";
import { clearLoginFailures, loginAttemptAllowed, recordLoginFailure } from "@/lib/auth-rate-limit.server";
import { hashPassword, verifyPassword } from "@/lib/password-security.server";

const COOKIE_NAME = "transisrael_gerencia";
const RESET_COOKIE_NAME = "transisrael_gerencia_reset";
const SESSION_SECONDS = 60 * 60 * 12;
const REMEMBER_SECONDS = 60 * 60 * 24 * 30;
const RESET_SECONDS = 10 * 60;

function sessionSecret() {
  const secret = process.env.MANAGEMENT_SESSION_SECRET?.trim();
  if (!secret || secret.length < 32) throw new Error("MANAGEMENT_SESSION_SECRET ausente ou fraco; configure pelo menos 32 caracteres.");
  return secret;
}
function signature(payload: string) { return createHmac("sha256", sessionSecret()).update(payload).digest("hex"); }
function safeEqual(aValue: string, bValue: string) { const a=Buffer.from(aValue); const b=Buffer.from(bValue); return a.length===b.length && timingSafeEqual(a,b); }
function makeToken(username: string, purpose: "session" | "reset", seconds: number) {
  const expiresAt = Math.floor(Date.now() / 1000) + seconds;
  const payload = `${purpose}|${username}|${expiresAt}`;
  return `${payload}|${signature(payload)}`;
}
function parseToken(token: string | undefined, purpose: "session" | "reset") {
  if (!token) return null;
  const parts = token.split("|");
  if (parts.length !== 4) return null;
  const [tokenPurpose, username, expiresRaw, supplied] = parts;
  const expiresAt = Number(expiresRaw);
  if (tokenPurpose !== purpose || !username || !Number.isFinite(expiresAt) || expiresAt <= Math.floor(Date.now() / 1000)) return null;
  const payload = `${purpose}|${username}|${expiresAt}`;
  const expected = signature(payload);
  if (!safeEqual(supplied, expected)) return null;
  return { username, expiresAt };
}

export async function verifyManagementCredentials(username: string, password: string) {
  const clean = username.trim();
  if (!(await loginAttemptAllowed("management", clean))) return { ok: false as const, found: false as const, blocked: true as const };
  const sql = await getSql();
  const rows = await sql<{ id: string; username: string; password_hash: string; role: string; status: string; must_change_password: boolean }>`
    select id, username, password_hash, role, status, coalesce(must_change_password, false) as must_change_password
    from management_users where lower(username) = lower(${clean}) limit 1
  `;
  const row = rows[0];
  if (!row) return { ok: false as const, found: false as const };
  if (row.status !== "ativo") {
    await recordLoginFailure("management", clean);
    return { ok: false as const, found: true as const };
  }
  const verified = await verifyPassword(password, row.password_hash);
  if (!verified.ok) {
    await recordLoginFailure("management", clean);
    return { ok: false as const, found: true as const };
  }
  await clearLoginFailures("management", clean);
  // Legacy passwords shorter than the new minimum must still be allowed once
  // so the owner can reach the password-change flow instead of receiving HTTP 500.
  if (verified.legacy && password.length >= 10) {
    const upgraded = await hashPassword(password);
    await sql`update management_users set password_hash = ${upgraded}, must_change_password = true, updated_at = now() where id = ${row.id}`;
  }
  return { ok: true as const, found: true as const, username: row.username, role: row.role || "admin", mustChangePassword: row.must_change_password || verified.legacy };
}

export function managementSession() { return parseToken(getCookie(COOKIE_NAME), "session"); }
export function assertManagementSession() {
  const session = managementSession();
  if (!session) throw new Error("Sessão administrativa inválida.");
  return session;
}
function managementResetSession() { return parseToken(getCookie(RESET_COOKIE_NAME), "reset"); }

export async function loginManagement(username: string, password: string, remember = false) {
  const cleanUsername = username.trim();
  const verified = await verifyManagementCredentials(cleanUsername, password);
  if (verified.ok) {
    const { logoutKlebersom } = await import("@/lib/klebersom-access.server");
    logoutKlebersom();
    deleteCookie(COOKIE_NAME, { path: "/" });
    if (verified.mustChangePassword) {
      setCookie(RESET_COOKIE_NAME, makeToken(verified.username, "reset", RESET_SECONDS), { path: "/", httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", maxAge: RESET_SECONDS });
      return { ok: true as const, role: "admin" as const, username: verified.username, requiresPasswordChange: true as const };
    }
    deleteCookie(RESET_COOKIE_NAME, { path: "/" });
    const sessionSeconds = remember ? REMEMBER_SECONDS : SESSION_SECONDS;
    setCookie(COOKIE_NAME, makeToken(verified.username, "session", sessionSeconds), { path: "/", httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: sessionSeconds });
    return { ok: true as const, role: "admin" as const, username: verified.username, requiresPasswordChange: false as const };
  }
  if ("blocked" in verified && verified.blocked) return { ok: false as const, message: "Muitas tentativas. Aguarde 15 minutos e tente novamente." };
  const { loginKlebersom } = await import("@/lib/klebersom-access.server");
  const driverResult = await loginKlebersom(cleanUsername, password, remember);
  if (driverResult.ok) { deleteCookie(COOKIE_NAME, { path: "/" }); deleteCookie(RESET_COOKIE_NAME, { path: "/" }); return driverResult; }
  return ("blocked" in driverResult && driverResult.blocked) ? { ok: false as const, message: "Muitas tentativas. Aguarde 15 minutos e tente novamente." } : { ok: false as const, message: "Login ou senha inválidos." };
}

export async function changeManagementPasswordWithCurrent(username: string, currentPassword: string, newPassword: string) {
  const verified = await verifyManagementCredentials(username, currentPassword);
  if (!verified.ok) return { ok: false as const };
  const sql = await getSql();
  const hash = await hashPassword(newPassword);
  const rows = await sql<{ username: string }>`update management_users
    set password_hash=${hash}, must_change_password=false, updated_at=now()
    where lower(username)=lower(${verified.username}) and status='ativo'
    returning username`;
  const changed = rows[0]?.username;
  if (!changed) return { ok: false as const };
  await clearLoginFailures("management", changed);
  return { ok: true as const, username: changed };
}
export async function completeManagementPasswordChange(newPassword: string) {
  const reset = managementResetSession();
  if (!reset) return null;
  const sql = await getSql();
  const hash = await hashPassword(newPassword);
  const rows = await sql<{ username: string }>`update management_users set password_hash=${hash},must_change_password=false,updated_at=now() where lower(username)=lower(${reset.username}) and status='ativo' returning username`;
  const username = rows[0]?.username;
  if (!username) throw new Error("Conta administrativa não encontrada.");
  deleteCookie(RESET_COOKIE_NAME, { path: "/" });
  setCookie(COOKIE_NAME, makeToken(username, "session", SESSION_SECONDS), { path: "/", httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: SESSION_SECONDS });
  return { ok: true as const, role: "admin" as const, username };
}

export function logoutManagement() { deleteCookie(COOKIE_NAME, { path: "/" }); deleteCookie(RESET_COOKIE_NAME, { path: "/" }); return { ok: true as const }; }
