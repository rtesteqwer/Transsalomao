const brlFmt = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});

const numFmt = new Intl.NumberFormat("pt-BR", {
  maximumFractionDigits: 2,
});

const num1Fmt = new Intl.NumberFormat("pt-BR", {
  minimumFractionDigits: 1,
  maximumFractionDigits: 1,
});

const intFmt = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 });

const compactFmt = new Intl.NumberFormat("pt-BR", {
  notation: "compact",
  maximumFractionDigits: 1,
});

export function brl(n: number) {
  return brlFmt.format(n);
}

export function num(n: number, digits = 2) {
  return new Intl.NumberFormat("pt-BR", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(n);
}

export function numLoose(n: number) {
  return numFmt.format(n);
}

export function num1(n: number) {
  return num1Fmt.format(n);
}

export function integer(n: number) {
  return intFmt.format(n);
}

export function compact(n: number) {
  return compactFmt.format(n);
}

export function pct(fraction: number) {
  return new Intl.NumberFormat("pt-BR", {
    style: "percent",
    maximumFractionDigits: 1,
  }).format(fraction);
}

export function kmL(n: number | null) {
  if (n === null || !Number.isFinite(n)) return "—";
  return `${num(n, 2)} km/L`;
}

export function tons(n: number) {
  return `${num(n, 2)} t`;
}

export function liters(n: number) {
  return `${num(n, 0)} L`;
}

export function km(n: number) {
  return `${integer(n)} km`;
}

export function formatDate(iso: string) {
  const [y, m, d] = String(iso ?? "").split("-");
  if (!y || !m || !d) return iso;
  return `${d}/${m}/${y}`;
}

export function formatDateShort(iso: string) {
  const [y, m, d] = String(iso ?? "").split("-");
  if (!y || !m || !d) return iso;
  return `${d}/${m}`;
}

export function monthLabel(iso: string) {
  const [y, m] = String(iso ?? "").split("-");
  const months = [
    "jan",
    "fev",
    "mar",
    "abr",
    "mai",
    "jun",
    "jul",
    "ago",
    "set",
    "out",
    "nov",
    "dez",
  ];
  const idx = Number(m) - 1;
  return `${months[idx] ?? m}/${y?.slice(2)}`;
}

export function signedPct(fraction: number | null) {
  if (fraction === null || !Number.isFinite(fraction)) return "—";
  const sign = fraction > 0 ? "+" : "";
  return `${sign}${pct(fraction)}`;
}

export function maskCpf(value: string) {
  const d = value.replace(/\D/g, "").slice(0, 11);
  return d
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}

export function maskPhone(value: string) {
  const d = value.replace(/\D/g, "").slice(0, 11);
  if (d.length <= 10) {
    return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{4})(\d)/, "$1-$2");
  }
  return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
}

export function maskPlate(value: string) {
  return value.toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 8);
}

export function downloadText(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function toCsv(rows: Array<Record<string, string | number | null>>) {
  if (rows.length === 0) return "";
  const headers = Object.keys(rows[0] ?? {});
  const esc = (v: string | number | null) => {
    const s = v === null || v === undefined ? "" : String(v);
    if (/[;"\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  return [
    headers.join(";"),
    ...rows.map((r) => headers.map((h) => esc(r[h] ?? "")).join(";")),
  ].join("\n");
}
