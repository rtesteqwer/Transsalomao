import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import type {
  Driver,
  DriverReport,
  Expense,
  Fleet,
  FleetState,
  FreightMode,
  FreightPrices,
  Fueling,
  Trip,
} from "@/lib/types";

function num(v: unknown) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.trim() !== "") {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  }
  return 0;
}

function str(v: unknown) {
  return v == null ? "" : String(v);
}

function freightMode(v: unknown): FreightMode {
  const mode = str(v);
  if (mode === "trip" || mode === "cegonha" || mode === "caixinha") return mode;
  return "ton";
}
function nullableFreightMode(v: unknown): FreightMode | null {
  if (v == null || String(v).trim() === "") return null;
  return freightMode(v);
}


function mapFreightPrices(rows: Record<string, unknown>[]): FreightPrices {
  const prices: FreightPrices = { trip: 0, cegonha: 0, caixinha: 0 };
  for (const row of rows) {
    const mode = str(row.mode);
    if (mode === "trip" || mode === "cegonha" || mode === "caixinha") {
      prices[mode] = num(row.price);
    }
  }
  return prices;
}

async function getConfiguredTripPrice(
  sql: Awaited<ReturnType<typeof getSql>>,
  mode: "trip" | "cegonha" | "caixinha",
) {
  const rows = await sql<Record<string, unknown>>`
    select price from freight_prices where mode = ${mode} limit 1
  `;
  return num(rows[0]?.price);
}

function mapDriver(r: Record<string, unknown>): Driver {
  return {
    id: str(r.id),
    name: str(r.name),
    phone: str(r.phone),
    category: str(r.category),
    status: str(r.status) === "inativo" ? "inativo" : "ativo",
    commissionPct: num(r.commission_pct),
  };
}

function mapFleet(r: Record<string, unknown>): Fleet {
  return {
    id: str(r.id),
    name: str(r.name),
    tractorPlate: str(r.tractor_plate),
    trailerPlate: str(r.trailer_plate),
    model: str(r.model),
    status: str(r.status) === "inativo" ? "inativo" : "ativo",
  };
}

function mapTrip(r: Record<string, unknown>): Trip {
  return {
    id: str(r.id),
    code: str(r.code),
    date: str(r.date).slice(0, 10),
    client: str(r.client),
    origin: str(r.origin),
    destination: str(r.destination),
    driverId: str(r.driver_id),
    fleetId: str(r.fleet_id),
    loadedTons: num(r.loaded_tons),
    grossWeight: num(r.gross_weight),
    netWeight: num(r.net_weight),
    freightMode: freightMode(r.freight_mode),
    tripBillingType: str(r.trip_billing_type) === "weight" ? "weight" : "fixed",
    pricePerTon: num(r.price_per_ton),
    pricePerTrip: num(r.price_per_trip),
    kmStart: num(r.km_start),
    kmEnd: num(r.km_end),
    dieselLiters: num(r.diesel_liters),
    dieselPrice: num(r.diesel_price),
  };
}

function mapReport(r: Record<string, unknown>): DriverReport {
  const status = str(r.status);
  const created = r.created_at;
  return {
    id: str(r.id),
    ticket: str(r.ticket),
    driverId: str(r.driver_id),
    fleetId: str(r.fleet_id),
    km: num(r.km),
    tons: num(r.tons),
    dailyValue: num(r.daily_value),
    freightMode: nullableFreightMode(r.freight_mode),
    status:
      status === "aceito" || status === "recusado" ? status : "pendente",
    createdAt: created instanceof Date ? created.toISOString() : str(created),
    tripId: r.trip_id ? str(r.trip_id) : null,
  };
}

function mapFueling(r: Record<string, unknown>): Fueling {
  const created = r.created_at;
  return {
    id: str(r.id),
    date: str(r.date).slice(0, 10),
    driverId: r.driver_id ? str(r.driver_id) : null,
    fleetId: str(r.fleet_id),
    station: str(r.station),
    km: num(r.km),
    liters: num(r.liters),
    pricePerLiter: num(r.price_per_liter),
    discountAmount: num(r.discount_amount),
    totalAmount: r.total_amount == null ? null : num(r.total_amount),
    notes: str(r.notes),
    createdAt: created instanceof Date ? created.toISOString() : str(created),
  };
}

function mapExpense(r: Record<string, unknown>): Expense {
  const created = r.created_at;
  return {
    id: str(r.id),
    date: str(r.date).slice(0, 10),
    fleetId: r.fleet_id ? str(r.fleet_id) : null,
    assetType: r.asset_type ? (str(r.asset_type) === "trailer" ? "trailer" : "tractor") : null,
    driverId: r.driver_id ? str(r.driver_id) : null,
    transactionTime: r.transaction_time ? str(r.transaction_time) : null,
    category: str(r.category),
    description: str(r.description),
    amount: num(r.amount),
    notes: str(r.notes),
    createdAt: created instanceof Date ? created.toISOString() : str(created),
  };
}

async function nextTicketCode(sql: Awaited<ReturnType<typeof getSql>>) {
  const rows = await sql<{ next: string }>`select nextval('transisrael_ticket_seq')::text as next`;
  return String(rows[0]?.next ?? "1");
}

function newId(prefix: string) {
  return `${prefix}_${crypto.randomUUID().replace(/-/g, "").slice(0, 10)}`;
}


let ticketNormalizationPromise: Promise<void> | null = null;
async function normalizeTicketCodes(sql: Awaited<ReturnType<typeof getSql>>) {
  if (!ticketNormalizationPromise) {
    ticketNormalizationPromise = (async () => {
      await sql`with ordered as (select id, row_number() over (order by date asc, created_at asc nulls first, id asc) as rn from trips) update trips t set code = ordered.rn::text from ordered where t.id = ordered.id`;
      const countRows = await sql<{ count: number }>`select count(*)::int as count from trips`;
      const offset = Number(countRows[0]?.count ?? 0);
      await sql`with ordered as (select r0.id, row_number() over (order by r0.created_at asc nulls first, r0.id asc) as rn from reports r0 where r0.status = 'pendente' and not exists (select 1 from tickets_balanca tb where tb.report_id = r0.id)) update reports r set ticket = (${offset} + ordered.rn)::text from ordered where r.id = ordered.id`;
      await sql`update reports r set ticket = tb.numero_ticket from tickets_balanca tb where tb.report_id = r.id and r.status = 'pendente' and r.ticket is distinct from tb.numero_ticket`;
      await sql`update reports r set ticket = t.code from trips t where r.trip_id = t.id`;
    })().catch((error) => { ticketNormalizationPromise = null; throw error; });
  }
  await ticketNormalizationPromise;
}

async function requireManagement() {
  const { assertManagementSession } = await import("@/lib/management-auth.server");
  return assertManagementSession();
}

async function fleetAccess() {
  try {
    const { managementSession } = await import("@/lib/management-auth.server");
    const manager = managementSession();
    if (manager) return { role: "admin" as const, driverId: null };
  } catch {}
  const { klebersomAuthorizedSession } = await import("@/lib/klebersom-access.server");
  const driver = await klebersomAuthorizedSession();
  if (driver) return { role: "driver" as const, driverId: driver.driverId };
  throw new Error("Faça login para acessar os dados da frota.");
}

export const getFleetState = createServerFn({ method: "GET" }).handler(
  async (): Promise<FleetState> => {
    const access = await fleetAccess();
    const sql = await getSql();
    if (access.role === "admin") {
      const [drivers, fleets, trips, reports, fuelings, expenses, freightPriceRows] = await Promise.all([
        sql<Record<string, unknown>>`select * from drivers order by name`, sql<Record<string, unknown>>`select * from fleets order by name`,
        sql<Record<string, unknown>>`select * from trips order by date desc, code desc`, sql<Record<string, unknown>>`select * from reports order by created_at desc`,
        sql<Record<string, unknown>>`select * from fuelings order by date desc, created_at desc`, sql<Record<string, unknown>>`select * from expenses order by date desc, created_at desc`,
        sql<Record<string, unknown>>`select mode, price from freight_prices`,
      ]);
      return { drivers:drivers.map(mapDriver), fleets:fleets.map(mapFleet), trips:trips.map(mapTrip), reports:reports.map(mapReport), fuelings:fuelings.map(mapFueling), expenses:expenses.map(mapExpense), freightPrices:mapFreightPrices(freightPriceRows) };
    }
    const driverId=access.driverId!;
    const [drivers, fleets, trips, reports, fuelings, expenses, freightPriceRows] = await Promise.all([
      sql<Record<string, unknown>>`select * from drivers where id=${driverId} and status='ativo' order by name`,
      sql<Record<string, unknown>>`select * from fleets where status='ativo' order by name`,
      sql<Record<string, unknown>>`select * from trips where driver_id=${driverId} order by date desc, code desc`,
      sql<Record<string, unknown>>`select * from reports where driver_id=${driverId} order by created_at desc`,
      sql<Record<string, unknown>>`select * from fuelings where driver_id=${driverId} order by date desc, created_at desc`,
      sql<Record<string, unknown>>`select * from expenses where driver_id=${driverId} order by date desc, created_at desc`,
      sql<Record<string, unknown>>`select mode, price from freight_prices`,
    ]);
    return { drivers:drivers.map(mapDriver), fleets:fleets.map(mapFleet), trips:trips.map(mapTrip), reports:reports.map(mapReport), fuelings:fuelings.map(mapFueling), expenses:expenses.map(mapExpense), freightPrices:mapFreightPrices(freightPriceRows) };
  },
);

const freightPricesSchema = z.object({
  trip: z.number().positive("Informe um valor maior que zero para Por viagem"),
  cegonha: z.number().positive("Informe um valor maior que zero para Cegonha"),
  caixinha: z.number().positive("Informe um valor maior que zero para Caixinha"),
});

export const upsertFreightPrices = createServerFn({ method: "POST" })
  .validator(freightPricesSchema)
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();

    await sql`
      insert into freight_prices (mode, price, updated_at)
      values ('trip', ${data.trip}, now())
      on conflict (mode) do update set
        price = excluded.price,
        updated_at = excluded.updated_at
    `;
    await sql`
      insert into freight_prices (mode, price, updated_at)
      values ('cegonha', ${data.cegonha}, now())
      on conflict (mode) do update set
        price = excluded.price,
        updated_at = excluded.updated_at
    `;
    await sql`
      insert into freight_prices (mode, price, updated_at)
      values ('caixinha', ${data.caixinha}, now())
      on conflict (mode) do update set
        price = excluded.price,
        updated_at = excluded.updated_at
    `;

    // Modos de valor fixo usam o preço atual da Gerência também no histórico.
    // Por tonelada nunca é alterado aqui: cada viagem mantém seu próprio R$/t.
    await sql`update trips set price_per_trip = ${data.trip} where freight_mode = 'trip'`;
    await sql`update trips set price_per_trip = ${data.cegonha} where freight_mode = 'cegonha'`;
    await sql`update trips set price_per_trip = ${data.caixinha} where freight_mode = 'caixinha'`;

    return { ok: true, freightPrices: data };
  });

const driverSchema = z.object({
  id: z.string().optional(),
  name: z.string().trim().min(2, "Informe o nome"),
  phone: z.string().trim(),
  category: z.string().trim().min(1),
  status: z.enum(["ativo", "inativo"]),
  commissionPct: z.number().min(0).max(1),
});

export const upsertDriver = createServerFn({ method: "POST" })
  .validator(driverSchema)
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    const id = data.id?.trim() || newId("drv");
    await sql`
      insert into drivers (id, name, phone, category, status, commission_pct)
      values (${id}, ${data.name}, ${data.phone}, ${data.category}, ${data.status}, ${data.commissionPct})
      on conflict (id) do update set
        name = excluded.name,
        phone = excluded.phone,
        category = excluded.category,
        status = excluded.status,
        commission_pct = excluded.commission_pct
    `;
    return { id };
  });

export const deleteDriver = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.string().min(1) }))
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    const [trips, reports, fuelings] = await Promise.all([
      sql<{ count: string }>`select count(*)::text as count from trips where driver_id = ${data.id}`,
      sql<{ count: string }>`select count(*)::text as count from reports where driver_id = ${data.id}`,
      sql<{ count: string }>`select count(*)::text as count from fuelings where driver_id = ${data.id}`,
    ]);
    const linked = Number(trips[0]?.count ?? 0) + Number(reports[0]?.count ?? 0) + Number(fuelings[0]?.count ?? 0);
    if (linked > 0) {
      throw new Error("Este motorista possui histórico de viagens, lançamentos ou abastecimentos. Para preservar os relatórios, altere o status para inativo em vez de excluir.");
    }
    await sql`delete from drivers where id = ${data.id}`;
    return { ok: true };
  });

const fleetSchema = z.object({
  id: z.string().optional(),
  name: z.string().trim().min(2, "Informe o conjunto"),
  tractorPlate: z.string().trim().min(1, "Informe a placa do cavalo"),
  trailerPlate: z.string().trim().min(1, "Informe a placa da carreta"),
  model: z.string().trim(),
  status: z.enum(["ativo", "inativo"]),
});

export const upsertFleet = createServerFn({ method: "POST" })
  .validator(fleetSchema)
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    const id = data.id?.trim() || newId("flt");
    await sql`
      insert into fleets (id, name, tractor_plate, trailer_plate, model, status)
      values (${id}, ${data.name}, ${data.tractorPlate}, ${data.trailerPlate}, ${data.model}, ${data.status})
      on conflict (id) do update set
        name = excluded.name,
        tractor_plate = excluded.tractor_plate,
        trailer_plate = excluded.trailer_plate,
        model = excluded.model,
        status = excluded.status
    `;
    return { id };
  });

const reportSchema = z.object({
  ticket: z.string().trim().max(80).default(""),
  driverId: z.string().min(1, "Escolha o motorista"),
  fleetId: z.string().min(1, "Escolha o conjunto"),
  km: z.number().min(0).default(0),
  tons: z.number().min(0).default(0),
  dailyValue: z.number().min(0).default(0),
  freightMode: z.enum(["ton", "trip", "cegonha", "caixinha"]).nullable().optional().default(null),
});

export const submitReport = createServerFn({ method: "POST" })
  .validator(reportSchema)
  .handler(async ({ data }) => {
    const access = await fleetAccess();
    const { reportDriverId } = await import("@/lib/report-access");
    const driverId = reportDriverId(access, data.driverId);
    const sql = await getSql();
    const driver = await sql<{ id: string }>`select id from drivers where id=${driverId} and status='ativo' limit 1`;
    if (!driver[0]) throw new Error("Motorista inválido ou inativo.");
    const id = newId("rep");
    const suppliedTicket = data.ticket.trim();
    const ticket = suppliedTicket || await nextTicketCode(sql);
    if (suppliedTicket) {
      const existing = await sql<{ id: string }>`select id from reports where ticket=${suppliedTicket} and status <> 'recusado' limit 1`;
      if (existing[0]) throw new Error("Este ticket já foi lançado.");
      const tripHit = await sql<{ id: string }>`select id from trips where code=${suppliedTicket} limit 1`;
      if (tripHit[0]) throw new Error("Este ticket já virou viagem no Painel Gerência.");
    }
    const fleet = await sql<{ id: string }>`select id from fleets where id=${data.fleetId} and status='ativo' limit 1`;
    if (!fleet[0]) throw new Error("Conjunto inválido ou inativo.");
    await sql`insert into reports (id,ticket,driver_id,fleet_id,km,tons,daily_value,freight_mode,status)
      values (${id},${ticket},${driverId},${data.fleetId},${data.km},${data.tons},${data.dailyValue},${data.freightMode ?? null},'pendente')`;
    return { id, ticket };
  });

// validation probe: inspect reconstructed acceptReports before production deploy
export const acceptReports = createServerFn({ method: "POST" })
  .validator(z.object({ ids: z.array(z.string().min(1)).min(1).max(500) }))
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    const ids = [...new Set(data.ids)];
    const reports = (await Promise.all(ids.map(async (id) => (await sql<Record<string, unknown>>`
      select * from reports where id = ${id} and status = 'pendente' limit 1
    `)[0]))).filter(Boolean) as Record<string, unknown>[];

    reports.sort((a, b) => str(a.fleet_id).localeCompare(str(b.fleet_id)) || num(a.km) - num(b.km));

    const prices = new Map<string, number>();
    const modes = [...new Set(reports.map((report) => nullableFreightMode(report.freight_mode)).filter((mode): mode is "cegonha" | "caixinha" => mode === "cegonha" || mode === "caixinha"))];
    await Promise.all(modes.map(async (mode) => prices.set(mode, await getConfiguredTripPrice(sql, mode))));

    let accepted = 0;
    let needsReview = 0;

    for (const report of reports) {
      const linkedId = str(report.trip_id);
      if (linkedId) {
        const linked = await sql<{ id: string }>`select id from trips where id = ${linkedId} limit 1`;
        if (linked[0]?.id) {
          await sql`update reports set status = 'aceito' where id = ${str(report.id)}`;
          accepted += 1;
          continue;
        }
      }

      const reportId = str(report.id); const mode = nullableFreightMode(report.freight_mode); const price = mode === "trip" ? num(report.daily_value) : mode && mode !== "ton" ? (prices.get(mode) ?? 0) : 0;
      if (!mode || (mode !== "ton" && price <= 0)) {
        needsReview += 1;
        continue;
      }

      let ticket = str(report.ticket).toUpperCase();
      const collision = ticket ? await sql<{ id: string }>`select id from trips where code = ${ticket} limit 1` : [];
      if (!ticket || collision[0]?.id) ticket = await nextTicketCode(sql);

      const ticketPrices = mode === "ton" ? await sql<{ ticket_data: Record<string, unknown> | null }>
        `select ticket_data from tickets_balanca where report_id = ${reportId} order by id desc limit 1` : [];
      const proposedPrice = Number(ticketPrices[0]?.ticket_data?.price_per_ton);
      const pricePerTon = Number.isFinite(proposedPrice) && proposedPrice > 0 && proposedPrice <= 100_000_000 ? proposedPrice : 0;
      // A ton trip without a price still needs management review before closing.
      if (mode === "ton" && (pricePerTon <= 0 || num(report.tons) <= 0)) { needsReview += 1; continue; }
      const tripId = newId("trip");
      const created = report.created_at;
      const createdAt = created instanceof Date ? created.toISOString() : str(created);
      const date = /^\d{4}-\d{2}-\d{2}/.test(createdAt) ? createdAt.slice(0, 10) : new Date().toISOString().slice(0, 10);
      const fleetId = str(report.fleet_id);
      const kmEnd = num(report.km);
      const prev = await sql<{ km_end: number }>`select km_end from trips where fleet_id = ${fleetId} and km_end <= ${kmEnd} order by km_end desc limit 1`;
      const kmStart = num(prev[0]?.km_end);
      const tons = num(report.tons);

      await sql`
        insert into trips (id, code, date, client, origin, destination, driver_id, fleet_id, loaded_tons, gross_weight, net_weight, freight_mode, price_per_ton, price_per_trip, km_start, km_end, diesel_liters, diesel_price)
        values (${tripId}, ${ticket}, ${date}, '', '', '', ${str(report.driver_id)}, ${fleetId}, ${tons}, 0, ${tons}, ${mode}, ${pricePerTon}, ${price}, ${kmStart}, ${kmEnd}, 0, 0)
      `;
      await sql`update reports set status = 'aceito', trip_id = ${tripId}, ticket = ${ticket} where id = ${reportId}`;
      accepted += 1;
    }

    return { ok: true, accepted, needsReview };
  });
export const rejectReport = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.string() }))
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    await sql`update reports set status = 'recusado' where id = ${data.id} and status = 'pendente'`;
    return { ok: true };
  });

export const deleteReport = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.string().min(1) }))
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    try { await sql`update trip_ticket_photos set relation_type='unlinked', relation_id='pending', report_status=null where relation_type='report' and relation_id=${data.id}`; } catch {}
    const __deleted_reports = await sql<{ id: string }[]>`delete from reports where id=${data.id} returning id`;
    if (!__deleted_reports[0]) throw new Error("O lançamento já não existe ou a exclusão não foi confirmada pelo banco.");
    return { ok: true };
  });

const pendingReportEditSchema = z.object({
  id: z.string().min(1),
  driverId: z.string().min(1, "Escolha o motorista"),
  fleetId: z.string().min(1, "Escolha o conjunto"),
  tons: z.number().min(0).default(0),
  dailyValue: z.number().min(0).default(0),
  freightMode: z.enum(["ton", "trip", "cegonha", "caixinha"]),
});

export const updatePendingReport = createServerFn({ method: "POST" })
  .validator(pendingReportEditSchema)
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    const rows = await sql<{ id: string }[]>`
      update reports set
        driver_id = ${data.driverId},
        fleet_id = ${data.fleetId},
        tons = ${data.freightMode === "ton" ? data.tons : 0},
        daily_value = ${data.freightMode === "trip" ? data.dailyValue : 0},
        freight_mode = ${data.freightMode}
      where id = ${data.id} and status = 'pendente'
      returning id
    `;
    if (!rows[0]) throw new Error("Este lançamento não está mais pendente.");
    return { ok: true };
  });

const tripSchema = z.object({
  id: z.string().optional(),
  code: z.string().trim().min(1, "Informe o ticket"),
  date: z.string().min(8),
  client: z.string().trim(),
  origin: z.string().trim(),
  destination: z.string().trim(),
  driverId: z.string().min(1),
  fleetId: z.string().min(1),
  loadedTons: z.number().min(0),
  grossWeight: z.number().min(0),
  netWeight: z.number().min(0),
  freightMode: z.enum(["ton", "trip", "cegonha", "caixinha"]),
  tripBillingType: z.enum(["weight", "fixed"]).optional().default("fixed"),
  pricePerTon: z.number().min(0),
  pricePerTrip: z.number().min(0),
  kmStart: z.number().min(0),
  kmEnd: z.number().min(0),
  dieselLiters: z.number().min(0),
  dieselPrice: z.number().min(0),
  reportId: z.string().optional(),
});

export const upsertTrip = createServerFn({ method: "POST" })
  .validator(tripSchema)
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    const id = data.id?.trim() || newId("trip");
    const code = data.id ? data.code.toUpperCase() : await nextTicketCode(sql);
    const usesGlobalPrice = data.freightMode !== "ton";
    const pricePerTrip = data.freightMode !== "ton"
      ? await getConfiguredTripPrice(sql, data.freightMode)
      : 0;
    if (usesGlobalPrice && pricePerTrip <= 0) {
      const label = data.freightMode === "trip" ? "Por viagem" : data.freightMode === "cegonha" ? "Cegonha" : "Caixinha";
      throw new Error(`Configure o preço de ${label} em Cadastros > Preços frete antes de salvar a viagem.`);
    }
    if (data.freightMode === "ton" && data.pricePerTon <= 0) {
      throw new Error("Informe o preço R$/t desta viagem.");
    }
    await sql`
      insert into trips (
        id, code, date, client, origin, destination, driver_id, fleet_id,
        loaded_tons, gross_weight, net_weight, freight_mode, price_per_ton, price_per_trip,
        km_start, km_end, diesel_liters, diesel_price
      ) values (
        ${id}, ${code}, ${data.date}, ${data.client}, ${data.origin}, ${data.destination},
        ${data.driverId}, ${data.fleetId}, ${data.loadedTons}, ${data.grossWeight},
        ${data.netWeight}, ${data.freightMode}, ${data.pricePerTon}, ${pricePerTrip},
        ${data.kmStart}, ${data.kmEnd}, ${data.dieselLiters}, ${data.dieselPrice}
      )
      on conflict (id) do update set
        code = excluded.code,
        date = excluded.date,
        client = excluded.client,
        origin = excluded.origin,
        destination = excluded.destination,
        driver_id = excluded.driver_id,
        fleet_id = excluded.fleet_id,
        loaded_tons = excluded.loaded_tons,
        gross_weight = excluded.gross_weight,
        net_weight = excluded.net_weight,
        freight_mode = excluded.freight_mode,
        price_per_ton = excluded.price_per_ton,
        price_per_trip = excluded.price_per_trip,
        km_start = excluded.km_start,
        km_end = excluded.km_end,
        diesel_liters = excluded.diesel_liters,
        diesel_price = excluded.diesel_price
    `;
    // Se esta viagem veio de um lançamento, manter o lançamento sincronizado
    // com qualquer edição individual ou em lote feita na tela Viagens.
    await sql`
      update reports set
        ticket = ${code},
        driver_id = ${data.driverId},
        fleet_id = ${data.fleetId},
        km = ${data.kmEnd},
        tons = ${data.netWeight},
        freight_mode = ${data.freightMode}
      where trip_id = ${id}
    `;
    if (data.reportId) {
      await sql`update reports set status = 'aceito', trip_id = ${id} where id = ${data.reportId}`;
    }
    return { id };
  });

export const deleteAllTrips = createServerFn({ method: "POST" })
  .handler(async () => {
    await requireManagement();
    const sql = await getSql();
    const countRows = await sql<{ count: number }>`select count(*)::int as count from trips`;
    await sql`update reports set trip_id = null, status = 'pendente' where trip_id is not null`;
    await sql`delete from trips`;
    return { ok: true, deleted: Number(countRows[0]?.count ?? 0) };
  });

export const deleteTrip = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.string() }))
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    await sql`update reports set trip_id = null, status = 'pendente' where trip_id = ${data.id}`;
    try { await sql`update trip_ticket_photos set relation_type='unlinked', relation_id='pending', report_status=null where relation_type='trip' and relation_id=${data.id}`; } catch {}
    const __deleted_trips = await sql<{ id: string }[]>`delete from trips where id=${data.id} returning id`;
    if (!__deleted_trips[0]) throw new Error("A viagem já não existe ou a exclusão não foi confirmada pelo banco.");
    return { ok: true };
  });

const fuelingSchema = z.object({
  id: z.string().optional(),
  date: z.string().min(8),
  driverId: z.string().nullable().optional(),
  fleetId: z.string().min(1, "Escolha o conjunto"),
  station: z.string().trim(),
  km: z.number().min(0),
  liters: z.number().positive("Informe os litros"),
  pricePerLiter: z.number().min(0),
  discountAmount: z.number().min(0).optional(),
  totalAmount: z.number().min(0).nullable().optional(),
  notes: z.string().trim(),
});

export const upsertFueling = createServerFn({ method: "POST" })
  .validator(fuelingSchema)
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    const id = data.id?.trim() || newId("fuel");
    const driverId = data.driverId?.trim() || null;
    const discountAmount = Number(data.discountAmount ?? 0);
    const computedTotal = Math.max(0, Number(data.liters) * Number(data.pricePerLiter) - discountAmount);
    const totalAmount = data.totalAmount == null ? computedTotal : Number(data.totalAmount);
    await sql`
      insert into fuelings (id, date, driver_id, fleet_id, station, km, liters, price_per_liter, discount_amount, total_amount, notes)
      values (${id}, ${data.date}, ${driverId}, ${data.fleetId}, ${data.station}, ${data.km}, ${data.liters}, ${data.pricePerLiter}, ${discountAmount}, ${totalAmount}, ${data.notes})
      on conflict (id) do update set
        date = excluded.date,
        driver_id = excluded.driver_id,
        fleet_id = excluded.fleet_id,
        station = excluded.station,
        km = excluded.km,
        liters = excluded.liters,
        price_per_liter = excluded.price_per_liter,
        discount_amount = excluded.discount_amount,
        total_amount = excluded.total_amount,
        notes = excluded.notes
    `;
    return { id };
  });

export const deleteFueling = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.string().min(1) }))
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    try { await sql`update fueling_photo_reads set fueling_id=null, status='pending_completion', confirmed_at=null where fueling_id=${data.id}`; } catch {}
    const __deleted_fuelings = await sql<{ id: string }[]>`delete from fuelings where id=${data.id} returning id`;
    if (!__deleted_fuelings[0]) throw new Error("O abastecimento já não existe ou a exclusão não foi confirmada pelo banco.");
    return { ok: true };
  });

const expenseSchema = z.object({
  id: z.string().optional(),
  date: z.string().min(8),
  transactionTime: z.string().regex(/^(?:[01]\d|2[0-3]):[0-5]\d$/).nullable().optional(),
  fleetId: z.string().nullable().optional(),
  assetType: z.enum(["tractor", "trailer"]).nullable().optional(),
  driverId: z.string().nullable().optional(),
  category: z.string().trim().min(1, "Informe a categoria"),
  description: z.string().trim().min(1, "Informe a despesa"),
  amount: z.number().positive("Informe um valor maior que zero"),
  notes: z.string().trim(),
});

export const upsertExpense = createServerFn({ method: "POST" })
  .validator(expenseSchema)
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    const id = data.id?.trim() || newId("exp");
    const isAdvance = data.category === "Adiantamento";
    if (isAdvance && !data.driverId) throw new Error("Escolha o motorista que recebeu o adiantamento.");
    if (!isAdvance && (!data.fleetId || !data.assetType)) throw new Error("Escolha o conjunto e o veículo da despesa.");
    await sql`
      insert into expenses (id, date, transaction_time, fleet_id, asset_type, driver_id, category, description, amount, notes)
      values (${id}, ${data.date}, ${data.transactionTime ?? null}, ${isAdvance ? null : data.fleetId ?? null}, ${isAdvance ? null : data.assetType ?? null}, ${isAdvance ? data.driverId : null}, ${data.category}, ${data.description}, ${data.amount}, ${data.notes})
      on conflict (id) do update set
        date = excluded.date,
        transaction_time = excluded.transaction_time,
        fleet_id = excluded.fleet_id,
        asset_type = excluded.asset_type,
        driver_id = excluded.driver_id,
        category = excluded.category,
        description = excluded.description,
        amount = excluded.amount,
        notes = excluded.notes
    `;
    return { id };
  });

export const deleteExpense = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.string().min(1) }))
  .handler(async ({ data }) => {
    await requireManagement();
    const sql = await getSql();
    const __deleted_expenses = await sql<{ id: string }[]>`delete from expenses where id=${data.id} returning id`;
    if (!__deleted_expenses[0]) throw new Error("A despesa ou adiantamento já não existe ou a exclusão não foi confirmada pelo banco.");
    return { ok: true };
  });
