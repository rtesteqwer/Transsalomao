import { REPORT_LOGO_JPEG } from "@/lib/report-logo";
import { brl, formatDate, integer, kmL, liters, tons } from "@/lib/format";
import type { ComputedTrip, Fueling } from "@/lib/types";
import { freightModeBreakdown, freightModeLabel, fuelingConsumptionStats } from "@/lib/calc";

const PAGE_W = 595;
const PAGE_H = 842;
const MARGIN = 28;
const CONTENT_W = PAGE_W - MARGIN * 2;

const colors = {
  bg: [1, 1, 1] as const,
  surface: [1, 1, 1] as const,
  surface2: [250 / 255, 250 / 255, 250 / 255] as const,
  fg: [0, 0, 0] as const,
  muted: [70 / 255, 70 / 255, 70 / 255] as const,
  subtle: [110 / 255, 110 / 255, 110 / 255] as const,
  accent: [20 / 255, 20 / 255, 20 / 255] as const,
  border: [205 / 255, 205 / 255, 205 / 255] as const,
  ok: [40 / 255, 40 / 255, 40 / 255] as const,
};

function latin1Bytes(input: string) {
  const out = new Uint8Array(input.length);
  for (let i = 0; i < input.length; i += 1) {
    const code = input.charCodeAt(i);
    out[i] = code <= 255 ? code : 63;
  }
  return out;
}

function escapePdfText(input: string) {
  return input
    .replace(/[•·]/g, " - ")
    .replace(/→/g, " -> ")
    .replace(/[–—]/g, "-")
    .replace(/…/g, "...")
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)")
    .replace(/[\r\n]+/g, " ");
}

function normalizeFilename(name: string) {
  return name
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9-_]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .toLowerCase();
}

function truncate(text: string, maxChars: number) {
  if (text.length <= maxChars) return text;
  return `${text.slice(0, Math.max(0, maxChars - 3)).trimEnd()}...`;
}

function wrap(text: string, maxChars: number, maxLines = 2) {
  const words = text.trim().split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    const next = current ? `${current} ${word}` : word;
    if (next.length <= maxChars) {
      current = next;
      continue;
    }
    if (current) lines.push(current);
    current = word;
    if (lines.length >= maxLines - 1) break;
  }
  if (lines.length < maxLines && current) lines.push(current);
  if (lines.length === 0) lines.push("");
  const consumed = lines.join(" ").length;
  if (text.trim().length > consumed) {
    lines[lines.length - 1] = truncate(lines[lines.length - 1], maxChars - 1);
  }
  return lines.slice(0, maxLines);
}

function rgb([r, g, b]: readonly [number, number, number]) {
  return `${r.toFixed(3)} ${g.toFixed(3)} ${b.toFixed(3)}`;
}

class PdfPage {
  ops: string[] = [];

  rect(
    x: number,
    y: number,
    w: number,
    h: number,
    fill: readonly [number, number, number],
    stroke?: readonly [number, number, number],
    strokeWidth = 1,
  ) {
    this.ops.push("q");
    this.ops.push(`${rgb(fill)} rg`);
    if (stroke) {
      this.ops.push(`${rgb(stroke)} RG`);
      this.ops.push(`${strokeWidth.toFixed(2)} w`);
      this.ops.push(`${x.toFixed(2)} ${y.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re B`);
    } else {
      this.ops.push(`${x.toFixed(2)} ${y.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re f`);
    }
    this.ops.push("Q");
  }

  line(x1: number, y1: number, x2: number, y2: number, color: readonly [number, number, number], width = 1) {
    this.ops.push("q");
    this.ops.push(`${rgb(color)} RG`);
    this.ops.push(`${width.toFixed(2)} w`);
    this.ops.push(`${x1.toFixed(2)} ${y1.toFixed(2)} m ${x2.toFixed(2)} ${y2.toFixed(2)} l S`);
    this.ops.push("Q");
  }

  text(
    text: string,
    x: number,
    y: number,
    {
      size = 12,
      bold = false,
      color = colors.fg,
    }: {
      size?: number;
      bold?: boolean;
      color?: readonly [number, number, number];
    } = {},
  ) {
    this.ops.push("BT");
    this.ops.push(`/${bold ? "F2" : "F1"} ${size.toFixed(2)} Tf`);
    this.ops.push(`${rgb(color)} rg`);
    this.ops.push(`1 0 0 1 ${x.toFixed(2)} ${y.toFixed(2)} Tm`);
    this.ops.push(`(${escapePdfText(text)}) Tj`);
    this.ops.push("ET");
  }
}

function buildPdf(contents: string[]) {
  const objects: string[] = [];
  const pageIds: number[] = [];
  const fontRegularId = 3;
  const fontBoldId = 4;
  let nextId = 5;

  objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  objects[fontRegularId] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
  objects[fontBoldId] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";

  for (const content of contents) {
    const pageId = nextId++;
    const contentId = nextId++;
    pageIds.push(pageId);
    objects[pageId] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 ${fontRegularId} 0 R /F2 ${fontBoldId} 0 R >> >> /Contents ${contentId} 0 R >>`;
    objects[contentId] = `<< /Length ${latin1Bytes(content).length} >>\nstream\n${content}\nendstream`;
  }

  objects[2] = `<< /Type /Pages /Kids [${pageIds.map((id) => `${id} 0 R`).join(" ")}] /Count ${pageIds.length} >>`;

  const header = "%PDF-1.4\n%âãÏÓ\n";
  const chunks: Uint8Array[] = [latin1Bytes(header)];
  const offsets: number[] = [0];
  let offset = chunks[0].length;

  for (let id = 1; id < objects.length; id += 1) {
    const body = `${id} 0 obj\n${objects[id]}\nendobj\n`;
    offsets[id] = offset;
    const bytes = latin1Bytes(body);
    chunks.push(bytes);
    offset += bytes.length;
  }

  const xrefOffset = offset;
  const xref = [
    `xref\n0 ${objects.length}\n`,
    "0000000000 65535 f \n",
    ...Array.from({ length: objects.length - 1 }, (_, i) => `${String(offsets[i + 1]).padStart(10, "0")} 00000 n \n`),
    `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`,
  ].join("");
  chunks.push(latin1Bytes(xref));
  const blobParts: BlobPart[] = chunks.map((chunk) =>
    chunk.buffer.slice(chunk.byteOffset, chunk.byteOffset + chunk.byteLength) as ArrayBuffer,
  );
  return new Blob(blobParts, { type: "application/pdf" });
}

function topToY(top: number) {
  return PAGE_H - top;
}

function drawPageShell(page: PdfPage, pageNumber: number) {
  page.rect(0, 0, PAGE_W, PAGE_H, colors.bg);
  page.text("Trans Israel", MARGIN + 16, topToY(50), {
    size: 18,
    bold: true,
    color: colors.fg,
  });
  page.text("Gerência • Viagens • Abastecimentos", MARGIN + 16, topToY(66), {
    size: 9,
    color: colors.muted,
  });
  page.text(`Página ${pageNumber}`, PAGE_W - MARGIN - 56, topToY(50), {
    size: 9,
    color: colors.muted,
  });
  page.line(MARGIN, topToY(78), PAGE_W - MARGIN, topToY(78), colors.border, 0.7);
  page.text("Relatório gerado pelo painel Trans Israel", MARGIN, 22, {
    size: 8,
    color: colors.subtle,
  });
}

function drawHeaderCard(
  page: PdfPage,
  driverName: string,
  periodLabel: string,
  sourceLabel: string,
  generatedAt: string,
  reportTitle: string,
  operatorName: string,
) {
  const top = 92;
  const height = 104;
  const y = PAGE_H - top - height;
  page.rect(MARGIN, y, CONTENT_W, height, colors.surface, colors.border, 0.7);
  page.text(reportTitle, MARGIN + 16, topToY(top + 28), {
    size: 14,
    bold: true,
    color: colors.fg,
  });
  page.text(driverName, MARGIN + 16, topToY(top + 52), {
    size: 26,
    bold: true,
    color: colors.fg,
  });
  page.text(`Origem: ${sourceLabel}`, MARGIN + 16, topToY(top + 74), {
    size: 10,
    color: colors.muted,
  });
  page.text(`Período: ${periodLabel}`, MARGIN + 160, topToY(top + 74), {
    size: 10,
    color: colors.muted,
  });
  page.text(`Emitido em ${generatedAt}`, MARGIN + 16, topToY(top + 90), {
    size: 9,
    color: colors.subtle,
  });
  page.text(`Operador: ${operatorName}`, PAGE_W - MARGIN - 125, topToY(top + 90), {
    size: 9,
    color: colors.subtle,
  });
}

function drawMetricCard(
  page: PdfPage,
  x: number,
  top: number,
  w: number,
  h: number,
  label: string,
  value: string,
  subtitle?: string,
) {
  const y = PAGE_H - top - h;
  page.rect(x, y, w, h, colors.surface, colors.border, 0.7);
  page.text(label.toUpperCase(), x + 12, topToY(top + 18), {
    size: 8,
    color: colors.muted,
  });
  page.text(value, x + 12, topToY(top + 42), {
    size: 18,
    bold: true,
    color: colors.accent,
  });
  if (subtitle) {
    page.text(subtitle, x + 12, topToY(top + 58), {
      size: 8,
      color: colors.subtle,
    });
  }
}

export type ReportFueling = Fueling & {
  driverName: string;
  fleetName: string;
  tractorPlate: string;
  trailerPlate: string;
  kmSincePrevious: number | null;
  kmPerLiter: number | null;
};

function drawSummary(page: PdfPage, trips: ComputedTrip[], fuelings: ReportFueling[]) {
  const totalFreight = trips.reduce((a, t) => a + t.freight, 0);
  const hasFuelings = fuelings.length > 0;
  const totalDiesel = hasFuelings
    ? fuelings.reduce((a, f) => a + f.liters * f.pricePerLiter, 0)
    : trips.reduce((a, t) => a + t.dieselCost, 0);
  const totalTons = trips.reduce((a, t) => a + t.netWeight, 0);
  const totalLiters = hasFuelings
    ? fuelings.reduce((a, f) => a + f.liters, 0)
    : trips.reduce((a, t) => a + t.dieselLiters, 0);
  const totalCommissions = trips.reduce((a, t) => a + t.commissionValue, 0);
  const totalResult = totalFreight - totalDiesel;
  const totalAfter = totalResult - totalCommissions;
  const modes = freightModeBreakdown(trips);
  const consumption = fuelingConsumptionStats(fuelings.map((f) => ({
    kmSincePrevious: f.kmSincePrevious ?? null,
    liters: f.liters,
  })));

  const byFleet = new Map<string, number>();
  for (const trip of trips) byFleet.set(trip.fleetName, (byFleet.get(trip.fleetName) ?? 0) + 1);
  const fleetLine = [...byFleet.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([name, count]) => `${name}: ${count}`)
    .join(" | ");

  const gap = 10;
  const colW = (CONTENT_W - gap * 2) / 3;
  const rowH = 68;
  const top1 = 214;
  const top2 = top1 + rowH + gap;
  const top3 = top2 + rowH + gap;
  const x1 = MARGIN;
  const x2 = MARGIN + colW + gap;
  const x3 = MARGIN + (colW + gap) * 2;

  drawMetricCard(page, x1, top1, colW, rowH, "Viagens totais", String(trips.length), "quantidade no período");
  drawMetricCard(page, x2, top1, colW, rowH, "Por tonelada", `${modes.tonTripCount} viagens`, `${tons(modes.tonTons)} • ${brl(modes.tonFreight)}`);
  drawMetricCard(page, x3, top1, colW, rowH, "Diária", String(modes.tripModeCount), brl(modes.tripFreight));
  drawMetricCard(page, x1, top2, colW, rowH, "Cegonha", String(modes.cegonhaCount), brl(modes.cegonhaFreight));
  drawMetricCard(page, x2, top2, colW, rowH, "Caixinha", String(modes.caixinhaCount), brl(modes.caixinhaFreight));
  drawMetricCard(page, x3, top2, colW, rowH, "KM/L abastecimentos", consumption.kmPerLiter ? kmL(consumption.kmPerLiter) : "—", `${integer(consumption.kmDriven)} km calculados`);
  drawMetricCard(page, x1, top3, colW, rowH, "Frete total", brl(totalFreight), `${tons(totalTons)} de peso líquido`);
  drawMetricCard(page, x2, top3, colW, rowH, "Custo diesel", brl(totalDiesel), totalLiters > 0 ? `${liters(totalLiters)} no período` : "sem litros lançados");
  drawMetricCard(page, x3, top3, colW, rowH, "Após comissão", brl(totalAfter), `Resultado bruto ${brl(totalResult)}`);

  const stripTop = top3 + rowH + 14;
  page.text(`Modos por viagem: ${modes.fixedTripCount} viagens • ${brl(modes.fixedFreight)} | Viagens por caminhão: ${truncate(fleetLine || "sem viagens", 78)}`, MARGIN, topToY(stripTop), {
    size: 8.5,
    color: colors.muted,
  });
}

function drawTripSectionTitle(page: PdfPage, top: number, label = "Histórico de viagens") {
  page.text(label, MARGIN, topToY(top), {
    size: 14,
    bold: true,
    color: colors.fg,
  });
  page.text("Detalhamento das viagens do motorista", MARGIN, topToY(top + 16), {
    size: 9,
    color: colors.muted,
  });
}

function drawTripCard(page: PdfPage, trip: ComputedTrip, top: number) {
  const height = 74;
  const y = PAGE_H - top - height;
  page.rect(MARGIN, y, CONTENT_W, height, colors.surface, colors.border, 0.7);
  page.text(trip.code, MARGIN + 12, topToY(top + 20), {
    size: 14,
    bold: true,
    color: colors.accent,
  });
  page.text(formatDate(trip.date), PAGE_W - MARGIN - 70, topToY(top + 20), {
    size: 10,
    color: colors.muted,
  });

  const route = wrap(`${trip.origin || "Origem não informada"} → ${trip.destination || "Destino não informado"}`, 70, 2);
  page.text(route[0] ?? "", MARGIN + 12, topToY(top + 36), {
    size: 11,
    bold: true,
    color: colors.fg,
  });
  if (route[1]) {
    page.text(route[1], MARGIN + 12, topToY(top + 48), {
      size: 10,
      color: colors.fg,
    });
  }

  const meta = truncate(`${trip.driverName} • ${trip.fleetName} • ${freightModeLabel(trip.freightMode)}`, 78);
  const values = truncate(`Peso ${tons(trip.netWeight)} • KM ${integer(trip.kmDriven)} • Frete ${brl(trip.freight)} • Diesel ${brl(trip.dieselCost)} • Resultado ${brl(trip.grossResult)}`, 102);
  page.text(meta, MARGIN + 12, topToY(top + 60), {
    size: 8.5,
    color: colors.muted,
  });
  page.text(values, MARGIN + 12, topToY(top + 70), {
    size: 8.3,
    color: colors.ok,
  });
}

function drawFuelingSectionTitle(page: PdfPage, top: number, label = "Abastecimentos") {
  page.text(label, MARGIN, topToY(top), {
    size: 14,
    bold: true,
    color: colors.fg,
  });
  page.text("Dados registrados no controle de combustível", MARGIN, topToY(top + 16), {
    size: 9,
    color: colors.muted,
  });
}

function drawFuelingCard(page: PdfPage, fueling: ReportFueling, top: number) {
  const height = 64;
  const y = PAGE_H - top - height;
  const cost = fueling.liters * fueling.pricePerLiter;
  page.rect(MARGIN, y, CONTENT_W, height, colors.surface, colors.border, 0.7);
  page.text(formatDate(fueling.date), MARGIN + 12, topToY(top + 19), {
    size: 12,
    bold: true,
    color: colors.accent,
  });
  page.text(truncate(`${fueling.fleetName} • ${fueling.tractorPlate} • ${fueling.trailerPlate}`, 70), MARGIN + 12, topToY(top + 35), {
    size: 9,
    color: colors.fg,
  });
  page.text(truncate(`${fueling.driverName} • ${fueling.station || "Posto não informado"} • KM ${integer(fueling.km)}`, 78), MARGIN + 12, topToY(top + 49), {
    size: 8.5,
    color: colors.muted,
  });
  const consumption = fueling.kmPerLiter == null
    ? "KM/L —"
    : `KM/L ${kmL(fueling.kmPerLiter)}${fueling.kmSincePrevious != null ? ` • ${integer(fueling.kmSincePrevious)} km` : ""}`;
  page.text(`${liters(fueling.liters)} • ${brl(fueling.pricePerLiter)}/L • ${consumption} • Total ${brl(cost)}`, MARGIN + 250, topToY(top + 49), {
    size: 8.2,
    color: colors.ok,
  });
}

export async function downloadDriverReportPdf({
  driverName,
  trips,
  fuelings = [],
  advances = [],
  expenses = [],
  periodLabel,
  sourceLabel,
  reportTitle,
  operatorName,
}: {
  driverName: string;
  trips: ComputedTrip[];
  fuelings?: ReportFueling[];
  advances?: Array<{ driverId?: string | null; driverName?: string; date: string; amount: number; description?: string }>;
  expenses?: Array<{ driverId?: string | null; driverName?: string; date: string; amount: number; category?: string; description?: string; fleetName?: string; notes?: string }>;
  periodLabel?: string;
  sourceLabel?: string;
  reportTitle?: string;
  operatorName?: string;
}) {
  const { jsPDF } = await import("jspdf");
  const autoTableModule: any = await import("jspdf-autotable");
  const autoTable: any = autoTableModule.default ?? autoTableModule.autoTable;
  const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a3", compress: true });
  const blue = [0, 140, 255] as [number, number, number];
  const dark = [7, 17, 31] as [number, number, number];
  const black = [17, 17, 17] as [number, number, number];

  let resolvedOperatorName = String(operatorName ?? "").trim();
  if (!resolvedOperatorName || resolvedOperatorName.toLocaleLowerCase("pt-BR") === "admin") {
    try {
      const { getManagementSession } = await import("@/lib/management-auth");
      const session = await getManagementSession();
      if (session.authenticated && session.username) resolvedOperatorName = session.username;
    } catch {}
  }
  if (!resolvedOperatorName) resolvedOperatorName = "Gerência";

  const localIso = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  const today = new Date();
  const todayIso = localIso(today);
  const shiftedIso = (days: number) => { const d = new Date(today.getFullYear(), today.getMonth(), today.getDate()); d.setDate(d.getDate() + days); return localIso(d); };
  const sourceDates = [
    ...trips.map((item: any) => String(item.date ?? "").slice(0, 10)),
    ...fuelings.map((item: any) => String(item.date ?? "").slice(0, 10)),
    ...advances.map((item: any) => String(item.date ?? "").slice(0, 10)),
    ...expenses.map((item: any) => String(item.date ?? "").slice(0, 10)),
  ].filter((value) => /^\d{4}-\d{2}-\d{2}$/.test(value)).sort();
  const basePeriodLabel = String(periodLabel || "Período selecionado");
  const detailedPeriodLabel = (() => {
    if (/\(.*\d{2}\/\d{2}\/\d{4}.*\)/.test(basePeriodLabel)) return basePeriodLabel;
    if (/este mês|mensal/i.test(basePeriodLabel)) {
      const first = localIso(new Date(today.getFullYear(), today.getMonth(), 1));
      const last = localIso(new Date(today.getFullYear(), today.getMonth() + 1, 0));
      return `${basePeriodLabel} (${formatDate(first)} a ${formatDate(last)})`;
    }
    if (/7 dias|semanal/i.test(basePeriodLabel)) return `${basePeriodLabel} (${formatDate(shiftedIso(-6))} a ${formatDate(todayIso)})`;
    if (/30 dias/i.test(basePeriodLabel)) return `${basePeriodLabel} (${formatDate(shiftedIso(-29))} a ${formatDate(todayIso)})`;
    if (/diário|diario/i.test(basePeriodLabel)) return `${basePeriodLabel} (${formatDate(todayIso)})`;
    if (/tudo|completo/i.test(basePeriodLabel) && sourceDates.length > 0) return `${basePeriodLabel} (${formatDate(sourceDates[0])} a ${formatDate(sourceDates[sourceDates.length - 1])})`;
    return basePeriodLabel;
  })();

  const totalCommission = trips.reduce((sum, trip) => sum + Number((trip as any).commissionValue ?? (trip as any).commission ?? 0), 0);
  const totalAdvances = advances.reduce((sum, item) => sum + Number(item.amount ?? 0), 0);
  const totalFreight = trips.reduce((sum, trip) => sum + Number((trip as any).freight ?? 0), 0);
  const totalDiesel = fuelings.reduce((sum, item: any) => sum + Number(item.liters ?? 0) * Number(item.pricePerLiter ?? 0), 0);
  const totalNetRevenue = totalFreight - totalDiesel - totalCommission;
  const totalFuelings = totalDiesel;
  const totalTons = trips.reduce((sum, trip) => sum + Number((trip as any).netWeight ?? 0), 0);

  const driverTotals = new Map<string, { name: string; trips: number; billing: number; commission: number; advances: number }>();
  trips.forEach((trip: any) => {
    const name = String(trip.driverName ?? driverName ?? "Motorista").trim() || "Motorista";
    const key = String(trip.driverId ?? name);
    const current = driverTotals.get(key) ?? { name, trips: 0, billing: 0, commission: 0, advances: 0 };
    current.trips += 1;
    current.billing += Number(trip.freight ?? 0);
    current.commission += Number(trip.commissionValue ?? trip.commission ?? 0);
    driverTotals.set(key, current);
  });
  advances.forEach((advance) => {
    const name = String(advance.driverName ?? "Motorista").trim() || "Motorista";
    const key = String(advance.driverId ?? name);
    const current = driverTotals.get(key) ?? { name, trips: 0, billing: 0, commission: 0, advances: 0 };
    current.advances += Number(advance.amount ?? 0);
    driverTotals.set(key, current);
  });

  const reportDateKey = (value: any) => {
    const raw = String(value ?? "").trim();
    if (!raw) return "";
    const iso = raw.match(/^(\d{4}-\d{2}-\d{2})/);
    if (iso) return iso[1];
    const parsed = new Date(raw);
    if (Number.isNaN(parsed.getTime())) return raw;
    const y = parsed.getFullYear();
    const m = String(parsed.getMonth() + 1).padStart(2, "0");
    const d = String(parsed.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  };

  const modeLabelCompact = (mode: string) => mode === "trip" ? "Diária" : mode === "cegonha" ? "Cegonha" : mode === "caixinha" ? "Caixinha" : "Por tonelada";
  const sortedTrips = [...trips].sort((a: any, b: any) => String(a.driverName ?? "").localeCompare(String(b.driverName ?? ""), "pt-BR") || reportDateKey(a.date).localeCompare(reportDateKey(b.date)) || String(a.code ?? "").localeCompare(String(b.code ?? ""), "pt-BR", { numeric: true }));
  const rowForTrip = (trip: any) => {
    const mode = String(trip.freightMode ?? "ton");
    const details = mode === "ton"
      ? `Peso líquido: ${tons(Number(trip.netWeight ?? 0))} • Preço/t: ${brl(Number(trip.pricePerTon ?? 0))}/t`
      : mode === "trip"
        ? `Diária: ${brl(Number(trip.pricePerTrip ?? trip.freight ?? 0))}`
        : `${modeLabelCompact(mode)} • 1 frete`;
    return [formatDate(trip.date), `${String(trip.code ?? "—")} • ${modeLabelCompact(mode)}`, String(trip.driverName ?? driverName ?? "—"), details, brl(Number(trip.freight ?? 0)), brl(Number(trip.commissionValue ?? trip.commission ?? 0)), brl(Number(trip.afterCommission ?? (Number(trip.freight ?? 0) - Number(trip.commissionValue ?? trip.commission ?? 0))))];
  };
  const generalRows = sortedTrips.map(rowForTrip);
  const compactRows = (() => {
    const rows: any[][] = [];
    const grouped = new Map<string, any>();
    sortedTrips.forEach((trip: any) => {
      const mode = String(trip.freightMode ?? "ton");
      if (mode === "ton" || mode === "trip") { rows.push(rowForTrip(trip)); return; }
      const name = String(trip.driverName ?? driverName ?? "Motorista");
      const key = String(trip.driverId ?? name) + "|" + mode;
      const current = grouped.get(key) ?? { mode, name, count: 0, firstDate: reportDateKey(trip.date), lastDate: reportDateKey(trip.date), freight: 0, commission: 0, after: 0 };
      current.count += 1; const d = reportDateKey(trip.date); if (d < current.firstDate) current.firstDate = d; if (d > current.lastDate) current.lastDate = d; current.freight += Number(trip.freight ?? 0); current.commission += Number(trip.commissionValue ?? trip.commission ?? 0); current.after += Number(trip.afterCommission ?? (Number(trip.freight ?? 0) - Number(trip.commissionValue ?? trip.commission ?? 0))); grouped.set(key, current);
    });
    grouped.forEach((item) => { const dateText = item.firstDate === item.lastDate ? formatDate(item.firstDate) : `${formatDate(item.firstDate)} a ${formatDate(item.lastDate)}`; rows.push([dateText, `${modeLabelCompact(item.mode)} • ${item.count} fretes`, item.name, `${item.count} fretes`, brl(item.freight), brl(item.commission), brl(item.after)]); });
    return rows;
  })();
  const isGeneralReport = String(driverName ?? "").toLocaleLowerCase("pt-BR").includes("todos os motoristas");
  const rows = isGeneralReport ? generalRows : compactRows;

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const reportMargin = 10;
  const headerBottom = 54;
  const lightHeader = [232, 238, 244] as [number, number, number];
  const totalHighlight = [255, 247, 214] as [number, number, number];

  const drawHeader = () => {
    doc.setFillColor(255, 255, 255);
    doc.rect(0, 0, pageWidth, headerBottom, "F");
    doc.addImage(REPORT_LOGO_JPEG, "JPEG", 8, 2, 92, 47, undefined, "FAST");
    doc.setTextColor(...black);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(22);
    doc.text(driverName || "Motorista", pageWidth / 2 + 20, 15, { align: "center" });
    doc.setFontSize(18);
    doc.text(reportTitle || "Relatório operacional por motorista", pageWidth / 2 + 20, 27, { align: "center" });
    doc.setFont("helvetica", "normal");
    doc.setFontSize(16);
    doc.text(`${detailedPeriodLabel}  •  ${sourceLabel || "Relatórios"}  •  Operador: ${resolvedOperatorName}`, pageWidth / 2 + 20, 40, { align: "center" });
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.35);
    doc.line(reportMargin, 51, pageWidth - reportMargin, 51);
  };

  autoTable(doc, {
    head: [["Faturamento total", "Custo diesel", "Comissão total", "Faturamento líquido", "Fretes"]],
    body: [[brl(totalFreight), brl(totalDiesel), brl(totalCommission), brl(totalNetRevenue), String(trips.length)]],
    startY: 56,
    margin: { top: 56, right: reportMargin, bottom: 16, left: reportMargin },
    theme: "grid",
    styles: { font: "helvetica", fontSize: 16, cellPadding: 2.4, textColor: black, fillColor: [255, 255, 255], lineColor: black, lineWidth: 0.18, halign: "center", valign: "middle" },
    headStyles: { fillColor: lightHeader, textColor: black, fontStyle: "bold", fontSize: 16, halign: "center", minCellHeight: 12 },
    bodyStyles: { fillColor: totalHighlight, textColor: black, fontStyle: "bold", fontSize: 16, minCellHeight: 13 },
    columnStyles: { 0: { cellWidth: 80 }, 1: { cellWidth: 80 }, 2: { cellWidth: 80 }, 3: { cellWidth: 80 }, 4: { cellWidth: 80 } },
    didDrawPage: drawHeader,
  });
  const tripStartY = Number((doc as any).lastAutoTable?.finalY ?? 56) + 5;
  autoTable(doc, {
    head: [["Data", "Ticket / modalidade", "Motorista", "Detalhes do frete", "Frete", "Comissão", "Após comissão"]],
    body: rows,
    startY: tripStartY,
    margin: { top: 56, right: reportMargin, bottom: 16, left: reportMargin },
    theme: "grid",
    showHead: "everyPage",
    rowPageBreak: "avoid",
    styles: { font: "helvetica", fontSize: 16, cellPadding: 2.2, textColor: black, fillColor: [255, 255, 255], lineColor: black, lineWidth: 0.16, valign: "middle", overflow: "linebreak", minCellHeight: 10, halign: "center" },
    headStyles: { fillColor: lightHeader, textColor: black, fontStyle: "bold", fontSize: 16, lineColor: black, lineWidth: 0.2, halign: "center", minCellHeight: 12 },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    columnStyles: {
      0: { cellWidth: 36 }, 1: { cellWidth: 68 }, 2: { cellWidth: 66 }, 3: { cellWidth: 100 },
      4: { cellWidth: 42, fontStyle: "bold" }, 5: { cellWidth: 42, fontStyle: "bold" }, 6: { cellWidth: 46, fontStyle: "bold" },
    },
    didDrawPage: drawHeader,
  });

  const normalizeDriverName = (value: any) => String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLocaleLowerCase("pt-BR");
  const dieselByDriverName = new Map<string, number>();
  fuelings.forEach((fueling: any) => {
    const key = normalizeDriverName(fueling.driverName);
    if (!key) return;
    dieselByDriverName.set(key, (dieselByDriverName.get(key) ?? 0) + Number(fueling.liters ?? 0) * Number(fueling.pricePerLiter ?? 0));
  });
  const commissionRows = Array.from(driverTotals.values())
    .sort((a, b) => a.name.localeCompare(b.name, "pt-BR"))
    .map((item) => {
      const diesel = dieselByDriverName.get(normalizeDriverName(item.name)) ?? 0;
      return [item.name, String(item.trips), brl(item.billing), brl(item.commission), brl(diesel), brl(item.advances), brl(item.billing - item.commission - diesel)];
    });

  let summaryY = Number((doc as any).lastAutoTable?.finalY ?? 56) + 7;
  if (summaryY > pageHeight - 45) {
    doc.addPage("a3", "landscape");
    summaryY = 58;
  }

  autoTable(doc, {
    head: [["Motorista", "Fretes", "Faturamento", "Comissão", "Custo diesel", "Adiantamentos", "Faturamento líquido"]],
    body: commissionRows,
    startY: summaryY,
    margin: { top: 56, right: reportMargin, bottom: 16, left: reportMargin },
    theme: "grid",
    showHead: "everyPage",
    rowPageBreak: "avoid",
    styles: { font: "helvetica", fontSize: 16, cellPadding: 2.2, textColor: black, fillColor: [255, 255, 255], lineColor: black, lineWidth: 0.16, overflow: "linebreak", halign: "center", valign: "middle" },
    headStyles: { fillColor: lightHeader, textColor: black, fontStyle: "bold", fontSize: 16, halign: "center", lineColor: black, lineWidth: 0.2, minCellHeight: 12 },
    columnStyles: {
      0: { cellWidth: 80 }, 1: { cellWidth: 32 },
      2: { cellWidth: 60, halign: "right", fontStyle: "bold" },
      3: { cellWidth: 55, halign: "right", fontStyle: "bold" },
      4: { cellWidth: 55, halign: "right", fontStyle: "bold" },
      5: { cellWidth: 52, halign: "right" },
      6: { cellWidth: 60, halign: "right", fontStyle: "bold" },
    },
    didDrawPage: drawHeader,
  });

  const addDetailTable = (title: string, head: string[], body: any[][]) => {
    if (body.length === 0) return;
    let y = Number((doc as any).lastAutoTable?.finalY ?? 56) + 9;
    if (y > pageHeight - 42) { doc.addPage("a3", "landscape"); y = 58; }
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(...black);
    doc.text(title, pageWidth / 2, y - 3, { align: "center" });
    autoTable(doc, {
      head: [head], body, startY: y,
      margin: { top: 56, right: reportMargin, bottom: 16, left: reportMargin },
      theme: "grid", showHead: "everyPage", rowPageBreak: "avoid",
      styles: { font: "helvetica", fontSize: 16, cellPadding: 2.2, textColor: black, fillColor: [255,255,255], lineColor: black, lineWidth: 0.16, halign: "center", valign: "middle", overflow: "linebreak" },
      headStyles: { fillColor: lightHeader, textColor: black, fontStyle: "bold", fontSize: 16, halign: "center", lineColor: black },
      didDrawPage: drawHeader,
    });
  };

  addDetailTable("ABASTECIMENTOS / CUSTO DIESEL", ["Data", "Motorista", "Posto", "Litros", "Preço/L", "Custo diesel"], fuelings.map((f: any) => [formatDate(f.date), f.driverName ?? "Sem motorista", f.station ?? "—", liters(Number(f.liters ?? 0)), brl(Number(f.pricePerLiter ?? 0)), brl(Number(f.liters ?? 0) * Number(f.pricePerLiter ?? 0))]));
  addDetailTable("ADIANTAMENTOS", ["Data", "Motorista", "Descrição", "Valor"], advances.map((a: any) => [formatDate(a.date), a.driverName ?? "Motorista", a.description ?? "—", brl(Number(a.amount ?? 0))]));
  addDetailTable("DESPESAS", ["Data", "Categoria", "Descrição", "Motorista", "Valor"], expenses.map((e: any) => [formatDate(e.date), e.category ?? "Despesa", e.description ?? "—", e.driverName ?? "—", brl(Number(e.amount ?? 0))]));

  const pages = doc.getNumberOfPages();
  for (let page = 1; page <= pages; page += 1) {
    doc.setPage(page);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.setTextColor(...black);
    doc.text(`Faturamento: ${brl(totalFreight)}  •  Comissão: ${brl(totalCommission)}  •  Diesel: ${brl(totalDiesel)}  •  Líquido: ${brl(totalNetRevenue)}`, reportMargin, pageHeight - 7);
    doc.text(`Página ${page}/${pages}`, pageWidth - reportMargin, pageHeight - 7, { align: "right" });
  }

  const fileName = `relatorio-trans-salomao-${normalizeFilename(driverName) || "motorista"}.pdf`;
  const blob = doc.output("blob");
  const isAndroid = typeof navigator !== "undefined" && /Android/i.test(navigator.userAgent || "");
  let downloadStarted = false;
  let downloadUrl = "";

  // Caminho principal: download direto. Mantemos a URL viva porque Chrome/Android
  // e WebViews podem entregar o Blob ao gerenciador de downloads de forma assíncrona.
  try {
    downloadUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = downloadUrl;
    link.download = fileName;
    link.rel = "noopener";
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    downloadStarted = true;
    window.setTimeout(() => link.remove(), 60_000);
    window.setTimeout(() => URL.revokeObjectURL(downloadUrl), 120_000);
  } catch (downloadError) {
    console.warn("[pdf-report] direct download failed", downloadError);
  }

  // Fallback do próprio jsPDF.
  if (!downloadStarted) {
    try {
      doc.save(fileName);
      downloadStarted = true;
    } catch (saveError) {
      console.warn("[pdf-report] jsPDF save failed", saveError);
    }
  }

  // Em Android, tente compartilhamento de arquivo somente como fallback. Alguns
  // WebViews expõem canShare mas lançam exceção; por isso toda a checagem fica protegida.
  if (!downloadStarted && isAndroid && typeof navigator !== "undefined" && typeof navigator.share === "function") {
    try {
      const pdfFile = new File([blob], fileName, { type: "application/pdf" });
      const canSharePdf =
        typeof navigator.canShare !== "function" ||
        navigator.canShare({ files: [pdfFile] });
      if (canSharePdf) {
        await navigator.share({
          files: [pdfFile],
          title: fileName,
          text: "Relatório Trans Israel",
        });
        downloadStarted = true;
      }
    } catch (shareError) {
      const errorName = shareError instanceof Error ? shareError.name : "";
      if (errorName === "AbortError") downloadStarted = true;
      else console.warn("[pdf-report] share failed", shareError);
    }
  }

  // Último fallback: abre o PDF no visualizador do navegador.
  if (!downloadStarted) {
    const viewerUrl = doc.output("bloburl");
    try {
      const viewer = window.open(viewerUrl, "_blank");
      if (viewer) downloadStarted = true;
      else {
        window.location.href = viewerUrl;
        downloadStarted = true;
      }
      window.setTimeout(() => URL.revokeObjectURL(viewerUrl), 120_000);
    } catch (viewerError) {
      console.error("[pdf-report] viewer fallback failed", viewerError);
    }
  }

  if (!downloadStarted) {
    throw new Error("Não foi possível iniciar o download do PDF.");
  }
}
