export async function ocrDeadline<T>(operation: Promise<T>, milliseconds: number, message: string, onTimeout?: () => void) {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      operation,
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => { onTimeout?.(); reject(new Error(message)); }, milliseconds);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}
