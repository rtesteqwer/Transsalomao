export function salomaoModel() {
  return process.env.OPENAI_ASSISTANT_MODEL?.trim() || "gpt-5.6-sol";
}

export async function getSalomaoOpenAIKeys() {
  const envKey = process.env.OPENAI_API_KEY?.trim();
  return envKey ? [envKey] : [];
}
