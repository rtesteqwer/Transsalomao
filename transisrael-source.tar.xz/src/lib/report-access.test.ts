import assert from "node:assert/strict";
import { test } from "node:test";
import { reportDriverId } from "./report-access.ts";

test("management can submit for the selected driver", () => {
  assert.equal(reportDriverId({ role: "admin", driverId: null }, "selected-driver"), "selected-driver");
});

test("driver cannot submit in another driver's name", () => {
  assert.equal(reportDriverId({ role: "driver", driverId: "session-driver" }, "other-driver"), "session-driver");
});

test("missing driver identity cannot use a supplied driver ID", () => {
  assert.throws(() => reportDriverId({ role: "driver", driverId: null }, "other-driver"), /Faça login/);
});
