import { createHash } from "node:crypto";
import { getSql } from "@/lib/db";

const MAX_FAILURES = 5;
function key(scope: string, identity: string) {
  return createHash("sha256").update(scope + ":" + identity.trim().toLocaleLowerCase("pt-BR")).digest("hex");
}
export async function loginAttemptAllowed(scope: string, identity: string) {
  const sql = await getSql();
  const identityHash = key(scope, identity);
  const rows = await sql<{ blocked: boolean }>`
    select coalesce(blocked_until > now(), false) as blocked
    from auth_login_attempts where identity_hash = ${identityHash} limit 1
  `;
  return !rows[0]?.blocked;
}
export async function recordLoginFailure(scope: string, identity: string) {
  const sql = await getSql();
  const identityHash = key(scope, identity);
  await sql`
    insert into auth_login_attempts(identity_hash, window_start, failures, blocked_until, updated_at)
    values (${identityHash}, now(), 1, null, now())
    on conflict(identity_hash) do update set
      window_start = case when auth_login_attempts.window_start < now() - interval '15 minutes' then now() else auth_login_attempts.window_start end,
      failures = case when auth_login_attempts.window_start < now() - interval '15 minutes' then 1 else auth_login_attempts.failures + 1 end,
      blocked_until = case
        when (case when auth_login_attempts.window_start < now() - interval '15 minutes' then 1 else auth_login_attempts.failures + 1 end) >= ${MAX_FAILURES}
          then now() + interval '15 minutes'
        else auth_login_attempts.blocked_until
      end,
      updated_at = now()
  `;
}
export async function clearLoginFailures(scope: string, identity: string) {
  const sql = await getSql();
  const identityHash = key(scope, identity);
  await sql`delete from auth_login_attempts where identity_hash = ${identityHash}`;
}
