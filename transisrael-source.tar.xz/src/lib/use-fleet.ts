import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  acceptReports,
  deleteDriver,
  deleteExpense,
  deleteFueling,
  deleteReport,
  deleteAllTrips,
  deleteTrip,
  getFleetState,
  rejectReport,
  submitReport,
  upsertDriver,
  upsertExpense,
  upsertFleet,
  upsertFreightPrices,
  upsertFueling,
  upsertTrip,
  updatePendingReport,
} from "@/lib/api";

export const fleetKey = ["fleet"] as const;

export function useFleet(enabled = true) {
  return useQuery({
    queryKey: fleetKey,
    queryFn: () => getFleetState(),
    enabled,
    refetchInterval: enabled ? 4000 : false,
    staleTime: 2000,
  });
}

export function useFleetMutations() {
  const qc = useQueryClient();
  const invalidate = async () => {
    await qc.invalidateQueries({ queryKey: fleetKey });
    await qc.refetchQueries({ queryKey: fleetKey, type: "active" });
  };

  const driver = useMutation({
    mutationFn: (data: Parameters<typeof upsertDriver>[0]["data"]) => upsertDriver({ data }),
    onSuccess: invalidate,
  });
  const removeDriver = useMutation({
    mutationFn: (id: string) => deleteDriver({ data: { id } }),
    onSuccess: invalidate,
  });
  const fleet = useMutation({
    mutationFn: (data: Parameters<typeof upsertFleet>[0]["data"]) => upsertFleet({ data }),
    onSuccess: invalidate,
  });
  const report = useMutation({
    mutationFn: (data: Parameters<typeof submitReport>[0]["data"]) => submitReport({ data }),
    onSuccess: invalidate,
  });
  const acceptMany = useMutation({
    mutationFn: (ids: string[]) => acceptReports({ data: { ids } }),
    onSuccess: invalidate,
  });
  const reject = useMutation({
    mutationFn: (id: string) => rejectReport({ data: { id } }),
    onSuccess: invalidate,
  });
  const removeReport = useMutation({
    mutationFn: (id: string) => deleteReport({ data: { id } }),
    onSuccess: invalidate,
  });
  const editReport = useMutation({
    mutationFn: (data: Parameters<typeof updatePendingReport>[0]["data"]) => updatePendingReport({ data }),
    onSuccess: invalidate,
  });
  const trip = useMutation({
    mutationFn: (data: Parameters<typeof upsertTrip>[0]["data"]) => upsertTrip({ data }),
    onSuccess: invalidate,
  });
  const removeAllTrips = useMutation({ mutationFn: () => deleteAllTrips(), onSuccess: invalidate });
  const removeTrip = useMutation({
    mutationFn: (id: string) => deleteTrip({ data: { id } }),
    onSuccess: invalidate,
  });
  const expense = useMutation({
    mutationFn: (data: Parameters<typeof upsertExpense>[0]["data"]) => upsertExpense({ data }),
    onSuccess: invalidate,
  });
  const removeExpense = useMutation({
    mutationFn: (id: string) => deleteExpense({ data: { id } }),
    onSuccess: invalidate,
  });
  const fueling = useMutation({
    mutationFn: (data: Parameters<typeof upsertFueling>[0]["data"]) => upsertFueling({ data }),
    onSuccess: invalidate,
  });
  const freightPrices = useMutation({
    mutationFn: (data: Parameters<typeof upsertFreightPrices>[0]["data"]) =>
      upsertFreightPrices({ data }),
    onSuccess: invalidate,
  });
  const removeFueling = useMutation({
    mutationFn: (id: string) => deleteFueling({ data: { id } }),
    onSuccess: invalidate,
  });

  return {
    driver,
    removeDriver,
    fleet,
    report,
    acceptMany,
    reject,
    removeReport,
    editReport,
    trip,
    removeAllTrips,
    removeTrip,
    expense,
    removeExpense,
    fueling,
    freightPrices,
    removeFueling,
  };
}
