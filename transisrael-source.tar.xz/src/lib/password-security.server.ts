import bcrypt from "bcryptjs";
import { createHash, timingSafeEqual } from "node:crypto";

const BCRYPT_ROUNDS = 12;

function sameText(a: string, b: string) {
  const aa = Buffer.from(a);
  const bb = Buffer.from(b);
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}

export function isLegacySha256Hash(value: string) {
  return /^[a-f0-9]{64}$/i.test(value.trim());
}

export async function hashPassword(value: string) {
  if (value.length < 10) throw new Error("Use uma senha com pelo menos 10 caracteres.");
  return bcrypt.hash(value, BCRYPT_ROUNDS);
}

export async function verifyPassword(value: string, storedHash: string) {
  const stored = storedHash.trim();
  if (/^\$2[aby]\$/.test(stored)) {
    return { ok: await bcrypt.compare(value, stored), legacy: false as const };
  }
  if (isLegacySha256Hash(stored)) {
    const digest = createHash("sha256").update(value).digest("hex");
    return { ok: sameText(digest, stored.toLowerCase()), legacy: true as const };
  }
  return { ok: false, legacy: false as const };
}
