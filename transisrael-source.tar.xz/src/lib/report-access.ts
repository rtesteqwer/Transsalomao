type ReportAccess = { role: "admin" | "driver"; driverId: string | null };

export function reportDriverId(access: ReportAccess, selectedDriverId: string) {
  if (access.role === "admin" && selectedDriverId) return selectedDriverId;
  if (access.role === "driver" && access.driverId) return access.driverId;
  throw new Error("Faça login para lançar a viagem.");
}
