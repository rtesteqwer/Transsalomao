import assert from "node:assert/strict";
import { test } from "node:test";
import { ocrDeadline } from "./ocr-deadline.ts";

test("a stalled OCR releases the form and invokes cleanup", async () => {
  let stopped = false;
  await assert.rejects(ocrDeadline(new Promise(() => {}), 10, "Leitura excedeu o tempo", () => { stopped = true; }), /Leitura excedeu/);
  assert.equal(stopped, true);
});
test("worker errors are returned without waiting for the deadline", async () => {
  await assert.rejects(ocrDeadline(Promise.reject(new Error("Falha no idioma")), 1000, "timeout"), /Falha no idioma/);
});
test("successful OCR retains extracted text", async () => {
  assert.equal(await ocrDeadline(Promise.resolve("PESO LIQUIDO 23000 KG"), 1000, "timeout"), "PESO LIQUIDO 23000 KG");
});
