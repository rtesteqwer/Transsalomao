export function parseLocaleNumber(raw: string): number | null {
  const t = raw.trim().replace(/\s/g, "");
  if (!t) return null;
  const hasComma = t.includes(",");
  const hasDot = t.includes(".");
  let normalized = t;
  if (hasComma && hasDot) {
    if (t.lastIndexOf(",") > t.lastIndexOf(".")) {
      normalized = t.replace(/\./g, "").replace(",", ".");
    } else {
      normalized = t.replace(/,/g, "");
    }
  } else if (hasComma) {
    normalized = t.replace(",", ".");
  }
  const n = Number(normalized);
  return Number.isFinite(n) ? n : null;
}

export function parseLocaleNumberOrZero(raw: string): number {
  return parseLocaleNumber(raw) ?? 0;
}
