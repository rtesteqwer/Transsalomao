import type { SelectHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Select({
  className,
  children,
  ...props
}: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      className={cn(
        "flex h-12 w-full appearance-none rounded-md border border-border bg-surface bg-[length:12px] bg-[right_12px_center] bg-no-repeat px-3 pr-10 text-base text-fg outline-none",
        "bg-[url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2212%22 height=%228%22 fill=%22none%22><path d=%22M1 1.5 6 6.5 11 1.5%22 stroke=%22%238b8e96%22 stroke-width=%221.6%22 stroke-linecap=%22round%22/></svg>')]",
        "focus-visible:ring-2 focus-visible:ring-ring/60 focus-visible:border-accent/40",
        className,
      )}
      {...props}
    >
      {children}
    </select>
  );
}
