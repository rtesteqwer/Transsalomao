import type { InputHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Input({
  className,
  ...props
}: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "flex h-12 w-full rounded-md border border-border bg-surface px-3 text-base text-fg shadow-none outline-none transition-colors placeholder:text-subtle",
        "focus-visible:ring-2 focus-visible:ring-ring/60 focus-visible:border-accent/40",
        "disabled:opacity-50",
        className,
      )}
      {...props}
    />
  );
}
