import { Archive, Camera, FileText, LoaderCircle, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";

import { ShareToChatGPT } from "@/components/share-to-chatgpt";
export type FinancialDocumentResult = {
  amount: string | null;
  date: string | null;
  time: string | null;
  driverName: string | null;
  suggestedDriverId: string | null;
  suggestedDriverName: string | null;
};

type BatchPdfItem = {
  fileName: string;
  result: FinancialDocumentResult | null;
  error: string | null;
};

export function FinancialDocumentReader({
  kind,
  onRead,
}: {
  kind: "advance" | "expense";
  onRead: (reading: FinancialDocumentResult) => void;
}) {
  const fileInput = useRef<HTMLInputElement>(null);
  const pdfInput = useRef<HTMLInputElement>(null);
  const batchPdfInput = useRef<HTMLInputElement>(null);
  const zipInput = useRef<HTMLInputElement>(null);
  const cameraInput = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [fileName, setFileName] = useState("");
  const [reading, setReading] = useState<FinancialDocumentResult | null>(null);
  const [batchItems, setBatchItems] = useState<BatchPdfItem[]>([]);
  const [batchProgress, setBatchProgress] = useState("");
  const [selectedBatch, setSelectedBatch] = useState<Set<number>>(new Set());
  const [batchSaving, setBatchSaving] = useState(false);
  const [batchActionMessage, setBatchActionMessage] = useState("");
  const [error, setError] = useState("");

  async function readOne(file: File, reader: "ai" | "pdf_text") {
    const prepared = await prepareFile(file);
    const response = await fetch("/api/ler-comprovante-financeiro", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        fileName: prepared.fileName,
        mime: prepared.mime,
        base64: prepared.base64,
        kind,
        reader,
      }),
    });
    const payload: any = await response.json().catch(() => ({}));
    if (!response.ok || !payload?.ok) throw new Error(payload?.message || "Não foi possível ler o comprovante.");
    const next: FinancialDocumentResult = {
      amount: typeof payload.amount === "string" ? payload.amount : null,
      date: typeof payload.date === "string" ? payload.date : null,
      time: typeof payload.time === "string" ? payload.time : null,
      driverName: typeof payload.driverName === "string" ? payload.driverName : null,
      suggestedDriverId: typeof payload.suggestedDriverId === "string" ? payload.suggestedDriverId : null,
      suggestedDriverName: typeof payload.suggestedDriverName === "string" ? payload.suggestedDriverName : null,
    };
    if (!next.amount && !next.date && !next.time && !next.driverName && !next.suggestedDriverName) {
      throw new Error("Não consegui identificar valor, data, hora nem o recebedor deste comprovante. Confira se este é um comprovante de PIX com texto legível.");
    }
    return next;
  }

  async function handleVisibleFiles(files?: FileList | null) {
    const selected = Array.from(files || []);
    if (!selected.length) return;
    const isSingleZip = selected.length === 1 && (selected[0].type === "application/zip" || selected[0].type === "application/x-zip-compressed" || /\.zip$/i.test(selected[0].name));
    if (isSingleZip) {
      await handleZip(selected[0]);
      return;
    }
    const firstIsPdf = selected[0]?.type === "application/pdf" || /\.pdf$/i.test(selected[0]?.name || "");
    if (selected.length > 1) {
      await handlePdfBatch(selected);
      return;
    }
    await handleFile(selected[0], firstIsPdf ? "pdf_text" : "ai");
  }

  async function handleFile(file?: File | null, reader: "ai" | "pdf_text" = "ai") {
    if (!file) return;
    setBusy(true);
    setError("");
    setReading(null);
    setBatchItems([]);
    setBatchProgress("");
    setFileName(file.name || "comprovante");
    try {
      const next = await readOne(file, reader);
      setReading(next);
      onRead(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível ler o arquivo.");
    } finally {
      setBusy(false);
      if (fileInput.current) fileInput.current.value = "";
      if (pdfInput.current) pdfInput.current.value = "";
      if (batchPdfInput.current) batchPdfInput.current.value = "";
      if (zipInput.current) zipInput.current.value = "";
      if (cameraInput.current) cameraInput.current.value = "";
    }
  }

  async function handlePdfBatch(files?: FileList | File[] | null) {
    const selected = Array.from(files || []);
    if (!selected.length) return;
    setBusy(true);
    setError("");
    setReading(null);
    setBatchItems([]);
    setSelectedBatch(new Set());
    setBatchActionMessage("");
    setFileName("");
    const rows: BatchPdfItem[] = [];
    try {
      for (let index = 0; index < selected.length; index += 1) {
        const file = selected[index];
        setBatchProgress("Lendo arquivo " + (index + 1) + " de " + selected.length + ": " + (file.name || "comprovante"));
        try {
          const isPdf = file.type === "application/pdf" || /\.pdf$/i.test(file.name);
          const result = await readOne(file, isPdf ? "pdf_text" : "ai");
          rows.push({ fileName: file.name || "comprovante.pdf", result, error: null });
        } catch (err) {
          rows.push({
            fileName: file.name || "comprovante.pdf",
            result: null,
            error: err instanceof Error ? err.message : "Não foi possível ler este PDF.",
          });
        }
        setBatchItems([...rows]);
      }
      const successful = rows.filter((row) => row.result);
      if (selected.length === 1 && successful[0]?.result) {
        setReading(successful[0].result);
        onRead(successful[0].result);
      }
      if (!successful.length) {
        setError("Nenhum dos PDFs selecionados pôde ser lido automaticamente.");
      }
    } finally {
      setBusy(false);
      setBatchProgress("");
      if (batchPdfInput.current) batchPdfInput.current.value = "";
    }
  }


  async function handleZip(file?: File | null) {
    if (!file) return;
    if (!(file.type === "application/zip" || file.type === "application/x-zip-compressed" || /\.zip$/i.test(file.name))) {
      setError("Selecione um arquivo ZIP.");
      return;
    }
    if (file.size > 50_000_000) {
      setError("O ZIP deve ter no máximo 50 MB.");
      return;
    }

    setBusy(true);
    setBatchSaving(false);
    setError("");
    setReading(null);
    setBatchItems([]);
    setSelectedBatch(new Set());
    setBatchActionMessage("");
    setFileName(file.name || "comprovantes.zip");
    const rows: BatchPdfItem[] = [];

    try {
      setBatchProgress("Abrindo ZIP e procurando PDFs...");
      const { unzipSync } = await import("fflate");
      const archive = unzipSync(new Uint8Array(await file.arrayBuffer()));
      const pdfEntries = Object.entries(archive)
        .filter(([name, bytes]) => !name.startsWith("__MACOSX/") && /\.(?:pdf|jpe?g|png|webp)$/i.test(name) && bytes.length > 0);

      if (!pdfEntries.length) {
        throw new Error("Não encontrei PDF ou foto compatível dentro deste ZIP.");
      }
      if (pdfEntries.length > 100) {
        throw new Error("O ZIP possui mais de 100 arquivos compatíveis. Divida em dois ZIPs para processar.");
      }

      for (let index = 0; index < pdfEntries.length; index += 1) {
        const [entryName, bytes] = pdfEntries[index];
        const displayName = entryName.replace(/^.*[\\/]/, "") || ("comprovante-" + (index + 1));
        setBatchProgress("Lendo arquivo " + (index + 1) + " de " + pdfEntries.length + " do ZIP: " + displayName);

        if (bytes.length > 2_650_000) {
          rows.push({
            fileName: entryName,
            result: null,
            error: "PDF maior que aproximadamente 2,5 MB.",
          });
          setBatchItems([...rows]);
          continue;
        }

        try {
          const copy = new Uint8Array(bytes.length);
          copy.set(bytes);
          const mime = /\.pdf$/i.test(displayName) ? "application/pdf" : /\.png$/i.test(displayName) ? "image/png" : /\.webp$/i.test(displayName) ? "image/webp" : "image/jpeg";
          const archiveFile = new File([copy.buffer], displayName, { type: mime });
          const result = await readOne(archiveFile, mime === "application/pdf" ? "pdf_text" : "ai");
          rows.push({ fileName: entryName, result, error: null });
        } catch (err) {
          rows.push({
            fileName: entryName,
            result: null,
            error: err instanceof Error ? err.message : "Não foi possível ler este PDF do ZIP.",
          });
        }
        setBatchItems([...rows]);
      }

      const readyIndexes = rows
        .map((item, index) => ({ item, index }))
        .filter(({ item }) => isReadyForBatch(item))
        .map(({ index }) => index);

      setSelectedBatch(new Set(readyIndexes));

      if (kind !== "advance") {
        setBatchActionMessage("Arquivos lidos. Toque em Preencher no comprovante que deseja usar nesta despesa.");
        return;
      }

      if (!readyIndexes.length) {
        setBatchActionMessage("Os arquivos foram lidos, mas nenhum contém RECEBEDOR, VALOR, DATA e HORA suficientes para lançar automaticamente.");
        return;
      }

      setBatchSaving(true);
      setBatchProgress("Lançando " + readyIndexes.length + " adiantamento(s) identificados no ZIP...");
      const items = readyIndexes.map((index) => ({
        fileName: rows[index].fileName,
        sourceArchive: file.name || "comprovantes.zip",
        amount: rows[index].result!.amount,
        date: rows[index].result!.date,
        time: rows[index].result!.time,
        driverId: rows[index].result!.suggestedDriverId,
      }));

      const response = await fetch("/api/lancar-adiantamentos-pdf-lote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items }),
      });
      const payload: any = await response.json().catch(() => ({}));
      if (!response.ok || !payload?.ok) {
        throw new Error(payload?.message || "Não foi possível lançar os adiantamentos do ZIP.");
      }

      const unread = rows.length - readyIndexes.length;
      setBatchActionMessage(
        "ZIP processado: " + (payload.message || "adiantamentos lançados.") +
        (unread > 0 ? " " + unread + " arquivo(s) ficaram pendentes por falta de recebedor, valor, data ou hora." : "")
      );

      const createdCount = Array.isArray(payload.created) ? payload.created.length : 0;
      const failedCount = Array.isArray(payload.failed) ? payload.failed.length : 0;
      if (createdCount > 0 && failedCount === 0 && unread === 0) {
        window.setTimeout(() => window.location.reload(), 1200);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível processar o ZIP.");
    } finally {
      setBusy(false);
      setBatchSaving(false);
      setBatchProgress("");
      if (zipInput.current) zipInput.current.value = "";
      if (fileInput.current) fileInput.current.value = "";
    }
  }

  function isReadyForBatch(item: BatchPdfItem) {
    return !!(
      item.result &&
      item.result.amount &&
      item.result.date &&
      item.result.time &&
      item.result.suggestedDriverId
    );
  }

  function toggleBatch(index: number) {
    setSelectedBatch((current) => {
      const next = new Set(current);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  }

  function selectAllBatch() {
    const indexes = batchItems
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => isReadyForBatch(item))
      .map(({ index }) => index);
    setSelectedBatch(new Set(indexes));
  }

  async function saveSelectedBatch() {
    if (kind !== "advance") return;
    const indexes = [...selectedBatch].sort((a, b) => a - b);
    if (!indexes.length) {
      setBatchActionMessage("Selecione pelo menos um comprovante pronto.");
      return;
    }

    const items = indexes
      .map((index) => ({ index, item: batchItems[index] }))
      .filter(({ item }) => isReadyForBatch(item))
      .map(({ item }) => ({
        fileName: item.fileName,
        amount: item.result!.amount,
        date: item.result!.date,
        time: item.result!.time,
        driverId: item.result!.suggestedDriverId,
      }));

    setBatchSaving(true);
    setBatchActionMessage("");
    try {
      const response = await fetch("/api/lancar-adiantamentos-pdf-lote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items }),
      });
      const payload: any = await response.json().catch(() => ({}));
      if (!response.ok || !payload?.ok) {
        throw new Error(payload?.message || "Não foi possível lançar os adiantamentos selecionados.");
      }
      setBatchActionMessage(payload.message || "Adiantamentos selecionados lançados.");
      const failedCount = Array.isArray(payload.failed) ? payload.failed.length : 0;
      const createdCount = Array.isArray(payload.created) ? payload.created.length : 0;
      if (createdCount > 0 && failedCount === 0) {
        window.setTimeout(() => window.location.reload(), 900);
      }
    } catch (err) {
      setBatchActionMessage(err instanceof Error ? err.message : "Falha ao lançar os selecionados.");
    } finally {
      setBatchSaving(false);
    }
  }

  return (
    <div className="rounded-xl border border-border bg-surface-2 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="size-4 text-accent" />
            <p className="text-sm font-semibold">Leitor de comprovante</p>
          </div>
          <p className="mt-1 text-xs text-muted">
            {kind === "advance"
              ? "Lê Valor, Data, Hora e o Nome do Recebedor. Aceita foto, PDF, vários arquivos e ZIP; o recebedor é comparado com o cadastro e vinculado como motorista quando houver correspondência segura."
              : "Foto, PDF, vários arquivos ou ZIP pela Israel IA. Preenche Valor, Data e Hora para conferência."}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button type="button" size="sm" variant="secondary" disabled={busy} onClick={() => cameraInput.current?.click()}>
            {busy ? <LoaderCircle className="size-4 animate-spin" /> : <Camera className="size-4" />} Foto
          </Button>
          <Button type="button" size="sm" variant="secondary" disabled={busy} onClick={() => fileInput.current?.click()}>
            {busy ? <LoaderCircle className="size-4 animate-spin" /> : <Upload className="size-4" />} Foto ou arquivo(s)
          </Button>
          <Button type="button" size="sm" variant="secondary" disabled={busy} onClick={() => pdfInput.current?.click()}>
            {busy ? <LoaderCircle className="size-4 animate-spin" /> : <FileText className="size-4" />} PDF automático
          </Button>
          <Button type="button" size="sm" variant="secondary" disabled={busy} onClick={() => batchPdfInput.current?.click()}>
            {busy ? <LoaderCircle className="size-4 animate-spin" /> : <Upload className="size-4" />} Selecionar vários arquivos
          </Button>
          <Button type="button" size="sm" variant="secondary" disabled={busy || batchSaving} onClick={() => zipInput.current?.click()}>
            {busy ? <LoaderCircle className="size-4 animate-spin" /> : <Archive className="size-4" />} ZIP de arquivos
          </Button>
          <ShareToChatGPT kind={kind} />
        </div>
      </div>

      <input
        ref={fileInput}
        type="file"
        className="hidden"
        accept="application/pdf,image/jpeg,image/png,image/webp,application/zip,application/x-zip-compressed,.zip"
        multiple
        onChange={(event) => void handleVisibleFiles(event.target.files)}
      />
      <input
        ref={pdfInput}
        type="file"
        className="hidden"
        accept="application/pdf,.pdf"
        onChange={(event) => void handleFile(event.target.files?.[0], "pdf_text")}
      />
      <input
        ref={batchPdfInput}
        type="file"
        className="hidden"
        accept="application/pdf,image/jpeg,image/png,image/webp,.pdf,.jpg,.jpeg,.png,.webp"
        multiple
        onChange={(event) => void handlePdfBatch(event.target.files)}
      />
      <input
        ref={zipInput}
        type="file"
        className="hidden"
        accept="application/zip,application/x-zip-compressed,.zip"
        onChange={(event) => void handleZip(event.target.files?.[0])}
      />
      <input
        ref={cameraInput}
        type="file"
        className="hidden"
        accept="image/*"
        capture="environment"
        onChange={(event) => void handleFile(event.target.files?.[0])}
      />

      <p className="mt-2 text-[11px] text-muted">No Android, você pode selecionar fotos, PDFs, vários arquivos de uma vez ou ZIP. A Israel IA abre cada item, identifica RECEBEDOR, VALOR, DATA e HORA e, nos adiantamentos, cruza o recebedor com os motoristas cadastrados. Itens incompletos ficam para conferência e duplicados são ignorados.</p>
      {batchProgress ? <p className="mt-3 text-xs font-medium text-muted">{batchProgress}</p> : null}
      {fileName ? <p className="mt-3 truncate text-xs text-muted">{busy ? "Lendo: " : "Arquivo: "}{fileName}</p> : null}
      {error ? <p className="mt-3 rounded-lg border border-danger/30 bg-danger/5 px-3 py-2 text-xs text-danger">{error}</p> : null}
      {batchItems.length ? (
        <div className="mt-3 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs font-semibold">Arquivos processados</p>
            <p className="text-[11px] text-muted">{batchItems.filter((item) => item.result).length} de {batchItems.length} lidos</p>
          </div>
          {kind === "advance" ? (
            <div className="flex flex-wrap items-center gap-2 rounded-lg border border-border bg-surface px-3 py-2">
              <Button type="button" size="sm" variant="secondary" disabled={busy || batchSaving} onClick={selectAllBatch}>
                Selecionar todos
              </Button>
              <Button
                type="button"
                size="sm"
                disabled={busy || batchSaving || selectedBatch.size === 0}
                onClick={() => void saveSelectedBatch()}
              >
                {batchSaving ? <LoaderCircle className="size-4 animate-spin" /> : null}
                Lançar selecionados ({selectedBatch.size})
              </Button>
              {selectedBatch.size ? (
                <button type="button" className="text-xs text-muted underline" onClick={() => setSelectedBatch(new Set())}>
                  Desmarcar
                </button>
              ) : null}
            </div>
          ) : null}
          {batchActionMessage ? (
            <p className="rounded-lg border border-border bg-surface px-3 py-2 text-xs">{batchActionMessage}</p>
          ) : null}
          {batchItems.map((item, index) => (
            <div key={item.fileName + "-" + index} className="rounded-lg border border-border bg-surface px-3 py-3">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex min-w-0 flex-1 items-start gap-3">
                  {kind === "advance" && item.result ? (
                    <input
                      type="checkbox"
                      className="mt-1 size-4 shrink-0"
                      checked={selectedBatch.has(index)}
                      disabled={!isReadyForBatch(item) || batchSaving}
                      onChange={() => toggleBatch(index)}
                      aria-label={"Selecionar " + item.fileName}
                    />
                  ) : null}
                  <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-semibold">{item.fileName}</p>
                  {item.result ? (
                    <div className="mt-2 grid gap-1 text-[11px] text-muted sm:grid-cols-3">
                      <span><strong className="text-foreground">Valor:</strong> {item.result.amount ? "R$ " + item.result.amount.replace(".", ",") : "Não identificado"}</span>
                      <span><strong className="text-foreground">Data:</strong> {item.result.date || "Não identificada"}</span>
                      <span><strong className="text-foreground">Hora:</strong> {item.result.time || "Não identificada"}</span>
                      {kind === "advance" ? (
                        <span>
                          <strong className="text-foreground">Motorista:</strong>{" "}
                          {driverDisplayName(item.result)}
                        </span>
                      ) : null}
                    </div>
                  ) : (
                    <p className="mt-1 text-[11px] text-danger">{item.error || "Falha na leitura."}</p>
                  )}
                  {kind === "advance" && item.result && !item.result.suggestedDriverId ? (
                    <p className="mt-2 text-[11px] text-danger">Recebedor ainda não corresponde a um motorista cadastrado.</p>
                  ) : null}
                  </div>
                </div>
                {item.result ? (
                  <Button
                    type="button"
                    size="sm"
                    variant="secondary"
                    onClick={() => {
                      setReading(item.result);
                      onRead(item.result);
                    }}
                  >
                    Preencher
                  </Button>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      ) : null}

      {reading ? (
        <div className={"mt-3 grid gap-2 " + (kind === "advance" ? "sm:grid-cols-4" : "sm:grid-cols-3")}>
          <ReadValue label="Valor" value={reading.amount ? "R$ " + reading.amount.replace(".", ",") : "Não identificado"} />
          <ReadValue label="Data" value={reading.date || "Não identificada"} />
          <ReadValue label="Hora" value={reading.time || "Não identificada"} />
          {kind === "advance" ? (
            <ReadValue
              label="Recebedor / Motorista"
              value={driverDisplayName(reading)}
            />
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

function driverDisplayName(reading: FinancialDocumentResult) {
  if (reading.suggestedDriverName) return reading.suggestedDriverName;
  const raw = String(reading.driverName || "").trim();
  if (!raw) return "Recebedor não identificado";
  if (/[0-9@#$%*_=+{}\[\]<>\\|~^]/.test(raw)) return "Recebedor não identificado";
  const cleaned = raw.replace(/[A-Za-zÀ-ÿ\s.'’-]/g, "");
  const words = raw.match(/[A-Za-zÀ-ÿ]{2,}/g) || [];
  if (cleaned.length > Math.max(1, Math.floor(raw.length * 0.05)) || words.length < 2 || words.length > 10) {
    return "Recebedor não identificado";
  }
  return raw + " · conferir cadastro";
}

function ReadValue({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-surface px-3 py-2">
      <p className="text-[10px] uppercase tracking-[0.12em] text-muted">{label}</p>
      <p className="mt-1 text-sm font-semibold tabular">{value}</p>
    </div>
  );
}

async function prepareFile(file: File) {
  const isPdf = file.type === "application/pdf" || /\.pdf$/i.test(file.name);
  if (isPdf) {
    if (file.size > 2_650_000) throw new Error("O PDF deve ter até aproximadamente 2,5 MB.");
    return { fileName: file.name || "comprovante.pdf", mime: "application/pdf", base64: await fileToBase64(file) };
  }
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
    throw new Error("Selecione uma foto JPG, PNG, WebP ou um PDF.");
  }
  return await compressImage(file);
}

async function compressImage(file: File) {
  const dataUrl = await fileToDataUrl(file);
  const image = await loadImage(dataUrl);
  const maxSide = 1800;
  const scale = Math.min(1, maxSide / Math.max(image.naturalWidth || image.width, image.naturalHeight || image.height));
  const width = Math.max(1, Math.round((image.naturalWidth || image.width) * scale));
  const height = Math.max(1, Math.round((image.naturalHeight || image.height) * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Não foi possível preparar a foto.");
  context.drawImage(image, 0, 0, width, height);

  let quality = 0.88;
  let output = canvas.toDataURL("image/jpeg", quality);
  while (output.length > 3_400_000 && quality > 0.55) {
    quality -= 0.08;
    output = canvas.toDataURL("image/jpeg", quality);
  }
  if (output.length > 3_600_000) throw new Error("A foto continua grande demais. Recorte o comprovante e tente novamente.");
  return {
    fileName: file.name || "comprovante.jpg",
    mime: "image/jpeg",
    base64: output.split(",")[1] || "",
  };
}

function fileToDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Não foi possível abrir o arquivo."));
    reader.readAsDataURL(file);
  });
}

async function fileToBase64(file: File) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + chunk, bytes.length)));
  }
  return btoa(binary);
}

function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Não foi possível abrir a foto."));
    image.src = src;
  });
}
