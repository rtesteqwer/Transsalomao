import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { computeMetrics, lastDieselPrice, lastKmForFleet } from "@/lib/calc";
import { brl, integer, num } from "@/lib/format";
import { parseLocaleNumberOrZero } from "@/lib/parse";
import type { Driver, Fleet, FreightMode, Trip, TripBillingType } from "@/lib/types";
import { useFleet } from "@/lib/use-fleet";
import { cn } from "@/lib/utils";

import { OperationalFileReader } from "@/components/operational-file-reader";
export type TripDraft = {
  id?: string;
  code: string;
  date: string;
  client: string;
  origin: string;
  destination: string;
  driverId: string;
  fleetId: string;
  loadedTons: string;
  grossWeight: string;
  netWeight: string;
  freightMode: FreightMode;
  pricePerTon: string;
  pricePerTrip: string;
  kmStart: string;
  kmEnd: string;
  dieselLiters: string;
  dieselPrice: string;
  reportId?: string;
};

export function tripToDraft(trip: Trip): TripDraft {
  return {
    id: trip.id,
    code: trip.code,
    date: trip.date,
    client: trip.client,
    origin: trip.origin,
    destination: trip.destination,
    driverId: trip.driverId,
    fleetId: trip.fleetId,
    loadedTons: String(trip.loadedTons),
    grossWeight: String(trip.grossWeight),
    netWeight: String(trip.netWeight),
    freightMode: trip.freightMode,
    pricePerTon: String(trip.pricePerTon || ""),
    pricePerTrip: String(trip.pricePerTrip || ""),
    kmStart: String(trip.kmStart),
    kmEnd: String(trip.kmEnd),
    dieselLiters: String(trip.dieselLiters),
    dieselPrice: String(trip.dieselPrice),
  };
}

export function emptyDraft(
  drivers: Driver[],
  fleets: Fleet[],
  trips: Trip[],
  seed?: Partial<TripDraft>,
): TripDraft {
  const fleetId = seed?.fleetId ?? fleets[0]?.id ?? "";
  const last = fleetId ? lastKmForFleet(trips, fleetId) : null;
  return {
    code: "",
    date: new Date().toISOString().slice(0, 10),
    client: "",
    origin: "",
    destination: "",
    driverId: drivers[0]?.id ?? "",
    fleetId,
    loadedTons: "",
    grossWeight: "",
    netWeight: "",
    freightMode: "ton",
    pricePerTon: "",
    pricePerTrip: "",
    kmStart: last != null ? String(last) : "",
    kmEnd: "",
    dieselLiters: "",
    dieselPrice: String(lastDieselPrice(trips)),
    ...seed,
  };
}

export function TripForm({
  drivers,
  fleets,
  trips,
  initial,
  submitLabel,
  onSubmit,
  pending,
}: {
  drivers: Driver[];
  fleets: Fleet[];
  trips: Trip[];
  initial: TripDraft;
  submitLabel: string;
  pending?: boolean;
  onSubmit: (data: Parameters<typeof import("@/lib/api").upsertTrip>[0]["data"]) => Promise<void>;
}) {
  const [form, setForm] = useState<TripDraft>(initial);
  const { data: fleetState } = useFleet();
  const globalPrices = fleetState?.freightPrices ?? { trip: 0, cegonha: 0, caixinha: 0 };

  useEffect(() => {
    if (form.freightMode === "ton" || form.freightMode === "trip") return;
    const currentPrice = globalPrices[form.freightMode];
    const nextValue = currentPrice > 0 ? String(currentPrice) : "";
    setForm((current) =>
      current.pricePerTrip === nextValue
        ? current
        : { ...current, pricePerTrip: nextValue },
    );
  }, [form.freightMode, globalPrices.trip, globalPrices.cegonha, globalPrices.caixinha]);
  const set = (key: keyof TripDraft, value: string) =>
    setForm((f) => {
      const next = { ...f, [key]: value };
      if (key === "fleetId" && !f.id) {
        const last = lastKmForFleet(trips, value);
        if (last != null) next.kmStart = String(last);
      }
      if (key === "loadedTons" && !f.netWeight) next.netWeight = value;
      if (key === "netWeight" && !f.loadedTons) next.loadedTons = value;
      return next;
    });

  const driver = drivers.find((d) => d.id === form.driverId);
  const metrics = useMemo(() => {
    return computeMetrics(
      {
        freightMode: form.freightMode,
        netWeight: parseLocaleNumberOrZero(form.netWeight),
        pricePerTon: parseLocaleNumberOrZero(form.pricePerTon),
        pricePerTrip: parseLocaleNumberOrZero(form.pricePerTrip),
        kmStart: parseLocaleNumberOrZero(form.kmStart),
        kmEnd: parseLocaleNumberOrZero(form.kmEnd),
        dieselLiters: parseLocaleNumberOrZero(form.dieselLiters),
        dieselPrice: parseLocaleNumberOrZero(form.dieselPrice),
      },
      driver?.commissionPct ?? 0,
    );
  }, [form, driver]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    await onSubmit({
      id: form.id,
      reportId: form.reportId,
      code: form.code,
      date: form.date,
      client: form.client,
      origin: form.origin,
      destination: form.destination,
      driverId: form.driverId,
      fleetId: form.fleetId,
      loadedTons: parseLocaleNumberOrZero(form.loadedTons),
      grossWeight: parseLocaleNumberOrZero(form.grossWeight),
      netWeight: parseLocaleNumberOrZero(form.netWeight),
      freightMode: form.freightMode,
      pricePerTon: parseLocaleNumberOrZero(form.pricePerTon),
      pricePerTrip: parseLocaleNumberOrZero(form.pricePerTrip),
      kmStart: parseLocaleNumberOrZero(form.kmStart),
      kmEnd: parseLocaleNumberOrZero(form.kmEnd),
      dieselLiters: parseLocaleNumberOrZero(form.dieselLiters),
      dieselPrice: parseLocaleNumberOrZero(form.dieselPrice),
    });
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
      <div className="mb-4">
        <OperationalFileReader
          expectedKind="trip"
          driverId={form.driverId || null}
          fleetId={form.fleetId || null}
          title="Leitor de frete"
          description="Foto, PDF, vários arquivos ou ZIP. A Trans Israel IA extrai ticket, peso líquido, placas, motorista, rota e modalidade; quando estiver seguro, envia para o Caixa."
        />
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <Field label="Ticket">
          <Input
            value={form.code}
            onChange={(e) => set("code", e.target.value.toUpperCase())}
            required
          />
        </Field>
        <Field label="Data">
          <Input
            type="date"
            value={form.date}
            onChange={(e) => set("date", e.target.value)}
            required
          />
        </Field>
        <Field label="Empresa contratante">
          <Input
            value={form.client}
            onChange={(e) => set("client", e.target.value)}
          />
        </Field>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Origem">
          <Input
            value={form.origin}
            onChange={(e) => set("origin", e.target.value)}
          />
        </Field>
        <Field label="Descarga">
          <Input
            value={form.destination}
            onChange={(e) => set("destination", e.target.value)}
          />
        </Field>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Motorista">
          <Select
            value={form.driverId}
            onChange={(e) => set("driverId", e.target.value)}
          >
            {drivers.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Conjunto">
          <Select
            value={form.fleetId}
            onChange={(e) => set("fleetId", e.target.value)}
          >
            {fleets.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name} · {f.trailerPlate}
              </option>
            ))}
          </Select>
        </Field>
      </div>

      <div>
        <p className="mb-2 text-[11px] uppercase tracking-[0.14em] text-muted">
          Modo de frete
        </p>
        <div className="grid grid-cols-2 gap-1 rounded-lg border border-border bg-surface p-1 sm:grid-cols-4">
          {(
            [
              { key: "ton", label: "Por tonelada" },
              { key: "trip", label: "Diária" },
              { key: "cegonha", label: "Cegonha" },
              { key: "caixinha", label: "Caixinha" },
            ] as const
          ).map((opt) => (
            <button
              key={opt.key}
              type="button"
              onClick={() =>
                setForm((f) => ({
                  ...f,
                  freightMode: opt.key,
                  pricePerTrip:
                    opt.key === "ton"
                      ? ""
                      : String(
                          opt.key === "trip"
                            ? f.pricePerTrip || ""
                            : opt.key === "cegonha"
                              ? globalPrices.cegonha || ""
                              : globalPrices.caixinha || "",
                        ),
                }))
              }
              className={cn(
                "h-11 rounded-md px-3 text-sm",
                form.freightMode === opt.key
                  ? "bg-accent text-accent-fg"
                  : "text-muted hover:text-fg",
              )}
            >
              {opt.label}
            </button>
          ))}
        </div>
        <p className="mt-2 text-xs text-subtle">
          {form.freightMode === "ton"
            ? "Por tonelada: informe o preço R$/t individualmente nesta viagem."
            : form.freightMode === "cegonha"
              ? `Cegonha: valor automático definido pela Gerência (${brl(globalPrices.cegonha)}) por viagem.`
              : form.freightMode === "caixinha"
                ? `Caixinha: valor automático definido pela Gerência (${brl(globalPrices.caixinha)}) por viagem.`
                : "Diária: informe o valor da diária para esta viagem."}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Field label="Ton. carregadas">
          <Input
            inputMode="decimal"
            value={form.loadedTons}
            onChange={(e) => set("loadedTons", e.target.value)}
          />
        </Field>
        <Field label="Peso bruto (t)">
          <Input
            inputMode="decimal"
            value={form.grossWeight}
            onChange={(e) => set("grossWeight", e.target.value)}
          />
        </Field>
        <Field label="Peso líquido (t)">
          <Input
            inputMode="decimal"
            value={form.netWeight}
            onChange={(e) => set("netWeight", e.target.value)}
          />
        </Field>
        {form.freightMode !== "ton" ? (
          <Field
            label={
              form.freightMode === "trip"
                ? "Valor da diária (R$)"
                : `Preço automático — ${form.freightMode === "cegonha" ? "Cegonha" : "Caixinha"}`
            }
          >
            <Input
              inputMode="decimal"
              value={form.pricePerTrip}
              onChange={(e) => set("pricePerTrip", e.target.value)}
              placeholder="0,00"
              readOnly={form.freightMode !== "trip"}
            />
          </Field>
        ) : (
          <Field label="Preço R$/t">
            <Input
              inputMode="decimal"
              value={form.pricePerTon}
              onChange={(e) => set("pricePerTon", e.target.value)}
            />
          </Field>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Field label="KM inicial">
          <Input
            inputMode="numeric"
            value={form.kmStart}
            onChange={(e) => set("kmStart", e.target.value)}
          />
        </Field>
        <Field label="KM final">
          <Input
            inputMode="numeric"
            value={form.kmEnd}
            onChange={(e) => set("kmEnd", e.target.value)}
          />
        </Field>
        <Field label="Litros diesel">
          <Input
            inputMode="decimal"
            value={form.dieselLiters}
            onChange={(e) => set("dieselLiters", e.target.value)}
          />
        </Field>
        <Field label="Preço diesel">
          <Input
            inputMode="decimal"
            value={form.dieselPrice}
            onChange={(e) => set("dieselPrice", e.target.value)}
          />
        </Field>
      </div>

      <div className="grid grid-cols-2 gap-2 rounded-lg border border-border bg-surface-2 p-3 sm:grid-cols-3">
        <MiniStat label="KM rodados" value={integer(metrics.kmDriven)} />
        <MiniStat label="Frete" value={brl(metrics.freight)} />
        <MiniStat label="Diesel" value={brl(metrics.dieselCost)} />
        <MiniStat label="Resultado bruto" value={brl(metrics.grossResult)} />
        <MiniStat
          label="Comissão"
          value={`${num((driver?.commissionPct ?? 0) * 100, 0)}% · ${brl(metrics.commissionValue)}`}
        />
        <MiniStat
          label="Após comissão"
          value={brl(metrics.afterCommission)}
          wide
        />
      </div>

      <Button type="submit" size="lg" disabled={pending}>
        {pending ? "Salvando…" : submitLabel}
      </Button>
    </form>
  );
}

function MiniStat({
  label,
  value,
  wide,
}: {
  label: string;
  value: string;
  wide?: boolean;
}) {
  return (
    <div className={wide ? "col-span-2" : undefined}>
      <p className="text-[10px] uppercase tracking-[0.14em] text-subtle">{label}</p>
      <p className="mt-1 font-display text-lg tabular leading-none">{value}</p>
    </div>
  );
}
