import { useEffect, type ReactNode } from "react";

export function BiometricGate({ children }: { scope?: string; children: ReactNode }) {
  useEffect(() => {
    try {
      for (let i = localStorage.length - 1; i >= 0; i -= 1) {
        const key = localStorage.key(i);
        if (key?.startsWith("transisrael.biometric.")) localStorage.removeItem(key);
      }
      for (let i = sessionStorage.length - 1; i >= 0; i -= 1) {
        const key = sessionStorage.key(i);
        if (key?.startsWith("transisrael.biometric.")) sessionStorage.removeItem(key);
      }
    } catch {}
  }, []);
  return <>{children}</>;
}
