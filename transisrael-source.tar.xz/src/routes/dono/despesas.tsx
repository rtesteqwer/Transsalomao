import { createFileRoute } from "@tanstack/react-router";
import { Pencil, Plus, ReceiptText, Trash2, Truck, UserRound } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { FinancialDocumentReader } from "@/components/financial-document-reader";
import { SmartSearch, buildSmartSuggestions, smartSearchMatches } from "@/components/smart-search";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { brl, formatDate } from "@/lib/format";
import { parseLocaleNumberOrZero } from "@/lib/parse";
import type { Expense, ExpenseAssetType } from "@/lib/types";
import { useFleet, useFleetMutations } from "@/lib/use-fleet";

export const Route = createFileRoute("/dono/despesas")({ component: DespesasPage });

type Draft = Partial<Expense>;
type AssetFilter = "all" | ExpenseAssetType;

const CATEGORIES = [
  "Adiantamento",
  "Manutenção",
  "Peças",
  "Pneus",
  "Elétrica",
  "Mecânica",
  "Lavagem",
  "Documentação",
  "Seguro",
  "Pedágio",
  "Multa",
  "Outros",
] as const;

function DespesasPage() {
  const { data } = useFleet();
  const { removeExpense } = useFleetMutations();
  const [editing, setEditing] = useState<Draft | null>(null);
  const [fleetFilter, setFleetFilter] = useState("all");
  const [assetFilter, setAssetFilter] = useState<AssetFilter>("all");
  const [section, setSection] = useState<"despesas" | "adiantamentos">("despesas");
  const [search, setSearch] = useState("");

  const rows = useMemo(() => {
    let all = (data?.expenses ?? []).filter((e) => section === "adiantamentos" ? e.category === "Adiantamento" : e.category !== "Adiantamento");
    if (fleetFilter !== "all") all = all.filter((e) => e.category !== "Adiantamento" && e.fleetId === fleetFilter);
    if (assetFilter !== "all") all = all.filter((e) => e.category !== "Adiantamento" && e.assetType === assetFilter);
    all = all.filter((row) => {
      const fleet = data?.fleets.find((f) => f.id === row.fleetId);
      const driver = data?.drivers.find((d) => d.id === row.driverId);
      return smartSearchMatches(search, [row.description, row.category, row.notes, row.date, driver?.name, fleet?.name, fleet?.tractorPlate, fleet?.trailerPlate]);
    });
    return all;
  }, [data, fleetFilter, assetFilter, section, search]);

  const searchSuggestions = useMemo(() => buildSmartSuggestions(
    (data?.expenses ?? []).flatMap((row) => {
      const fleet = data?.fleets.find((f) => f.id === row.fleetId);
      const driver = data?.drivers.find((d) => d.id === row.driverId);
      return [row.description, row.category, row.notes, driver?.name, fleet?.name, fleet?.tractorPlate, fleet?.trailerPlate];
    }), search,
  ), [data, search]);

  const allExpenses = data?.expenses ?? [];
  const operating = allExpenses.filter((e) => e.category !== "Adiantamento");
  const scopedOperating = fleetFilter === "all" ? operating : operating.filter((e) => e.fleetId === fleetFilter);
  const tractorTotal = scopedOperating.filter((e) => e.assetType === "tractor").reduce((sum, e) => sum + e.amount, 0);
  const trailerTotal = scopedOperating.filter((e) => e.assetType === "trailer").reduce((sum, e) => sum + e.amount, 0);
  const advanceTotal = allExpenses.filter((e) => e.category === "Adiantamento").reduce((sum, e) => sum + e.amount, 0);
  const total = tractorTotal + trailerTotal;

  async function handleDelete(row: Expense) {
    if (!window.confirm(`Excluir “${row.description}”?`)) return;
    try {
      await removeExpense.mutateAsync(row.id);
      toast.success(row.category === "Adiantamento" ? "Adiantamento excluído." : "Despesa excluída.");
      if (editing?.id === row.id) setEditing(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Não foi possível excluir.");
    }
  }

  return (
    <div>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[11px] uppercase tracking-[0.18em] text-muted">Controle financeiro da frota</p>
          <h1 className="mt-1 font-display text-4xl font-semibold tracking-tight">Despesas</h1>
          <p className="mt-2 max-w-2xl text-sm text-muted">
            Registre gastos da frota e adiantamentos pagos aos motoristas. Adiantamentos são descontados da comissão nos relatórios.
          </p>
        </div>
        <Button onClick={() => setEditing({ date: new Date().toISOString().slice(0, 10), fleetId: section === "adiantamentos" ? null : data?.fleets[0]?.id ?? null, assetType: section === "adiantamentos" ? null : "tractor", driverId: null, category: section === "adiantamentos" ? "Adiantamento" : "Manutenção", description: "", amount: 0, notes: "" })}>
          <Plus className="size-4" /> {section === "adiantamentos" ? "Novo adiantamento" : "Nova despesa"}
        </Button>
      </div>

      <div className="mt-6 max-w-2xl">
        <SmartSearch value={search} onChange={setSearch} suggestions={searchSuggestions} placeholder="Motorista, conjunto, descrição, categoria ou placa — mínimo 3 letras" label="Pesquisar despesas e adiantamentos" />
      </div>

      <div className="mt-6 flex gap-1 rounded-lg border border-border bg-surface p-1 sm:w-fit">
        <button type="button" onClick={() => setSection("despesas")} className={`h-10 rounded-md px-4 text-sm font-semibold ${section === "despesas" ? "bg-accent text-accent-fg" : "text-muted"}`}>Despesas</button>
        <button type="button" onClick={() => setSection("adiantamentos")} className={`h-10 rounded-md px-4 text-sm font-semibold ${section === "adiantamentos" ? "bg-accent text-accent-fg" : "text-muted"}`}>Adiantamentos ({allExpenses.filter((e) => e.category === "Adiantamento").length})</button>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Metric label="Despesas operacionais" value={brl(total)} />
        <Metric label="Despesas dos cavalos" value={brl(tractorTotal)} />
        <Metric label="Despesas das carretas" value={brl(trailerTotal)} />
        <Metric label="Adiantamentos" value={brl(advanceTotal)} />
      </div>

      {section === "despesas" ? <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <Field label="Filtrar por conjunto">
          <Select value={fleetFilter} onChange={(e) => setFleetFilter(e.target.value)}>
            <option value="all">Todos os conjuntos e adiantamentos</option>
            {(data?.fleets ?? []).map((f) => <option key={f.id} value={f.id}>{f.name} · cavalo {f.tractorPlate} · carreta {f.trailerPlate}</option>)}
          </Select>
        </Field>
        <Field label="Separar por veículo">
          <Select value={assetFilter} onChange={(e) => setAssetFilter(e.target.value as AssetFilter)}>
            <option value="all">Cavalo + carreta + adiantamentos</option>
            <option value="tractor">Somente cavalo</option>
            <option value="trailer">Somente carreta</option>
          </Select>
        </Field>
      </div> : null}

      {rows.length === 0 ? (
        <div className="mt-6 rounded-xl border border-dashed border-border px-5 py-12 text-center">
          <ReceiptText className="mx-auto size-7 text-muted" />
          <p className="mt-3 text-sm text-muted">Nenhuma despesa ou adiantamento registrado neste filtro.</p>
        </div>
      ) : (
        <ul className="mt-6 grid gap-3">
          {rows.map((row) => {
            const isAdvance = row.category === "Adiantamento";
            const fleet = data?.fleets.find((f) => f.id === row.fleetId);
            const driver = data?.drivers.find((d) => d.id === row.driverId);
            const plate = row.assetType === "tractor" ? fleet?.tractorPlate : fleet?.trailerPlate;
            const assetLabel = row.assetType === "tractor" ? "Cavalo" : "Carreta";
            return (
              <li key={row.id} className="rounded-xl border border-border bg-surface p-4 sm:p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded-md border border-border bg-surface-2 px-2 py-1 text-[10px] uppercase tracking-[0.12em] text-muted">
                        {isAdvance ? "Adiantamento" : assetLabel}
                      </span>
                      {(isAdvance ? driver?.name : plate) ? <span className="text-xs text-muted">{isAdvance ? driver?.name : plate}</span> : null}
                    </div>
                    <p className="mt-2 font-display text-2xl font-semibold">{row.description}</p>
                    <p className="text-sm text-muted">
                      {[formatDate(row.date), row.transactionTime || null, isAdvance ? driver?.name : fleet?.name, row.category].filter(Boolean).join(" · ")}
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <p className="mr-1 font-display text-2xl font-semibold tabular">{brl(row.amount)}</p>
                    <Button size="sm" variant="secondary" className="px-3" onClick={() => setEditing(row)} title="Editar"><Pencil className="size-4" /></Button>
                    <Button size="sm" variant="ghost" className="px-3 text-danger" disabled={removeExpense.isPending} onClick={() => handleDelete(row)} title="Excluir"><Trash2 className="size-4" /></Button>
                  </div>
                </div>
                {isAdvance ? <p className="mt-3 border-t border-border pt-3 text-sm text-muted">Será abatido da comissão de {driver?.name ?? "este motorista"} nos relatórios.</p> : null}
                {row.notes ? <p className="mt-3 border-t border-border pt-3 text-sm text-muted">{row.notes}</p> : null}
              </li>
            );
          })}
        </ul>
      )}

      <ExpenseDialog value={editing} onClose={() => setEditing(null)} onDelete={handleDelete} />
    </div>
  );
}

function ExpenseDialog({ value, onClose, onDelete }: { value: Draft | null; onClose: () => void; onDelete: (value: Expense) => Promise<void> }) {
  const { data } = useFleet();
  const { expense } = useFleetMutations();
  const [date, setDate] = useState("");
  const [fleetId, setFleetId] = useState("");
  const [assetType, setAssetType] = useState<ExpenseAssetType>("tractor");
  const [driverId, setDriverId] = useState("");
  const [category, setCategory] = useState("Manutenção");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [transactionTime, setTransactionTime] = useState("");
  const [notes, setNotes] = useState("");

  const reset = () => {
    if (!value) return;
    setDate(value.date ?? new Date().toISOString().slice(0, 10));
    setFleetId(value.fleetId ?? data?.fleets[0]?.id ?? "");
    setAssetType(value.assetType ?? "tractor");
    setDriverId(value.driverId ?? "");
    setCategory(value.category ?? "Manutenção");
    setDescription(value.description ?? "");
    setAmount(value.amount ? String(value.amount) : "");
    setTransactionTime(value.transactionTime ?? "");
    setNotes(value.notes ?? "");
  };

  useEffect(() => { reset(); }, [value?.id, value?.date]);
  const isAdvance = category === "Adiantamento";
  const fleet = data?.fleets.find((f) => f.id === fleetId);
  const driver = data?.drivers.find((d) => d.id === driverId);

  return (
    <Dialog open={!!value} onOpenChange={(open) => (open ? reset() : onClose())}>
      {value ? (
        <DialogContent title={value.id ? "Editar despesa" : "Nova despesa"}>
          <form className="grid gap-4" onSubmit={async (e) => {
            e.preventDefault();
            if (isAdvance && !driverId) return toast.error("Escolha o motorista que recebeu o adiantamento.");
            if (!isAdvance && !fleetId) return toast.error("Escolha o conjunto da despesa.");
            try {
              await expense.mutateAsync({
                id: value.id,
                date: date || new Date().toISOString().slice(0, 10),
                transactionTime: transactionTime || null,
                fleetId: isAdvance ? null : fleetId,
                assetType: isAdvance ? null : assetType,
                driverId: isAdvance ? driverId : null,
                category,
                description: description.trim() || (isAdvance ? `Adiantamento - ${driver?.name ?? "Motorista"}` : "Despesa"),
                amount: parseLocaleNumberOrZero(amount),
                notes,
              });
              toast.success(isAdvance ? "Adiantamento salvo e vinculado ao motorista." : "Despesa salva.");
              onClose();
            } catch (err) {
              toast.error(err instanceof Error ? err.message : "Não foi possível salvar.");
            }
          }}>
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Data"><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} required /></Field>
              <Field label="Hora"><Input type="time" value={transactionTime} onChange={(e) => setTransactionTime(e.target.value)} /></Field>
              <Field label="Categoria">
                <Select value={category} onChange={(e) => setCategory(e.target.value)}>
                  {CATEGORIES.map((item) => <option key={item} value={item}>{item}</option>)}
                </Select>
              </Field>
            </div>

            {isAdvance ? (
              <div className="rounded-xl border border-border bg-surface-2 p-4">
                <Field label="Motorista que recebeu o adiantamento" hint="Obrigatório — o valor será descontado da comissão deste motorista nos relatórios">
                  <Select value={driverId} onChange={(e) => setDriverId(e.target.value)} required>
                    <option value="">Escolha o motorista</option>
                    {(data?.drivers ?? []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
                  </Select>
                </Field>
                <div className="mt-3 flex items-start gap-2 text-sm text-muted"><UserRound className="mt-0.5 size-4 shrink-0" /><span>Este lançamento não entra novamente como custo da frota. Ele aparece separado como valor já pago da comissão.</span></div>
              </div>
            ) : (
              <>
                <Field label="Conjunto cadastrado">
                  <Select value={fleetId} onChange={(e) => setFleetId(e.target.value)} required>
                    <option value="">Escolha</option>
                    {(data?.fleets ?? []).map((f) => <option key={f.id} value={f.id}>{f.name} · {f.tractorPlate} / {f.trailerPlate}</option>)}
                  </Select>
                </Field>
                <Field label="Despesa pertence a">
                  <div className="grid grid-cols-2 gap-2">
                    <button type="button" onClick={() => setAssetType("tractor")} className={`rounded-lg border px-3 py-3 text-left ${assetType === "tractor" ? "border-accent bg-surface-2 text-fg" : "border-border text-muted"}`}><span className="block text-sm font-medium">Cavalo</span><span className="mt-1 block text-xs">{fleet?.tractorPlate ?? "Placa do cavalo"}</span></button>
                    <button type="button" onClick={() => setAssetType("trailer")} className={`rounded-lg border px-3 py-3 text-left ${assetType === "trailer" ? "border-accent bg-surface-2 text-fg" : "border-border text-muted"}`}><span className="block text-sm font-medium">Carreta</span><span className="mt-1 block text-xs">{fleet?.trailerPlate ?? "Placa da carreta"}</span></button>
                  </div>
                </Field>
              </>
            )}

            <FinancialDocumentReader
              kind={isAdvance ? "advance" : "expense"}
              onRead={(result) => {
                if (result.amount) setAmount(result.amount.replace(".", ","));
                setDate(result.date || "");
                setTransactionTime(result.time || "");
                if (isAdvance && result.suggestedDriverId) setDriverId(result.suggestedDriverId);
                toast.success(isAdvance && result.suggestedDriverName ? "Valor, data/hora do PDF e motorista vinculados para conferência." : "Valor e data/hora do PDF preenchidos para conferência.");
              }}
            />
            <Field label={isAdvance ? "Descrição do adiantamento" : "Descrição da despesa"}><Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder={isAdvance ? "Ex.: adiantamento semanal" : "Ex.: troca de pneu, peça, oficina..."} /></Field>
            <Field label="Valor (R$)"><Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0,00" required /></Field>
            <Field label="Observação"><Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Opcional" /></Field>

            <div className="flex flex-wrap gap-2">
              <Button type="submit" disabled={expense.isPending}>{value.id ? <Pencil className="size-4" /> : <Plus className="size-4" />}{value.id ? "Salvar alterações" : isAdvance ? "Salvar adiantamento" : "Salvar despesa"}</Button>
              {value.id ? <Button type="button" variant="ghost" className="text-danger" onClick={() => onDelete(value as Expense)}><Trash2 className="size-4" /> Excluir</Button> : null}
            </div>
          </form>
        </DialogContent>
      ) : null}
    </Dialog>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="rounded-lg border border-border bg-surface p-4"><p className="text-[10px] uppercase tracking-[0.14em] text-muted">{label}</p><p className="mt-2 font-display text-2xl font-semibold tabular">{value}</p></div>;
}
