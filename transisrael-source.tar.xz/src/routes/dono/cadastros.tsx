import { createFileRoute } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { maskPhone, maskPlate, pct } from "@/lib/format";
import { parseLocaleNumberOrZero } from "@/lib/parse";
import type { Driver, Fleet, FreightPrices } from "@/lib/types";
import { useFleet, useFleetMutations } from "@/lib/use-fleet";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/dono/cadastros")({
  component: CadastrosPage,
});

function CadastrosPage() {
  const { data } = useFleet();
  const { removeDriver } = useFleetMutations();
  const [tab, setTab] = useState<"motoristas" | "conjuntos" | "fretes">("motoristas");
  const [driver, setDriver] = useState<Partial<Driver> | null>(null);
  const [fleet, setFleet] = useState<Partial<Fleet> | null>(null);

  return (
    <div>
      <p className="text-[11px] uppercase tracking-[0.18em] text-muted">
        Cadastros
      </p>
      <h1 className="mt-1 font-display text-4xl font-semibold tracking-tight">
        Frota
      </h1>
      <p className="mt-2 max-w-xl text-sm text-muted">
        Motoristas e conjuntos ativos aparecem no app da cabine.
      </p>

      <div className="mt-6 flex w-full flex-wrap gap-1 rounded-lg border border-border bg-surface p-1 sm:w-fit">
        {(
          [
            ["motoristas", "Motoristas"],
            ["conjuntos", "Conjuntos"],
            ["fretes", "Preços frete"],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className={cn(
              "h-9 flex-1 rounded-md px-3 text-sm sm:flex-none sm:px-4",
              tab === key ? "bg-accent text-accent-fg" : "text-muted",
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "motoristas" ? (
        <section className="mt-6">
          <div className="flex justify-end">
            <Button
              onClick={() =>
                setDriver({
                  name: "",
                  phone: "",
                  category: "E",
                  status: "ativo",
                  commissionPct: 0.1,
                })
              }
            >
              Novo motorista
            </Button>
          </div>
          <ul className="mt-4 grid gap-3">
            {(data?.drivers ?? []).map((d) => (
              <li
                key={d.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-surface px-4 py-4"
              >
                <div>
                  <p className="font-display text-xl font-semibold">{d.name}</p>
                  <p className="text-sm text-muted">
                    CNH {d.category} · {d.phone || "sem telefone"} · comissão{" "}
                    {pct(d.commissionPct)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge tone={d.status === "ativo" ? "ok" : "default"}>
                    {d.status}
                  </Badge>
                  <Button size="sm" variant="secondary" onClick={() => setDriver(d)}>
                    Editar
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-danger"
                    aria-label={`Excluir ${d.name}`}
                    disabled={removeDriver.isPending}
                    onClick={async () => {
                      if (!window.confirm(`Excluir o motorista ${d.name}?`)) return;
                      try {
                        await removeDriver.mutateAsync(d.id);
                        toast.success("Motorista excluído.");
                      } catch (err) {
                        toast.error(err instanceof Error ? err.message : "Não foi possível excluir o motorista.");
                      }
                    }}
                  >
                    <Trash2 className="size-4" />
                    Excluir
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </section>
      ) : tab === "conjuntos" ? (
        <section className="mt-6">
          <div className="flex justify-end">
            <Button
              onClick={() =>
                setFleet({
                  name: "",
                  tractorPlate: "",
                  trailerPlate: "",
                  model: "",
                  status: "ativo",
                })
              }
            >
              Novo conjunto
            </Button>
          </div>
          <ul className="mt-4 grid gap-3">
            {(data?.fleets ?? []).map((f) => (
              <li
                key={f.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-surface px-4 py-4"
              >
                <div>
                  <p className="font-display text-xl font-semibold">{f.name}</p>
                  <p className="text-sm text-muted">
                    Cavalo {f.tractorPlate} · Carreta {f.trailerPlate}
                    {f.model ? ` · ${f.model}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge tone={f.status === "ativo" ? "ok" : "default"}>
                    {f.status}
                  </Badge>
                  <Button size="sm" variant="secondary" onClick={() => setFleet(f)}>
                    Editar
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </section>
      ) : (
        <FreightPricesPanel current={data?.freightPrices} />
      )}

      <DriverDialog value={driver} onClose={() => setDriver(null)} />
      <FleetDialog value={fleet} onClose={() => setFleet(null)} />
    </div>
  );
}

function FreightPricesPanel({
  current,
}: {
  current?: FreightPrices;
}) {
  const { freightPrices } = useFleetMutations();
  const [tripPrice, setTripPrice] = useState("");
  const [cegonha, setCegonha] = useState("");
  const [caixinha, setCaixinha] = useState("");

  useEffect(() => {
    if (!current) return;
    setTripPrice(current.trip > 0 ? String(current.trip) : "");
    setCegonha(current.cegonha > 0 ? String(current.cegonha) : "");
    setCaixinha(current.caixinha > 0 ? String(current.caixinha) : "");
  }, [current?.trip, current?.cegonha, current?.caixinha]);

  return (
    <section className="mt-6 max-w-3xl">
      <div className="rounded-xl border border-accent bg-surface p-5">
        <p className="text-[11px] uppercase tracking-[0.16em] text-muted">
          Valores automáticos
        </p>
        <h2 className="mt-1 font-display text-2xl font-semibold">
          Preços por viagem
        </h2>
        <p className="mt-2 text-sm text-muted">
          Defina os valores globais de Por viagem, Cegonha e Caixinha. O preço
          por tonelada é informado individualmente em cada viagem. Ao salvar, as
          viagens antigas desses modos também são atualizadas em painel, PDF e Excel.
        </p>

        <form
          className="mt-5 grid gap-4"
          onSubmit={async (e) => {
            e.preventDefault();
            const next = {
              trip: parseLocaleNumberOrZero(tripPrice),
              cegonha: parseLocaleNumberOrZero(cegonha),
              caixinha: parseLocaleNumberOrZero(caixinha),
            };
            if (next.trip <= 0 || next.cegonha <= 0 || next.caixinha <= 0) {
              toast.error("Informe valores maiores que zero para Por viagem, Cegonha e Caixinha.");
              return;
            }
            try {
              await freightPrices.mutateAsync(next);
              toast.success("Preços de Por viagem, Cegonha e Caixinha atualizados em todo o sistema.");
            } catch (err) {
              toast.error(
                err instanceof Error
                  ? err.message
                  : "Não foi possível atualizar os preços de frete.",
              );
            }
          }}
        >
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Por viagem — valor (R$)">
              <Input
                inputMode="decimal"
                value={tripPrice}
                onChange={(e) => setTripPrice(e.target.value)}
                placeholder="0,00"
              />
            </Field>
            <Field label="Cegonha — valor por viagem (R$)">
              <Input
                inputMode="decimal"
                value={cegonha}
                onChange={(e) => setCegonha(e.target.value)}
                placeholder="0,00"
              />
            </Field>
            <Field label="Caixinha — valor por viagem (R$)">
              <Input
                inputMode="decimal"
                value={caixinha}
                onChange={(e) => setCaixinha(e.target.value)}
                placeholder="0,00"
              />
            </Field>
          </div>

          <div className="rounded-lg border border-border bg-bg px-4 py-3 text-sm text-muted">
            <strong className="text-fg">Atualização automática:</strong>{" "}
            alterar Por viagem, Cegonha ou Caixinha recalcula também as viagens
            já lançadas desses modos. Por tonelada permanece individual por viagem.
          </div>

          <div className="flex justify-end">
            <Button type="submit" disabled={freightPrices.isPending}>
              {freightPrices.isPending ? "Atualizando…" : "Salvar preços"}
            </Button>
          </div>
        </form>
      </div>
    </section>
  );
}

function DriverDialog({
  value,
  onClose,
}: {
  value: Partial<Driver> | null;
  onClose: () => void;
}) {
  const { driver } = useFleetMutations();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [category, setCategory] = useState("E");
  const [status, setStatus] = useState<"ativo" | "inativo">("ativo");
  const [commission, setCommission] = useState("10");

  useEffect(() => {
    if (!value) return;
    setName(value.name ?? "");
    setPhone(value.phone ?? "");
    setCategory(value.category ?? "E");
    setStatus(value.status ?? "ativo");
    setCommission(String(Math.round((value.commissionPct ?? 0.1) * 100)));
  }, [value]);

  const open = !!value;
  const key = value?.id ?? "new-driver";

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) onClose();
        else if (value) {
          setName(value.name ?? "");
          setPhone(value.phone ?? "");
          setCategory(value.category ?? "E");
          setStatus(value.status ?? "ativo");
          setCommission(String(((value.commissionPct ?? 0.1) * 100).toFixed(0)));
        }
      }}
    >
      <DialogContent title={value?.id ? "Editar motorista" : "Novo motorista"} key={key}>
        <form
          className="flex flex-col gap-4"
          onSubmit={async (e) => {
            e.preventDefault();
            await driver.mutateAsync({
              id: value?.id,
              name,
              phone,
              category,
              status,
              commissionPct: parseLocaleNumberOrZero(commission) / 100,
            });
            toast.success("Motorista salvo.");
            onClose();
          }}
        >
          <Field label="Nome">
            <Input value={name} onChange={(e) => setName(e.target.value)} required />
          </Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Telefone">
              <Input
                value={phone}
                onChange={(e) => setPhone(maskPhone(e.target.value))}
              />
            </Field>
            <Field label="Categoria CNH">
              <Input
                value={category}
                onChange={(e) => setCategory(e.target.value.toUpperCase())}
              />
            </Field>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Comissão %">
              <Input
                inputMode="decimal"
                value={commission}
                onChange={(e) => setCommission(e.target.value)}
              />
            </Field>
            <Field label="Status">
              <Select
                value={status}
                onChange={(e) => setStatus(e.target.value as "ativo" | "inativo")}
              >
                <option value="ativo">Ativo</option>
                <option value="inativo">Inativo</option>
              </Select>
            </Field>
          </div>
          <Button type="submit" disabled={driver.isPending}>
            Salvar
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function FleetDialog({
  value,
  onClose,
}: {
  value: Partial<Fleet> | null;
  onClose: () => void;
}) {
  const { fleet } = useFleetMutations();
  const [name, setName] = useState("");
  const [tractor, setTractor] = useState("");
  const [trailer, setTrailer] = useState("");
  const [model, setModel] = useState("");
  const [status, setStatus] = useState<"ativo" | "inativo">("ativo");
  const key = value?.id ?? "new-fleet";

  useEffect(() => {
    if (!value) return;
    setName(value.name ?? "");
    setTractor(value.tractorPlate ?? "");
    setTrailer(value.trailerPlate ?? "");
    setModel(value.model ?? "");
    setStatus(value.status ?? "ativo");
  }, [value]);

  return (
    <Dialog
      open={!!value}
      onOpenChange={(v) => {
        if (!v) onClose();
        else if (value) {
          setName(value.name ?? "");
          setTractor(value.tractorPlate ?? "");
          setTrailer(value.trailerPlate ?? "");
          setModel(value.model ?? "");
          setStatus(value.status ?? "ativo");
        }
      }}
    >
      <DialogContent title={value?.id ? "Editar conjunto" : "Novo conjunto"} key={key}>
        <form
          className="flex flex-col gap-4"
          onSubmit={async (e) => {
            e.preventDefault();
            await fleet.mutateAsync({
              id: value?.id,
              name,
              tractorPlate: tractor,
              trailerPlate: trailer,
              model,
              status,
            });
            toast.success("Conjunto salvo.");
            onClose();
          }}
        >
          <Field label="Nome do conjunto">
            <Input value={name} onChange={(e) => setName(e.target.value)} required />
          </Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Placa do cavalo">
              <Input
                value={tractor}
                onChange={(e) => setTractor(maskPlate(e.target.value))}
                required
              />
            </Field>
            <Field label="Placa da carreta">
              <Input
                value={trailer}
                onChange={(e) => setTrailer(maskPlate(e.target.value))}
                required
              />
            </Field>
          </div>
          <Field label="Tipo / modelo">
            <Input value={model} onChange={(e) => setModel(e.target.value)} />
          </Field>
          <Field label="Status">
            <Select
              value={status}
              onChange={(e) => setStatus(e.target.value as "ativo" | "inativo")}
            >
              <option value="ativo">Ativo</option>
              <option value="inativo">Inativo</option>
            </Select>
          </Field>
          <Button type="submit" disabled={fleet.isPending}>
            Salvar
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
