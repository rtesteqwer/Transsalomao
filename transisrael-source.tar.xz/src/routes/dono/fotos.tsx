import { DataIntegrityPanel } from "@/components/data-integrity-panel";
import { createFileRoute } from "@tanstack/react-router";
import { Camera, ImagePlus, Link2, LoaderCircle, RotateCcw, Trash2, X, ZoomIn, ZoomOut } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { MonthlyOperationImport } from "@/components/monthly-operation-import";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { useFleet } from "@/lib/use-fleet";

export const Route = createFileRoute("/dono/fotos")({ component: FotosTicketsPage });

type RelationKind = "trip" | "report" | "unlinked";

type SourceItem = {
  key: string;
  relationType: RelationKind;
  relationId: string;
  code: string;
  driverId: string;
  driverName: string;
  fleetId: string;
  fleetName: string;
  date: string;
  freightMode: string | null;
  netWeight: number | null;
  status: string | null;
};

type ReadTicketData = {
  numero_ticket?: string | null;
  peso_liquido_kg?: number | null;
  data_ticket?: string | null;
  placa_veiculo?: string | null;
  placa_carreta?: string | null;
  placas_detectadas?: string[];
  motorista?: string | null;
  transportadora?: string | null;
  contratante?: string | null;
  destinatario?: string | null;
  produto?: string | null;
  alertas?: string[];
  memory_driver_id?: string | null;
  memory_fleet_id?: string | null;
  memory_match_confidence?: number | null;
};

type BatchPhotoResult = {
  id: string;
  fileName: string;
  imageData: string;
  photoId: string;
  ticket: ReadTicketData | null;
  linked: boolean;
  caixaCreated: boolean;
  note: string;
  error: string;
};

type SavedPhoto = {
  id: string;
  relationType: RelationKind;
  relationId: string;
  tripCode: string;
  driverName: string | null;
  fleetName: string | null;
  tripDate: string | null;
  freightMode: string | null;
  netWeight: number | null;
  fileName: string;
  createdAt: string;
  createdBy: string | null;
};

function tons(value: number | null | undefined) {
  if (value == null || !Number.isFinite(Number(value)) || Number(value) <= 0) return "—";
  return new Intl.NumberFormat("pt-BR", { minimumFractionDigits: 3, maximumFractionDigits: 3 }).format(Number(value)) + " t";
}

function shortDate(value: string | null | undefined) {
  if (!value) return "—";
  const iso = value.slice(0, 10);
  const parts = iso.split("-");
  return parts.length === 3 ? parts[2] + "/" + parts[1] + "/" + parts[0] : iso;
}

function modeLabel(value: string | null | undefined) {
  return value === "ton" ? "Por tonelada" : value === "trip" ? "Diária" : value === "cegonha" ? "Cegonha" : value === "caixinha" ? "Caixinha" : "A definir";
}

async function imageToDataUrl(file: File) {
  const looksLikeImage = file.type.startsWith("image/") || /\.(jpe?g|png|webp|heic|heif)$/i.test(file.name || "");
  if (!looksLikeImage) throw new Error("Selecione uma foto válida.");
  if (file.size > 30_000_000) throw new Error("A foto deve ter no máximo 30 MB.");

  const encode = (source: CanvasImageSource, width: number, height: number) => {
    const maxSides = [1600, 1400, 1200, 1000, 800];
    for (const maxSide of maxSides) {
      const scale = Math.min(1, maxSide / Math.max(width, height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(width * scale));
      canvas.height = Math.max(1, Math.round(height * scale));
      const ctx = canvas.getContext("2d");
      if (!ctx) continue;
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
      for (const quality of [0.84, 0.76, 0.68, 0.60, 0.52, 0.44]) {
        const out = canvas.toDataURL("image/jpeg", quality);
        if (out.length <= 2_700_000) return out;
      }
    }
    throw new Error("Não foi possível reduzir a foto para envio.");
  };

  try {
    if (typeof createImageBitmap === "function") {
      const bitmap = await createImageBitmap(file);
      try {
        return encode(bitmap, bitmap.width, bitmap.height);
      } finally {
        bitmap.close();
      }
    }
  } catch {}

  const objectUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("Não foi possível abrir esta foto no celular."));
      image.src = objectUrl;
    });
    return encode(img, img.naturalWidth || img.width, img.naturalHeight || img.height);
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

function FotosTicketsPage() {
  const { data } = useFleet();
  const [sourceKey, setSourceKey] = useState("");
  const [search, setSearch] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [batchResults, setBatchResults] = useState<BatchPhotoResult[]>([]);
  const [batchProgress, setBatchProgress] = useState({ done: 0, total: 0 });
  const [busy, setBusy] = useState(false);
  const [loadingSaved, setLoadingSaved] = useState(true);
  const [savedPhotos, setSavedPhotos] = useState<SavedPhoto[]>([]);
  const [viewerPhoto, setViewerPhoto] = useState<SavedPhoto | null>(null);

  const sources = useMemo<SourceItem[]>(() => {
    if (!data) return [];
    const drivers = data.drivers ?? [];
    const fleets = data.fleets ?? [];
    const driverName = (id: string) => drivers.find((d) => d.id === id)?.name ?? "Motorista";
    const fleetName = (id: string) => fleets.find((f) => f.id === id)?.name ?? "Conjunto";

    const reports: SourceItem[] = (data.reports ?? []).map((r) => ({
      key: "report:" + r.id,
      relationType: "report",
      relationId: r.id,
      code: String(r.ticket ?? r.id),
      driverId: r.driverId,
      driverName: driverName(r.driverId),
      fleetId: r.fleetId,
      fleetName: fleetName(r.fleetId),
      date: String(r.createdAt ?? "").slice(0, 10),
      freightMode: r.freightMode ?? null,
      netWeight: Number(r.tons ?? 0) || null,
      status: r.status ?? null,
    }));

    const trips: SourceItem[] = (data.trips ?? []).map((t) => ({
      key: "trip:" + t.id,
      relationType: "trip",
      relationId: t.id,
      code: String(t.code ?? t.id),
      driverId: t.driverId,
      driverName: driverName(t.driverId),
      fleetId: t.fleetId,
      fleetName: fleetName(t.fleetId),
      date: String(t.date ?? "").slice(0, 10),
      freightMode: t.freightMode ?? null,
      netWeight: Number(t.netWeight ?? 0) || null,
      status: "fechada",
    }));

    return [...reports, ...trips].sort((a, b) => b.date.localeCompare(a.date) || b.code.localeCompare(a.code));
  }, [data]);

  const visibleSources = useMemo(() => {
    const q = search.trim().toLocaleLowerCase("pt-BR");
    if (!q) return sources;
    return sources.filter((s) => [s.code, s.driverName, s.fleetName, s.date, s.status, modeLabel(s.freightMode)]
      .some((value) => String(value ?? "").toLocaleLowerCase("pt-BR").includes(q)));
  }, [sources, search]);

  const selected = sources.find((s) => s.key === sourceKey) ?? null;
  const pendingSources = visibleSources.filter((s) => s.relationType === "report");
  const tripSources = visibleSources.filter((s) => s.relationType === "trip");

  async function loadSaved() {
    try {
      setLoadingSaved(true);
      const response = await fetch("/api/photo-intake", { credentials: "same-origin", cache: "no-store" });
      const result = await response.json().catch(() => ({ ok: false, message: "Resposta inválida do servidor." }));
      if (!response.ok) throw new Error(result?.message || "Não foi possível carregar as fotos.");
      setSavedPhotos(Array.isArray(result.photos) ? result.photos : []);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível carregar as fotos.");
    } finally {
      setLoadingSaved(false);
    }
  }

  useEffect(() => {
    void loadSaved();
  }, []);

  function normalizeMatchText(value: unknown) {
    return String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  }

  function ticketDateIso(value: unknown) {
    const raw = String(value ?? "").trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
    const match = raw.match(/^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})$/);
    return match ? match[3] + "-" + match[2].padStart(2, "0") + "-" + match[1].padStart(2, "0") : "";
  }

  async function readTicketImage(imageData: string, fileName: string, attempt = 0): Promise<ReadTicketData> {
    const response = await fetch("/api/ler-ticket", {
      method: "POST",
      credentials: "same-origin",
      signal: AbortSignal.timeout(45_000),
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ imagem: imageData, tipo: imageData.match(/^data:([^;]+);/)?.[1] || "image/jpeg", freightMode: "ton", fileName }),
    });
    if (response.status === 429 && attempt < 6) { await new Promise((resolve) => setTimeout(resolve, 61_000)); return readTicketImage(imageData, fileName, attempt + 1); }
    const result = await response.json().catch(() => ({ erro: "Resposta inválida do servidor." }));
    if (!response.ok) throw new Error(result?.erro || "O ChatGPT não conseguiu interpretar a foto.");
    return result as ReadTicketData;
  }

  function automaticSource(ticket: ReadTicketData) {
    const ticketNumber = normalizeMatchText(ticket.numero_ticket);
    const date = ticketDateIso(ticket.data_ticket);
    const kg = Number(ticket.peso_liquido_kg || 0);
    const ticketTons = kg > 0 ? kg / 1000 : 0;
    if (ticketNumber && kg > 0) {
      const sameNumber = sources.filter((source) => normalizeMatchText(source.code) === ticketNumber);
      if (sameNumber.length > 0) {
        const exact = sameNumber.filter((source) => source.netWeight != null && Math.round(Number(source.netWeight) * 1000) === kg);
        if (exact.length === 1) return exact[0];
        return null;
      }
    }
    const plateSet = new Set([ticket.placa_veiculo, ticket.placa_carreta, ...(ticket.placas_detectadas ?? [])].map(normalizeMatchText).filter(Boolean));
    const driverText = normalizeMatchText(ticket.motorista);
    const ranked = sources.map((source) => {
      let score = 0;
      if (date && source.date === date) score += 25;
      if (ticketTons > 0 && source.netWeight != null && Math.round(Number(source.netWeight) * 1000) === kg) score += 50;
      if (driverText && (driverText.includes(normalizeMatchText(source.driverName)) || normalizeMatchText(source.driverName).includes(driverText))) score += 20;
      const fleet = (data?.fleets ?? []).find((item) => item.id === source.fleetId);
      if (fleet && plateSet.size) {
        const tractor = normalizeMatchText(fleet.tractorPlate);
        const trailer = normalizeMatchText(fleet.trailerPlate);
        if ((tractor && plateSet.has(tractor)) || (trailer && plateSet.has(trailer))) score += 50;
      }
      return { source, score };
    }).sort((a, b) => b.score - a.score);
    const best = ranked[0];
    const second = ranked[1];
    if (!best || best.score < 80) return null;
    if (second && second.score >= best.score - 15) return null;
    return best.source;
  }

  function resolveDriverAndFleet(ticket: ReadTicketData) {
    const drivers = (data?.drivers ?? []).filter((item) => item.status === "ativo");
    const fleets = (data?.fleets ?? []).filter((item) => item.status === "ativo");
    const driverText = normalizeMatchText(ticket.motorista);
    const plates = new Set([ticket.placa_veiculo, ticket.placa_carreta, ...(ticket.placas_detectadas ?? [])].map(normalizeMatchText).filter(Boolean));
    let driver = null as (typeof drivers)[number] | null;
    let fleet = null as (typeof fleets)[number] | null;

    if (driverText) {
      const exact = drivers.filter((item) => normalizeMatchText(item.name) === driverText);
      const similar = exact.length ? exact : drivers.filter((item) => { const name = normalizeMatchText(item.name); return name && (driverText.includes(name) || name.includes(driverText)); });
      if (similar.length === 1) driver = similar[0];
    }
    if (plates.size) {
      const matches = fleets.filter((item) => {
        const tractor = normalizeMatchText(item.tractorPlate);
        const trailer = normalizeMatchText(item.trailerPlate);
        return (tractor && plates.has(tractor)) || (trailer && plates.has(trailer));
      });
      if (matches.length === 1) fleet = matches[0];
    }

    if (driver && !fleet) {
      const ids = [...new Set(sources.filter((source) => source.driverId === driver!.id).map((source) => source.fleetId).filter(Boolean))];
      const candidates = fleets.filter((item) => ids.includes(item.id));
      if (candidates.length === 1) fleet = candidates[0];
    }
    if (fleet && !driver) {
      const ids = [...new Set(sources.filter((source) => source.fleetId === fleet!.id).map((source) => source.driverId).filter(Boolean))];
      const candidates = drivers.filter((item) => ids.includes(item.id));
      if (candidates.length === 1) driver = candidates[0];
    }
    const memoryConfidence = Number(ticket.memory_match_confidence || 0);
    if (memoryConfidence >= 0.86) {
      if (!driver && ticket.memory_driver_id) driver = drivers.find((item) => item.id === ticket.memory_driver_id) ?? null;
      if (!fleet && ticket.memory_fleet_id) fleet = fleets.find((item) => item.id === ticket.memory_fleet_id) ?? null;
    }
    return driver && fleet ? { driver, fleet } : null;
  }

  async function createPendingCaixa(ticket: ReadTicketData, imageData: string, fileName: string, photoId: string) {
    const ticketNumber = String(ticket.numero_ticket || "").trim();
    const weightKg = Number(ticket.peso_liquido_kg || 0);
    if (!ticketNumber) return { source: null as SourceItem | null, note: "Foto salva, mas o número do ticket não ficou legível para lançar no Caixa." };
    if (!Number.isSafeInteger(weightKg) || weightKg <= 0) return { source: null as SourceItem | null, note: "Foto salva, mas o peso líquido precisa estar legível para lançar no Caixa." };
    const sameNumber = sources.filter((source) => normalizeMatchText(source.code) === normalizeMatchText(ticketNumber));
    if (sameNumber.length > 0 && !sameNumber.some((source) => source.netWeight != null && Math.round(Number(source.netWeight) * 1000) === weightKg)) {
      return { source: null as SourceItem | null, note: "Já existe lançamento com este número de ticket, mas com peso líquido diferente. A foto ficou salva para conferência da Gerência." };
    }
    const identity = resolveDriverAndFleet(ticket);
    if (!identity) return { source: null as SourceItem | null, note: "Foto e dados salvos. Não foi possível identificar motorista e conjunto com segurança; a Gerência pode relacionar manualmente." };

    const response = await fetch("/api/salvar-ticket", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...ticket, conferido: true, driverId: identity.driver.id, fleetId: identity.fleet.id, freightMode: "ton", dailyValue: 0, km_carreta: 0 }),
    });
    const result = await response.json().catch(() => ({ erro: "Resposta inválida do servidor." }));
    if (!response.ok) {
      if (response.status === 409) return { source: null as SourceItem | null, note: result?.erro || ("Ticket " + ticketNumber + " já existe e não foi duplicado.") };
      throw new Error(result?.erro || "Não foi possível lançar a viagem no Caixa.");
    }
    const source: SourceItem = {
      key: "report:" + result.reportId, relationType: "report", relationId: String(result.reportId), code: String(result.ticket || ticketNumber),
      driverId: String(result.driverId || identity.driver.id), driverName: String(result.driverName || identity.driver.name),
      fleetId: String(result.fleetId || identity.fleet.id), fleetName: String(result.fleetName || identity.fleet.name || ""),
      date: ticketDateIso(ticket.data_ticket) || new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo" }).format(new Date()),
      freightMode: String(result.freightMode || "ton"), netWeight: Number(result.tons ?? weightKg / 1000), status: String(result.reportStatus || "pendente"),
    };
    await archivePhoto(source, imageData, fileName, photoId);
    return { source, note: result.linkedExisting ? "Ticket e peso líquido já estavam lançados. A nova foto foi vinculada ao lançamento existente." : "Viagem criada no Caixa para conferência e fechamento da Gerência." };
  }

  async function blobBase64(blob: Blob) {
    const buffer = new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    for (let offset = 0; offset < buffer.length; offset += 0x8000) binary += String.fromCharCode(...buffer.subarray(offset, Math.min(buffer.length, offset + 0x8000)));
    return btoa(binary);
  }

  async function uploadPendingPhotoFile(file: File) {
    const startResponse = await fetch("/api/photo-upload", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "start", fileName: file.name || "ticket.jpg", mimeType: file.type || "application/octet-stream", size: file.size }) });
    const started = await startResponse.json().catch(() => ({ ok: false, message: "Resposta inválida do servidor." }));
    if (!startResponse.ok) throw new Error(started?.message || "Não foi possível iniciar o upload da foto.");
    const uploadId = String(started.uploadId || "");
    const chunkSize = 512 * 1024;
    for (let index = 0, offset = 0; offset < file.size; index += 1, offset += chunkSize) {
      const data = await blobBase64(file.slice(offset, Math.min(file.size, offset + chunkSize)));
      const response = await fetch("/api/photo-upload", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "chunk", uploadId, index, data }) });
      const result = await response.json().catch(() => ({ ok: false, message: "Resposta inválida do servidor." }));
      if (!response.ok) throw new Error(result?.message || "Falha ao enviar uma parte da foto.");
    }
    const finishResponse = await fetch("/api/photo-upload", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "finish", uploadId, reportStatus: "aguardando leitura" }) });
    const finished = await finishResponse.json().catch(() => ({ ok: false, message: "Resposta inválida do servidor." }));
    if (!finishResponse.ok) throw new Error(finished?.message || "Não foi possível concluir o upload da foto.");
    return { id: String(finished.id || ""), imageData: String(finished.imageData || ""), fileName: String(finished.fileName || file.name || "ticket.jpg") };
  }

  async function uploadPendingPhoto(image: string, fileName: string) {
    const response = await fetch("/api/photo-intake", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image, fileName, relationType: "unlinked", relationId: "pending", tripCode: "Aguardando vínculo" }),
    });
    const result = await response.json().catch(() => ({ ok: false, message: "Resposta inválida do servidor." }));
    if (!response.ok) throw new Error(result?.message || "Não foi possível enviar a foto.");
    return String(result?.id || "");
  }

  async function archivePhoto(source: SourceItem, image: string, fileName: string, photoId = "") {
    const response = await fetch("/api/photo-intake", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image, fileName, photoId, relationType: source.relationType, relationId: source.relationId, tripCode: source.code, driverId: source.driverId, driverName: source.driverName, fleetId: source.fleetId, fleetName: source.fleetName, tripDate: source.date, freightMode: source.freightMode, netWeight: source.netWeight, reportStatus: source.status }),
    });
    const result = await response.json().catch(() => ({ ok: false, message: "Resposta inválida do servidor." }));
    if (!response.ok) throw new Error(result?.message || "Não foi possível relacionar a foto.");
  }

  async function linkBatchResult(id: string) {
    const source = selected;
    const item = batchResults.find((entry) => entry.id === id);
    if (!item) return;
    if (!source) return toast.error("Escolha acima a viagem correta para esta foto.");
    try {
      await archivePhoto(source, item.imageData, item.fileName, item.photoId);
      setBatchResults((current) => current.map((entry) => entry.id === id ? { ...entry, linked: true, error: "" } : entry));
      toast.success("Foto relacionada à viagem " + source.code + ".");
      await loadSaved();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível relacionar a foto.");
    }
  }

  async function savePhotos(incomingFiles?: File[]) {
    const selectedFiles = incomingFiles?.length ? incomingFiles : files;
    if (selectedFiles.length === 0) return toast.error("Selecione pelo menos uma foto do ticket.");
    setBusy(true);
    toast.info("Arquivos recebidos. Iniciando upload…");
    setBatchResults([]);
    setBatchProgress({ done: 0, total: selectedFiles.length });
    let linked = 0;
    let failed = 0;
    try {
      for (let offset = 0; offset < selectedFiles.length; offset += 3) {
        const chunk = selectedFiles.slice(offset, offset + 3);
        const results = await Promise.all(chunk.map(async (file, chunkIndex): Promise<BatchPhotoResult> => {
          const id = Date.now().toString(36) + "-" + (offset + chunkIndex) + "-" + Math.random().toString(36).slice(2, 8);
          try {
            const uploaded = await uploadPendingPhotoFile(file);
            const imageData = uploaded.imageData;
            const pendingId = uploaded.id;
            const ticket = await readTicketImage(imageData, uploaded.fileName || file.name);
            const matched = automaticSource(ticket);
            let finalSource: SourceItem | null = matched;
            let caixaCreated = false;
            let note = "";
            if (matched) {
              await archivePhoto(matched, imageData, file.name, pendingId);
              linked += 1;
              note = "Mesmo número do ticket e mesmo peso líquido encontrados. Foto vinculada ao lançamento existente.";
            } else {
              const created = await createPendingCaixa(ticket, imageData, file.name, pendingId);
              finalSource = created.source;
              note = created.note;
              if (created.source) { caixaCreated = true; linked += 1; }
            }
            return { id, fileName: file.name || "ticket.jpg", imageData, photoId: pendingId, ticket, linked: !!finalSource, caixaCreated, note, error: "" };
          } catch (error) {
            failed += 1;
            return { id, fileName: file.name || "ticket.jpg", imageData: "", photoId: "", ticket: null, linked: false, caixaCreated: false, note: "", error: error instanceof Error ? error.message : "Não foi possível processar a foto." };
          }
        }));
        setBatchResults((current) => [...current, ...results]);
        setBatchProgress({ done: Math.min(offset + chunk.length, selectedFiles.length), total: selectedFiles.length });
      }
      const total = selectedFiles.length;
      setFiles([]);
      await loadSaved();
      const manual = total - linked - failed;
      if (failed === 0 && manual === 0) toast.success(linked + (linked === 1 ? " foto processada e enviada/relacionada com sucesso." : " fotos processadas e enviadas/relacionadas com sucesso."));
      else toast.success("Leitura concluída: " + linked + " enviada(s)/vinculada(s), " + manual + " aguardando identificação e " + failed + " com erro.");
    } finally {
      setBusy(false);
    }
  }

  async function deletePhoto(photo: SavedPhoto) {
    if (!window.confirm("Excluir a foto do ticket " + photo.tripCode + "?")) return;
    try {
      const response = await fetch("/api/photo-intake?id=" + encodeURIComponent(photo.id), {
        method: "DELETE",
        credentials: "same-origin",
      });
      const result = await response.json().catch(() => ({ ok: false, message: "Resposta inválida do servidor." }));
      if (!response.ok) throw new Error(result?.message || "Não foi possível excluir a foto.");
      toast.success("Foto excluída.");
      await loadSaved();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível excluir a foto.");
    }
  }

  return (
    <div>
      <div className="flex items-start gap-3">
        <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-surface-2 text-accent"><Camera className="size-6" /></span>
        <div>
          <p className="text-[11px] uppercase tracking-[0.18em] text-muted">Arquivo de tickets da Gerência</p>
          <h1 className="mt-1 font-display text-4xl font-semibold tracking-tight">Fotos dos Tickets</h1>
          <p className="mt-2 max-w-2xl text-sm text-muted">
            Selecione quantas fotos quiser. O ChatGPT extrai os dados; se já existir a viagem, relaciona a foto. Se não existir, cria um lançamento pendente no Caixa para a Gerência conferir e fechar.
          </p>
        </div>
      </div>

      <div className="mt-7"><MonthlyOperationImport /></div>

      <DataIntegrityPanel scope="tickets" />

      <section className="mt-7 grid gap-5 rounded-xl border border-border bg-surface p-5 sm:p-6">
        <div className="grid gap-4">
          <Field label="Pesquisar viagem">
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Ticket, motorista, conjunto ou data"
            />
          </Field>

          <Field label="Vínculo manual (para fotos sem correspondência automática)">
            <Select value={sourceKey} onChange={(e) => setSourceKey(e.target.value)}>
              <option value="">Escolha a viagem ou lançamento</option>
              {pendingSources.length > 0 ? (
                <optgroup label="Caixa / lançamentos">
                  {pendingSources.map((s) => (
                    <option key={s.key} value={s.key}>
                      Ticket {s.code} · {s.driverName} · {s.fleetName} · {tons(s.netWeight)}
                    </option>
                  ))}
                </optgroup>
              ) : null}
              {tripSources.length > 0 ? (
                <optgroup label="Viagens fechadas">
                  {tripSources.map((s) => (
                    <option key={s.key} value={s.key}>
                      Viagem {s.code} · {s.driverName} · {shortDate(s.date)} · {tons(s.netWeight)}
                    </option>
                  ))}
                </optgroup>
              ) : null}
            </Select>
          </Field>
        </div>

        {selected ? (
          <div className="rounded-xl border border-border bg-bg p-4">
            <div className="flex items-start gap-3">
              <Link2 className="mt-0.5 size-5 shrink-0 text-accent" />
              <div className="grid gap-1 text-sm">
                <strong>Ticket/viagem {selected.code}</strong>
                <span className="text-muted">{selected.driverName} · {selected.fleetName}</span>
                <span className="text-muted">{shortDate(selected.date)} · {modeLabel(selected.freightMode)} · {tons(selected.netWeight)}</span>
              </div>
            </div>
          </div>
        ) : null}

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="relative flex min-h-40 overflow-hidden flex-col items-center justify-center rounded-xl border border-dashed border-border bg-bg px-5 py-7 text-center hover:bg-surface-2">
            <ImagePlus className="pointer-events-none size-8 text-accent" />
            <strong className="pointer-events-none mt-3 text-sm">Escolher da galeria</strong>
            <span className="pointer-events-none mt-1 text-xs text-muted">Selecione várias fotos. Todas serão lidas pelo ChatGPT em lote.</span>
            <input
              aria-label="Escolher fotos da galeria"
              className="absolute inset-0 z-10 h-full w-full cursor-pointer opacity-0"
              type="file"
              accept="image/*"
              multiple
              onChange={(e) => {
                const selectedFiles = Array.from(e.currentTarget.files ?? []);
                e.currentTarget.value = "";
                if (!selectedFiles.length) return;
                setFiles(selectedFiles);
                void savePhotos(selectedFiles);
              }}
            />
          </div>

          <div className="relative flex min-h-40 overflow-hidden flex-col items-center justify-center rounded-xl border border-dashed border-border bg-bg px-5 py-7 text-center hover:bg-surface-2">
            <Camera className="pointer-events-none size-8 text-accent" />
            <strong className="pointer-events-none mt-3 text-sm">Fotografar ticket</strong>
            <span className="pointer-events-none mt-1 text-xs text-muted">Também é possível fotografar o ticket diretamente pela Gerência.</span>
            <input
              aria-label="Fotografar ticket"
              className="absolute inset-0 z-10 h-full w-full cursor-pointer opacity-0"
              type="file"
              accept="image/*"
              capture="environment"
              onChange={(e) => {
                const selectedFiles = Array.from(e.currentTarget.files ?? []);
                e.currentTarget.value = "";
                if (!selectedFiles.length) return;
                setFiles(selectedFiles);
                void savePhotos(selectedFiles);
              }}
            />
          </div>
        </div>

        {files.length > 0 ? (
          <div className="rounded-lg border border-border bg-bg p-3 text-sm">
            <strong>{busy ? "Enviando e lendo " + batchProgress.done + "/" + batchProgress.total : files.length + " foto(s) selecionada(s)"}</strong>
            <p className="mt-1 truncate text-xs text-muted">{files.map((f) => f.name).join(" • ")}</p>
          </div>
        ) : null}

        <Button type="button" size="lg" disabled={busy || files.length === 0} onClick={() => void savePhotos()}>
          {busy ? <LoaderCircle className="size-5 animate-spin" /> : <ImagePlus className="size-5" />}
          {busy ? "Lendo " + batchProgress.done + "/" + batchProgress.total + "…" : "Ler, extrair e relacionar fotos"}
        </Button>
      </section>
      {batchResults.length > 0 ? (
        <section className="mt-7 grid gap-3">
          <div>
            <p className="text-[11px] uppercase tracking-[0.16em] text-muted">Leitura em lote</p>
            <h2 className="mt-1 font-display text-2xl font-semibold">Dados extraídos</h2>
          </div>
          {batchResults.map((item, index) => {
            const ticket = item.ticket;
            return (
              <article key={item.id} className="rounded-xl border border-border bg-surface p-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div className="min-w-0 text-sm">
                    <strong>{index + 1}. {item.fileName}</strong>
                    {item.error ? <p className="mt-1 text-danger">{item.error}</p> : ticket ? (
                      <div className="mt-2 grid gap-1 text-muted sm:grid-cols-2">
                        <span>Ticket: <b className="text-fg">{ticket.numero_ticket || "—"}</b></span>
                        <span>Peso líquido: <b className="text-fg">{ticket.peso_liquido_kg ? new Intl.NumberFormat("pt-BR").format(ticket.peso_liquido_kg) + " kg" : "—"}</b></span>
                        <span>Veículo: <b className="text-fg">{ticket.placa_veiculo || "—"}</b></span>
                        <span>Carreta: <b className="text-fg">{ticket.placa_carreta || "—"}</b></span>
                        <span>Contratante: <b className="text-fg">{ticket.contratante || ticket.transportadora || "—"}</b></span>
                        <span>Destinatário: <b className="text-fg">{ticket.destinatario || "—"}</b></span>
                      </div>
                    ) : null}
                    {item.note ? <p className="mt-2 text-xs text-muted">{item.note}</p> : null}
                  </div>
                  <div className="shrink-0">
                    {item.linked ? (
                      <span className="inline-flex rounded-full border border-ok/30 bg-ok/10 px-3 py-1 text-xs font-semibold text-ok">{item.caixaCreated ? "Lançada no Caixa" : "Relacionada automaticamente"}</span>
                    ) : !item.error ? (
                      <Button type="button" size="sm" variant="secondary" disabled={!selected} onClick={() => void linkBatchResult(item.id)}>
                        <Link2 className="size-4" /> Relacionar à viagem escolhida
                      </Button>
                    ) : null}
                  </div>
                </div>
              </article>
            );
          })}
        </section>
      ) : null}

      <section className="mt-7">
        <div className="flex items-baseline justify-between gap-3">
          <div>
            <p className="text-[11px] uppercase tracking-[0.16em] text-muted">Arquivo da Gerência</p>
            <h2 className="mt-1 font-display text-2xl font-semibold">Tickets salvos</h2>
          </div>
          <Button type="button" size="sm" variant="ghost" disabled={loadingSaved} onClick={() => void loadSaved()}>
            {loadingSaved ? "Atualizando…" : "Atualizar"}
          </Button>
        </div>

        {loadingSaved ? (
          <div className="mt-4 flex items-center gap-2 rounded-xl border border-border bg-surface p-4 text-sm text-muted">
            <LoaderCircle className="size-4 animate-spin" /> Carregando fotos…
          </div>
        ) : savedPhotos.length === 0 ? (
          <p className="mt-4 rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted">
            Nenhuma foto de ticket salva ainda.
          </p>
        ) : (
          <div className="mt-4 grid gap-3">
            {savedPhotos.map((photo) => (
              <article key={photo.id} className="rounded-xl border border-border bg-surface p-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <strong className="font-display text-xl">Ticket/viagem {photo.tripCode}</strong>
                      <span className="rounded-full border border-border px-2 py-0.5 text-[10px] uppercase tracking-wide text-muted">
                        {photo.relationType === "trip" ? "Viagem fechada" : photo.relationType === "report" ? "Caixa" : "Sem vínculo"}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-muted">
                      {photo.driverName || "Motorista"} · {photo.fleetName || "Conjunto"} · {shortDate(photo.tripDate)}
                    </p>
                    <p className="mt-1 text-xs text-subtle">
                      {modeLabel(photo.freightMode)} · {tons(photo.netWeight)} · arquivo {photo.fileName}
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-wrap gap-2">
                    <Button
                      type="button"
                      size="sm"
                      variant="secondary"
                      onClick={() => setViewerPhoto(photo)}
                    >
                      <ZoomIn className="size-4" /> Ver foto
                    </Button>
                    <Button type="button" size="sm" variant="ghost" className="text-danger" onClick={() => void deletePhoto(photo)}>
                      <Trash2 className="size-4" /> Excluir
                    </Button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {viewerPhoto ? <PhotoViewer photo={viewerPhoto} onClose={() => setViewerPhoto(null)} /> : null}
    </div>
  );
}


function PhotoViewer({ photo, onClose }: { photo: SavedPhoto; onClose: () => void }) {
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const gesture = useRef<{ distance: number; x: number; y: number }>({ distance: 0, x: 0, y: 0 });
  const scaleRef = useRef(1);

  const clampScale = (value: number) => Math.min(6, Math.max(1, value));

  function applyScale(next: number) {
    const value = clampScale(next);
    scaleRef.current = value;
    setScale(value);
    if (value === 1) setOffset({ x: 0, y: 0 });
  }

  function reset() {
    scaleRef.current = 1;
    setScale(1);
    setOffset({ x: 0, y: 0 });
  }

  function distance(touches: React.TouchList) {
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.hypot(dx, dy);
  }

  function onTouchStart(event: React.TouchEvent<HTMLDivElement>) {
    if (event.touches.length === 2) {
      gesture.current = {
        distance: distance(event.touches),
        x: (event.touches[0].clientX + event.touches[1].clientX) / 2,
        y: (event.touches[0].clientY + event.touches[1].clientY) / 2,
      };
      return;
    }
    if (event.touches.length === 1) {
      gesture.current = { distance: 0, x: event.touches[0].clientX, y: event.touches[0].clientY };
    }
  }

  function onTouchMove(event: React.TouchEvent<HTMLDivElement>) {
    if (event.touches.length === 2) {
      event.preventDefault();
      const nextDistance = distance(event.touches);
      const previousDistance = gesture.current.distance || nextDistance;
      const ratio = nextDistance / previousDistance;
      applyScale(scaleRef.current * ratio);
      gesture.current = {
        distance: nextDistance,
        x: (event.touches[0].clientX + event.touches[1].clientX) / 2,
        y: (event.touches[0].clientY + event.touches[1].clientY) / 2,
      };
      return;
    }

    if (event.touches.length === 1 && scaleRef.current > 1) {
      event.preventDefault();
      const touch = event.touches[0];
      const dx = touch.clientX - gesture.current.x;
      const dy = touch.clientY - gesture.current.y;
      setOffset((current) => ({ x: current.x + dx, y: current.y + dy }));
      gesture.current = { distance: 0, x: touch.clientX, y: touch.clientY };
    }
  }

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[100] flex flex-col bg-black/95" role="dialog" aria-modal="true" aria-label={"Foto do ticket " + photo.tripCode}>
      <div className="flex shrink-0 items-center justify-between gap-3 border-b border-white/15 px-3 py-3 text-white sm:px-5">
        <div className="min-w-0">
          <strong className="block truncate">Ticket/viagem {photo.tripCode}</strong>
          <span className="block truncate text-xs text-white/65">Use dois dedos para ampliar ou reduzir · arraste quando estiver ampliado</span>
        </div>
        <Button type="button" size="sm" variant="secondary" onClick={onClose} aria-label="Fechar foto">
          <X className="size-4" /> Fechar
        </Button>
      </div>

      <div
        className="relative flex min-h-0 flex-1 items-center justify-center overflow-hidden p-2 sm:p-4"
        style={{ touchAction: "none" }}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={() => { gesture.current.distance = 0; }}
        onWheel={(event) => {
          event.preventDefault();
          applyScale(scaleRef.current + (event.deltaY < 0 ? 0.25 : -0.25));
        }}
      >
        <img
          src={"/api/photo-intake?id=" + encodeURIComponent(photo.id)}
          alt={"Foto do ticket " + photo.tripCode}
          draggable={false}
          className="max-h-full max-w-full select-none object-contain will-change-transform"
          style={{
            transform: `translate3d(${offset.x}px, ${offset.y}px, 0) scale(${scale})`,
            transformOrigin: "center center",
          }}
          onDoubleClick={() => applyScale(scaleRef.current > 1 ? 1 : 2)}
        />
      </div>

      <div className="flex shrink-0 items-center justify-center gap-2 border-t border-white/15 px-3 py-3">
        <Button type="button" size="sm" variant="secondary" onClick={() => applyScale(scaleRef.current - 0.5)} disabled={scale <= 1}>
          <ZoomOut className="size-4" /> Reduzir
        </Button>
        <span className="min-w-16 text-center text-sm font-semibold text-white">{Math.round(scale * 100)}%</span>
        <Button type="button" size="sm" variant="secondary" onClick={() => applyScale(scaleRef.current + 0.5)} disabled={scale >= 6}>
          <ZoomIn className="size-4" /> Ampliar
        </Button>
        <Button type="button" size="sm" variant="secondary" onClick={reset}>
          <RotateCcw className="size-4" /> Ajustar
        </Button>
      </div>
    </div>
  );
}
