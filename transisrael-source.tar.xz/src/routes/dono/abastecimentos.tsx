import { DataIntegrityPanel } from "@/components/data-integrity-panel";
import { createFileRoute } from "@tanstack/react-router";
import { Fuel, Pencil, Plus, Trash2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { SmartSearch, buildSmartSuggestions, smartSearchMatches } from "@/components/smart-search";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { fuelingConsumptionRows } from "@/lib/calc";
import { brl, formatDate, integer } from "@/lib/format";
import { parseLocaleNumberOrZero } from "@/lib/parse";
import type { Fueling } from "@/lib/types";
import { useFleet, useFleetMutations } from "@/lib/use-fleet";

import { FuelingPhotoReader } from "@/components/fueling-photo-reader";
const exactLiters = (value: unknown) => {
  const numeric = Number(value ?? 0);
  if (!Number.isFinite(numeric)) return "0 L";
  return new Intl.NumberFormat("pt-BR", {
    useGrouping: true,
    maximumFractionDigits: 3,
  }).format(numeric) + " L";
};

export const Route = createFileRoute("/dono/abastecimentos")({
  component: AbastecimentosPage,
});

type Draft = Partial<Fueling>;

const paidFuelingTotal = (row: Pick<Fueling, "liters" | "pricePerLiter" | "discountAmount" | "totalAmount">) => {
  if (row.totalAmount != null && Number.isFinite(Number(row.totalAmount))) return Number(row.totalAmount);
  return Math.max(0, Number(row.liters ?? 0) * Number(row.pricePerLiter ?? 0) - Number(row.discountAmount ?? 0));
};

function AbastecimentosPage() {
  const { data } = useFleet();
  const { fueling, removeFueling } = useFleetMutations();
  const [editing, setEditing] = useState<Draft | null>(null);
  const [fleetFilter, setFleetFilter] = useState("all");
  const [search, setSearch] = useState("");

  const consumptionRows = useMemo(
    () => fuelingConsumptionRows(data?.fuelings ?? []),
    [data],
  );
  const rows = useMemo(() => {
    let filtered = fleetFilter === "all" ? consumptionRows : consumptionRows.filter((f) => f.fleetId === fleetFilter);
    filtered = filtered.filter((row) => {
      const fleet = data?.fleets.find((f) => f.id === row.fleetId);
      const driver = data?.drivers.find((d) => d.id === row.driverId);
      return smartSearchMatches(search, [row.date, row.station, row.notes, driver?.name, fleet?.name, fleet?.tractorPlate, fleet?.trailerPlate]);
    });
    return filtered;
  }, [consumptionRows, fleetFilter, search, data]);

  const searchSuggestions = useMemo(() => buildSmartSuggestions(
    (data?.fuelings ?? []).flatMap((row) => {
      const fleet = data?.fleets.find((f) => f.id === row.fleetId);
      const driver = data?.drivers.find((d) => d.id === row.driverId);
      return [row.station, row.notes, driver?.name, fleet?.name, fleet?.tractorPlate, fleet?.trailerPlate];
    }), search,
  ), [data, search]);

  const totalLiters = rows.reduce((sum, row) => sum + row.liters, 0);
  const totalCost = rows.reduce((sum, row) => sum + paidFuelingTotal(row), 0);
  const grossCost = rows.reduce((sum, row) => sum + row.liters * row.pricePerLiter, 0);
  const avgPrice = totalLiters > 0 ? grossCost / totalLiters : 0;

  async function handleDeleteFueling(row: Fueling) {
    if (!window.confirm("Excluir este abastecimento?")) return;
    try {
      await removeFueling.mutateAsync(row.id);
      toast.success("Abastecimento excluído.");
      if (editing?.id === row.id) setEditing(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Não foi possível excluir.");
    }
  }

  return (
    <div>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[11px] uppercase tracking-[0.18em] text-muted">Controle de combustível</p>
          <h1 className="mt-1 font-display text-4xl font-semibold tracking-tight">Abastecimentos</h1>
          <p className="mt-2 max-w-xl text-sm text-muted">
            Registre e acompanhe litros, preços e custo total de cada abastecimento por conjunto.
          </p>
        </div>
        <Button
          onClick={() =>
            setEditing({
              date: new Date().toISOString().slice(0, 10),
              fleetId: data?.fleets[0]?.id ?? "",
              driverId: data?.drivers[0]?.id ?? null,
              station: "",
              km: 0,
              liters: 0,
              pricePerLiter: 0,
              discountAmount: 0,
              totalAmount: null,
              notes: "",
            })
          }
        >
          <Plus className="size-4" /> Novo abastecimento
        </Button>
      </div>

      <DataIntegrityPanel scope="fueling" />

      <FuelingPhotoReader />

      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <Metric label="Litros registrados" value={exactLiters(totalLiters)} />
        <Metric label="Custo total" value={brl(totalCost)} />
        <Metric label="Preço médio/L" value={brl(avgPrice)} />
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <SmartSearch value={search} onChange={setSearch} suggestions={searchSuggestions} placeholder="Posto, motorista, conjunto ou placa — mínimo 3 letras" label="Pesquisar abastecimentos" />
        <Field label="Filtrar por conjunto">
          <Select value={fleetFilter} onChange={(e) => setFleetFilter(e.target.value)}>
            <option value="all">Todos os conjuntos</option>
            {(data?.fleets ?? []).map((f) => (
              <option key={f.id} value={f.id}>{f.name} · {f.trailerPlate}</option>
            ))}
          </Select>
        </Field>
      </div>

      {rows.length === 0 ? (
        <div className="mt-6 rounded-xl border border-dashed border-border px-5 py-12 text-center">
          <Fuel className="mx-auto size-7 text-muted" />
          <p className="mt-3 text-sm text-muted">Nenhum abastecimento registrado.</p>
        </div>
      ) : (
        <ul className="mt-6 grid gap-3">
          {rows.map((row) => {
            const fleet = data?.fleets.find((f) => f.id === row.fleetId);
            const driver = data?.drivers.find((d) => d.id === row.driverId);
            return (
              <li key={row.id} className="rounded-xl border border-border bg-surface p-4 sm:p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    {fleet?.name ? <p className="font-display text-2xl font-semibold">{fleet.name}</p> : null}
                    <p className="text-sm text-muted">
                      {[formatDate(row.date), driver?.name, row.station].filter(Boolean).join(" · ")}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="px-3"
                      onClick={() => setEditing(row)}
                      title="Editar abastecimento"
                      aria-label="Editar abastecimento"
                    >
                      <Pencil className="size-4" />
                      <span className="hidden sm:inline">Editar</span>
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="px-3 text-danger"
                      disabled={removeFueling.isPending}
                      title="Excluir abastecimento"
                      aria-label="Excluir abastecimento"
                      onClick={() => handleDeleteFueling(row)}
                    >
                      <Trash2 className="size-4" />
                      <span className="hidden sm:inline">Excluir</span>
                    </Button>
                  </div>
                </div>
                <dl className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
                  {row.km > 0 ? <Metric label="Odômetro" value={`${integer(row.km)} km`} compact /> : null}
                  <Metric label="Litros" value={exactLiters(row.liters)} compact />
                  <Metric label="Preço/L" value={brl(row.pricePerLiter)} compact />
                  <Metric label="Desconto" value={brl(row.discountAmount ?? 0)} compact />
                  <Metric label="Total após desconto" value={brl(paidFuelingTotal(row))} compact />
                  {fleet?.trailerPlate ? <Metric label="Carreta" value={fleet.trailerPlate} compact /> : null}
                </dl>
                {row.notes ? <p className="mt-3 text-sm text-muted">{row.notes}</p> : null}
              </li>
            );
          })}
        </ul>
      )}

      <FuelingDialog value={editing} onClose={() => setEditing(null)} onDelete={handleDeleteFueling} />
    </div>
  );
}

function FuelingDialog({
  value,
  onClose,
  onDelete,
}: {
  value: Draft | null;
  onClose: () => void;
  onDelete: (value: Fueling) => Promise<void>;
}) {
  const { data } = useFleet();
  const { fueling } = useFleetMutations();
  const [date, setDate] = useState("");
  const [driverId, setDriverId] = useState("");
  const [fleetId, setFleetId] = useState("");
  const [station, setStation] = useState("");
  const [kmValue, setKmValue] = useState("");
  const [litersValue, setLitersValue] = useState("");
  const [priceValue, setPriceValue] = useState("");
  const [discountValue, setDiscountValue] = useState("");
  const [totalValue, setTotalValue] = useState("");
  const [notes, setNotes] = useState("");

  const reset = () => {
    if (!value) return;
    setDate(value.date ?? new Date().toISOString().slice(0, 10));
    setDriverId(value.driverId ?? "");
    setFleetId(value.fleetId ?? data?.fleets[0]?.id ?? "");
    setStation(value.station ?? "");
    setKmValue(value.km ? String(value.km) : "");
    setLitersValue(value.liters ? String(value.liters) : "");
    setPriceValue(value.pricePerLiter ? String(value.pricePerLiter) : "");
    setDiscountValue(value.discountAmount ? String(value.discountAmount) : "");
    setTotalValue(value.totalAmount != null ? String(value.totalAmount) : "");
    setNotes(value.notes ?? "");
  };

  // Reset only when a different record is opened; live fleet refetches must not erase typing.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    reset();
  }, [value?.id, value?.date]);

  return (
    <Dialog
      open={!!value}
      onOpenChange={(open) => {
        if (!open) onClose();
        else reset();
      }}
    >
      {value ? (
        <DialogContent title={value.id ? "Editar abastecimento" : "Novo abastecimento"}>
          <form
            className="grid gap-4"
            onSubmit={async (e) => {
              e.preventDefault();
              try {
                await fueling.mutateAsync({
                  id: value.id,
                  date: date || new Date().toISOString().slice(0, 10),
                  driverId: driverId || null,
                  fleetId,
                  station,
                  km: parseLocaleNumberOrZero(kmValue),
                  liters: parseLocaleNumberOrZero(litersValue),
                  pricePerLiter: parseLocaleNumberOrZero(priceValue),
                  discountAmount: parseLocaleNumberOrZero(discountValue),
                  totalAmount: totalValue.trim() ? parseLocaleNumberOrZero(totalValue) : null,
                  notes,
                });
                toast.success("Abastecimento salvo.");
                onClose();
              } catch (err) {
                toast.error(err instanceof Error ? err.message : "Não foi possível salvar.");
              }
            }}
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Data"><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></Field>
              <Field label="Posto"><Input value={station} onChange={(e) => setStation(e.target.value)} placeholder="Nome do posto" /></Field>
            </div>
            <Field label="Conjunto">
              <Select value={fleetId} onChange={(e) => setFleetId(e.target.value)} required>
                <option value="">Escolha</option>
                {(data?.fleets ?? []).map((f) => <option key={f.id} value={f.id}>{f.name} · {f.trailerPlate}</option>)}
              </Select>
            </Field>
            <Field label="Motorista">
              <Select value={driverId} onChange={(e) => setDriverId(e.target.value)}>
                <option value="">Sem motorista informado</option>
                {(data?.drivers ?? []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </Select>
            </Field>
            <div className="grid grid-cols-3 gap-3">
              <Field label="KM"><Input inputMode="numeric" value={kmValue} onChange={(e) => setKmValue(e.target.value)} /></Field>
              <Field label="Litros"><Input inputMode="decimal" value={litersValue} onChange={(e) => setLitersValue(e.target.value)} required /></Field>
              <Field label="Preço/L"><Input inputMode="decimal" value={priceValue} onChange={(e) => setPriceValue(e.target.value)} /></Field>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Desconto"><Input inputMode="decimal" value={discountValue} onChange={(e) => setDiscountValue(e.target.value)} placeholder="0,00" /></Field>
              <Field label="Total após desconto"><Input inputMode="decimal" value={totalValue} onChange={(e) => setTotalValue(e.target.value)} placeholder="Valor final pago" /></Field>
            </div>
            <Field label="Observação"><Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Opcional" /></Field>
            <div className="flex flex-wrap gap-2">
              <Button type="submit" disabled={fueling.isPending}>
                {value.id ? <Pencil className="size-4" /> : <Plus className="size-4" />}
                {value.id ? "Salvar alterações" : "Salvar abastecimento"}
              </Button>
              {value.id ? (
                <Button
                  type="button"
                  variant="ghost"
                  className="text-danger"
                  onClick={async () => {
                    await onDelete(value as Fueling);
                  }}
                >
                  <Trash2 className="size-4" /> Excluir
                </Button>
              ) : null}
            </div>
          </form>
        </DialogContent>
      ) : null}
    </Dialog>
  );
}

function Metric({ label, value, compact = false }: { label: string; value: string; compact?: boolean }) {
  return (
    <div className={compact ? "" : "rounded-lg border border-border bg-surface p-4"}>
      <dt className="text-[10px] uppercase tracking-[0.14em] text-muted">{label}</dt>
      <dd className={`mt-1 font-display font-semibold tabular ${compact ? "text-lg" : "text-2xl"}`}>{value}</dd>
    </div>
  );
}
