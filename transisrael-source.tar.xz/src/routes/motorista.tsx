import { createFileRoute, Link } from "@tanstack/react-router";
import { Archive, AlertTriangle, Camera, CheckCircle2, ChevronLeft, LoaderCircle } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { DriverTonPriceBatch } from "@/components/driver-ton-price-batch";
import { TicketPhotoAccess, type PhotoAccess } from "@/components/ticket-photo-access";
import { toast } from "sonner";
import { BrandLockup } from "@/components/brand";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { freightModeLabel } from "@/lib/calc";
import { integer, num } from "@/lib/format";
import { parseLocaleNumber } from "@/lib/parse";
import type { FreightMode } from "@/lib/types";
import { fleetKey, useFleet, useFleetMutations } from "@/lib/use-fleet";

export const Route = createFileRoute("/motorista")({ component: MotoristaPage });

const DRIVER_KEY = "transisrael.driverId";
const FLEET_KEY = "transisrael.fleetId";
const MODE_KEY = "transisrael.freightMode";

import type { TicketData } from "@/lib/ticket-core";

import { ShareToChatGPT } from "@/components/share-to-chatgpt";
async function ticketImageToDataUrl(file: File) {
  const looksLikeImage = file.type.startsWith("image/") || /\.(jpe?g|png|webp|heic|heif)$/i.test(file.name || "");
  if (!looksLikeImage) throw new Error("Selecione uma foto válida.");
  if (file.size > 30_000_000) throw new Error("A foto é grande demais.");

  const encode = (source: CanvasImageSource, width: number, height: number) => {
    const maxSides = [1600, 1400, 1200, 1000, 800];
    for (const maxSide of maxSides) {
      const scale = Math.min(1, maxSide / Math.max(width, height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(width * scale));
      canvas.height = Math.max(1, Math.round(height * scale));
      const ctx = canvas.getContext("2d");
      if (!ctx) continue;
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
      for (const quality of [0.84, 0.76, 0.68, 0.60, 0.52, 0.44]) {
        const out = canvas.toDataURL("image/jpeg", quality);
        if (out.length <= 2_700_000) return out;
      }
    }
    throw new Error("Não foi possível reduzir a foto para envio.");
  };

  try {
    if (typeof createImageBitmap === "function") {
      const bitmap = await createImageBitmap(file);
      try {
        return encode(bitmap, bitmap.width, bitmap.height);
      } finally {
        bitmap.close();
      }
    }
  } catch {}

  const objectUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("Não foi possível abrir esta foto no celular."));
      image.src = objectUrl;
    });
    return encode(img, img.naturalWidth || img.width, img.naturalHeight || img.height);
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

async function ocrTicketLocal(imageDataUrl: string) {
  const tesseract = await import("tesseract.js");
  const createWorker = tesseract.createWorker;
  if (typeof createWorker !== "function") throw new Error("OCR local indisponível neste aparelho.");

  let worker: Awaited<ReturnType<typeof createWorker>> | null = null;
  const pieces: string[] = [];
  const add = (value: unknown) => {
    const text = String(value || "").trim();
    if (text && !pieces.includes(text)) pieces.push(text);
  };

  try {
    try {
      worker = await createWorker(["por", "eng"]);
    } catch {
      try { worker = await createWorker("por"); }
      catch { worker = await createWorker("eng"); }
    }

    const original = await worker.recognize(imageDataUrl);
    add(original?.data?.text);

    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("O OCR não conseguiu abrir a foto."));
      img.src = imageDataUrl;
    });

    const makeCanvas = (sx: number, sy: number, sw: number, sh: number, maxSide = 2600) => {
      const scale = Math.min(3, maxSide / Math.max(sw, sh));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(sw * scale));
      canvas.height = Math.max(1, Math.round(sh * scale));
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Não foi possível preparar a foto para o OCR.");
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.filter = "grayscale(1) contrast(1.9)";
      ctx.drawImage(image, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
      return canvas;
    };

    const full = makeCanvas(0, 0, image.naturalWidth, image.naturalHeight);
    await worker.setParameters({
      tessedit_pageseg_mode: tesseract.PSM.SPARSE_TEXT,
      preserve_interword_spaces: "1",
    });
    add((await worker.recognize(full))?.data?.text);

    // Tickets verticais (Ecologistics/VPORTS) e folhas largas (Adubos Real/LOG)
    // ganham leituras por faixa. Isso melhora placa, número do ticket e pesos.
    if (image.naturalHeight > image.naturalWidth * 1.12) {
      for (const [top, bottom] of [[0, 0.58], [0.30, 0.90]] as const) {
        const sy = Math.floor(image.naturalHeight * top);
        const sh = Math.max(1, Math.floor(image.naturalHeight * (bottom - top)));
        add((await worker.recognize(makeCanvas(0, sy, image.naturalWidth, sh, 2400)))?.data?.text);
      }
    } else {
      const upper = Math.max(1, Math.floor(image.naturalHeight * 0.72));
      add((await worker.recognize(makeCanvas(0, 0, image.naturalWidth, upper, 2600)))?.data?.text);
    }

    const text = pieces.join("\n--- OCR PASS ---\n").slice(0, 30_000);
    if (text.replace(/\s/g, "").length < 8) {
      throw new Error("O OCR não encontrou texto suficiente. Tire outra foto mais nítida.");
    }
    return text;
  } finally {
    if (worker) await worker.terminate();
  }
}

async function postTicketRead(payload: Record<string, unknown>) {
  const response = await fetch("/api/ler-ticket", {
    method: "POST",
    signal: AbortSignal.timeout(50_000),
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const result = await response.json().catch(() => ({ erro: "Resposta inválida do servidor." }));
  return { response, result };
}

async function lerTicket(
  imageDataUrl: string,
  freightMode: "ton" | "trip" | "cegonha" | "caixinha",
  selectedFleet?: { tractorPlate: string; trailerPlate: string },
  fileName = "ticket.jpg",
  autoDetectMode = false,
): Promise<TicketData> {
  const primary = await postTicketRead({
    imagem: imageDataUrl,
    tipo: imageDataUrl.match(/^data:([^;]+);/)?.[1] || "image/jpeg",
    freightMode,
    fileName,
    selectedFleet,
    autoDetectMode,
  });
  if (primary.response.ok) return primary.result as TicketData;

  const fallbackStatuses = new Set([402, 408, 425, 429, 500, 502, 503, 504]);
  if (!fallbackStatuses.has(primary.response.status)) {
    throw new Error(primary.result?.erro || "Não foi possível interpretar o ticket.");
  }

  // Contingência automática: se a API de visão estiver sem crédito, em timeout
  // ou indisponível, a mesma foto é lida localmente e só o texto vai ao servidor.
  let ocrText: string;
  try {
    ocrText = await ocrTicketLocal(imageDataUrl);
  } catch (ocrError) {
    const aiMessage = primary.result?.erro || "A leitura por IA está indisponível.";
    const localMessage = ocrError instanceof Error ? ocrError.message : "OCR local indisponível.";
    throw new Error(aiMessage + " O OCR de contingência também falhou: " + localMessage);
  }

  const fallback = await postTicketRead({
    ocrText,
    freightMode,
    fileName,
    selectedFleet,
    autoDetectMode,
    fallbackReason: primary.response.status,
  });
  if (!fallback.response.ok) {
    throw new Error(fallback.result?.erro || "O OCR de contingência não conseguiu interpretar o ticket.");
  }
  return fallback.result as TicketData;
}

async function salvarTicket(dados: Partial<TicketData> & {
  driverId: string;
  fleetId: string;
  km_carreta: number;
  conferido: true;
  freightMode: "ton" | "trip" | "cegonha" | "caixinha";
  dailyValue: number;
  pricePerTon?: number;
  imagem?: string;
  fileName?: string;
}) {
  const response = await fetch("/api/salvar-ticket", {
    method: "POST",
    signal: AbortSignal.timeout(50_000),
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dados),
  });
  const result = await response.json().catch(() => ({ erro: "Resposta inválida do servidor." }));
  if (!response.ok) throw new Error(result?.erro || "Falha ao salvar o ticket");
  return result as { ok: true; id: number; reportId: string; ticket: string; tons: number; freightMode: string; photoId: string | null; linkedExisting?: boolean; duplicateExact?: boolean; driverId?: string | null; driverName?: string | null; fleetId?: string | null; fleetName?: string | null; reportStatus?: string | null };
}


function MotoristaPage() {
  const [ticketAccess, setTicketAccess] = useState<PhotoAccess | null>(null);
  const { data, isLoading } = useFleet(!!ticketAccess?.authenticated);
  const { report } = useFleetMutations();
  const drivers = (data?.drivers ?? []).filter((d) => d.status === "ativo" && (!ticketAccess?.driverId || d.id === ticketAccess.driverId));
  const fleets = (data?.fleets ?? []).filter((f) => f.status === "ativo");

  const [driverId, setDriverId] = useState("");
  const [fleetId, setFleetId] = useState("");
  const [tons, setTons] = useState("");
  const [tripCount, setTripCount] = useState("1");
  const [dailyValue, setDailyValue] = useState("");
  const [freightMode, setFreightMode] = useState<FreightMode | "">("");
  const [sentTicket, setSentTicket] = useState<string | null>(null);
  const [ticketData, setTicketData] = useState<TicketData | null>(null);
  const [ticketReading, setTicketReading] = useState(false);
  const [ticketFileName, setTicketFileName] = useState("");
  const [ticketImage, setTicketImage] = useState<string | null>(null);
  const [kmCarreta, setKmCarreta] = useState("");
  const [ticketConfirmed, setTicketConfirmed] = useState(false);
  const [ticketSending, setTicketSending] = useState(false);
  const ticketBusy = useRef(false);
  const queryClient = useQueryClient();
  useEffect(() => { if (ticketAccess?.driverId) setDriverId(ticketAccess.driverId); }, [ticketAccess?.driverId]);
  const [ticketReadError, setTicketReadError] = useState("");
  const [priceBatchMode, setPriceBatchMode] = useState(true);
  const [priceBatchPending, setPriceBatchPending] = useState(false);
  const [batchPhotos, setBatchPhotos] = useState<Array<{ id: string; fileName: string; imageData: string; data: TicketData | null; error: string; sent: boolean; status: "queued" | "uploading" | "saved" | "reading" | "sending" | "sent" | "linked" | "error" }>>([]);

  useEffect(() => {
    if (!data) return;
    const savedDriver = localStorage.getItem(DRIVER_KEY) ?? "";
    const savedFleet = localStorage.getItem(FLEET_KEY) ?? "";
    const savedMode = localStorage.getItem(MODE_KEY);
    if (savedMode === "trip" || savedMode === "ton" || savedMode === "cegonha" || savedMode === "caixinha") {
      setFreightMode((current) => current || savedMode);
    }
    if (!driverId) {
      const next =
        drivers.find((d) => d.id === savedDriver)?.id ?? drivers[0]?.id ?? "";
      setDriverId(next);
    }
    if (!fleetId) {
      const next =
        fleets.find((f) => f.id === savedFleet)?.id ?? fleets[0]?.id ?? "";
      setFleetId(next);
    }
  }, [data, driverId, fleetId, drivers, fleets]);

  const mine = useMemo(() => {
    if (!data || !driverId) return [];
    return data.reports.filter((r) => r.driverId === driverId).slice(0, 6);
  }, [data, driverId]);

  const fleet = fleets.find((f) => f.id === fleetId);
  const lastKm = useMemo(() => {
    if (!data || !fleetId) return null;
    const row = [...data.trips]
      .filter((t) => t.fleetId === fleetId)
      .sort((a, b) => b.date.localeCompare(a.date) || b.kmEnd - a.kmEnd)[0];
    return row?.kmEnd ?? null;
  }, [data, fleetId]);

  async function onTicketFile(file: File) {
    if (ticketBusy.current) return;
    if (!freightMode) return toast.error("Escolha primeiro o modo da viagem.");
    if (!ticketAccess?.authenticated) return toast.error("Entre com seu login para ler a foto.");
    ticketBusy.current = true;
    setTicketReading(true);
    setTicketData(null);
    setTicketImage(null);
    setTicketReadError("");
    setTicketConfirmed(false);
    setTons("");
    setTicketFileName(file.name);
    try {
      const imageData = await ticketImageToDataUrl(file);
      const dados = await lerTicket(
        imageData,
        freightMode,
        fleet ? { tractorPlate: fleet.tractorPlate, trailerPlate: fleet.trailerPlate } : undefined,
        file.name,
      );
      setTicketData(dados);
      setTicketImage(imageData);
      if (freightMode === "ton" && dados.peso_liquido_kg != null && dados.peso_liquido_kg > 0) {
        setTons(new Intl.NumberFormat("pt-BR", {
          minimumFractionDigits: 3,
          maximumFractionDigits: 3,
        }).format(dados.peso_liquido_kg / 1000));
      } else if (freightMode !== "ton") {
        setTons("");
      }
      if (dados.campos_ausentes?.length) toast.warning("Leitura incompleta. Preencha os campos que faltam antes de lançar.");
      else if (dados.alertas?.length) toast.warning("Ticket lido. Confira os alertas antes de lançar.");
      else toast.success("Ticket lido. Confira os dados antes de lançar.");
    } catch (error) {
      setTicketData(null);
      setTicketImage(null);
      const message = error instanceof Error ? error.message : "Não foi possível ler o ticket.";
      setTicketReadError(message);
      toast.error(message);
    } finally {
      ticketBusy.current = false;
      setTicketReading(false);
    }
  }

  async function blobBase64(blob: Blob) {
    const buffer = new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    for (let offset = 0; offset < buffer.length; offset += 0x8000) binary += String.fromCharCode(...buffer.subarray(offset, Math.min(buffer.length, offset + 0x8000)));
    return btoa(binary);
  }

  async function uploadSelectedPhotoFile(file: File) {
    const selectedDriver = (data?.drivers ?? []).find((item) => item.id === driverId);
    const startResponse = await fetch("/api/photo-upload", {
      method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "start", fileName: file.name || "ticket.jpg", mimeType: file.type || "application/octet-stream", size: file.size }),
    });
    const started = await startResponse.json().catch(() => ({ ok: false, message: "Resposta inválida do servidor." }));
    if (!startResponse.ok) throw new Error(started?.message || "Não foi possível iniciar o upload da foto.");
    const uploadId = String(started.uploadId || "");
    const chunkSize = 512 * 1024;
    for (let index = 0, offset = 0; offset < file.size; index += 1, offset += chunkSize) {
      const data = await blobBase64(file.slice(offset, Math.min(file.size, offset + chunkSize)));
      const response = await fetch("/api/photo-upload", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "chunk", uploadId, index, data }) });
      const result = await response.json().catch(() => ({ ok: false, message: "Resposta inválida do servidor." }));
      if (!response.ok) throw new Error(result?.message || "Falha ao enviar uma parte da foto.");
    }
    const finishResponse = await fetch("/api/photo-upload", {
      method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "finish", uploadId, driverId, driverName: selectedDriver?.name || null, fleetId, fleetName: fleet?.name || null, freightMode, reportStatus: "aguardando leitura" }),
    });
    const finished = await finishResponse.json().catch(() => ({ ok: false, message: "Resposta inválida do servidor." }));
    if (!finishResponse.ok) throw new Error(finished?.message || "Não foi possível concluir o upload da foto.");
    return { id: String(finished.id || ""), imageData: String(finished.imageData || ""), fileName: String(finished.fileName || file.name || "ticket.jpg") };
  }

  async function linkSelectedPhoto(photoId: string, imageData: string, fileName: string, saved: any, dados: TicketData) {
    if (!photoId) return;
    const selectedDriver = (data?.drivers ?? []).find((item) => item.id === String(saved?.driverId || driverId));
    const selectedFleet = (data?.fleets ?? []).find((item) => item.id === String(saved?.fleetId || fleetId));
    const response = await fetch("/api/photo-intake", {
      method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image: imageData, fileName, photoId, relationType: "report", relationId: String(saved.reportId), tripCode: String(saved.ticket || dados.numero_ticket || "Ticket"), driverId: String(saved?.driverId || driverId), driverName: String(saved?.driverName || selectedDriver?.name || ""), fleetId: String(saved?.fleetId || fleetId), fleetName: String(saved?.fleetName || selectedFleet?.name || ""), freightMode: String(saved?.freightMode || freightMode), netWeight: Number(saved?.tons ?? ((dados.peso_liquido_kg || 0) / 1000)) || null, reportStatus: String(saved?.reportStatus || "pendente") }),
    });
    const result = await response.json().catch(() => ({ ok: false, message: "Resposta inválida do servidor." }));
    if (!response.ok) throw new Error(result?.message || "A viagem foi salva, mas não foi possível vincular a foto.");
  }

  async function onBatchTicketFiles(files: File[]) {
    if (ticketBusy.current || files.length === 0) return;
    if (!freightMode) return toast.error("Escolha primeiro o modo da viagem.");
    if (!ticketAccess?.authenticated) return toast.error("Entre com seu login para enviar as fotos.");
    const fixedCountMode = freightMode === "cegonha" || freightMode === "caixinha";
    if (fixedCountMode && (!Number.isInteger(tripCountN) || tripCountN < 1 || tripCountN > 100)) {
      return toast.error("Antes das fotos, informe obrigatoriamente quantas viagens de " + freightModeLabel(freightMode) + " deseja adicionar (1 a 100).");
    }
    const selectedFiles = files.slice(0, 100);
    if (fixedCountMode && selectedFiles.length > tripCountN) {
      return toast.error("Você selecionou " + selectedFiles.length + " fotos, mas informou " + tripCountN + " viagens. A quantidade de viagens deve ser igual ou maior que a quantidade de fotos.");
    }
    const queued = selectedFiles.map((file, index) => ({
      id: Date.now().toString(36) + "-" + index + "-" + Math.random().toString(36).slice(2, 8),
      file,
      fileName: file.name || "foto.jpg",
    }));
    setBatchPhotos((current) => [
      ...current,
      ...queued.map((item) => ({ id: item.id, fileName: item.fileName, imageData: "", data: null, error: "", sent: false, status: "queued" as const })),
    ].slice(-100));
    ticketBusy.current = true;
    setTicketReading(true);
    setTicketReadError("");
    setTicketData(null);
    setTicketImage(null);
    setTicketFileName("");
    setTicketConfirmed(false);
    let sent = 0;
    let linkedExisting = 0;
    let failed = 0;
    try {
      for (const item of queued) {
        setBatchPhotos((current) => current.map((photo) => photo.id === item.id ? { ...photo, status: "reading", error: "" } : photo));
        let imageData = "";
        let storedPhotoId = "";
        try {
          setBatchPhotos((current) => current.map((photo) => photo.id === item.id ? { ...photo, status: "uploading", error: "Enviando arquivo ao servidor…" } : photo));
          const uploaded = await uploadSelectedPhotoFile(item.file);
          imageData = uploaded.imageData;
          storedPhotoId = uploaded.id;
          setBatchPhotos((current) => current.map((photo) => photo.id === item.id ? { ...photo, status: "saved", error: "Foto salva no banco. Iniciando leitura…" } : photo));
          let dados: TicketData | null = null;
          for (let attempt = 0; attempt < 6; attempt += 1) {
            try {
              setBatchPhotos((current) => current.map((photo) => photo.id === item.id ? { ...photo, status: "reading", error: "" } : photo));
              dados = await lerTicket(imageData, freightMode, fleet ? { tractorPlate: fleet.tractorPlate, trailerPlate: fleet.trailerPlate } : undefined, item.fileName);
              break;
            } catch (readError) {
              const message = readError instanceof Error ? readError.message : "";
              if (message.includes("Muitas leituras") && attempt < 5) {
                setBatchPhotos((current) => current.map((photo) => photo.id === item.id ? { ...photo, status: "queued", error: "Aguardando um minuto para continuar a leitura…" } : photo));
                await new Promise((resolve) => setTimeout(resolve, 61_000));
                setBatchPhotos((current) => current.map((photo) => photo.id === item.id ? { ...photo, status: "reading", error: "" } : photo));
                continue;
              }
              throw readError;
            }
          }
          if (!dados) throw new Error("Não foi possível concluir a leitura desta foto.");
          if (freightMode !== "cegonha" && freightMode !== "caixinha" && !dados.numero_ticket?.trim()) throw new Error("Número do ticket não identificado.");
          if (freightMode === "ton" && !(dados.peso_liquido_kg != null && dados.peso_liquido_kg > 0)) throw new Error("Peso líquido não identificado.");
          setBatchPhotos((current) => current.map((photo) => photo.id === item.id ? { ...photo, imageData, data: dados, status: "sending", error: "" } : photo));
          const saved = await salvarTicket({
            ...dados,
            conferido: true,
            driverId,
            fleetId,
            freightMode,
            dailyValue: 0,
            km_carreta: Number.parseInt(kmCarreta.replace(/\D/g, ""), 10) || 0,
          });
          await linkSelectedPhoto(storedPhotoId, imageData, item.fileName, saved, dados);
          sent += 1;
          if (saved?.linkedExisting) linkedExisting += 1;
          setBatchPhotos((current) => current.map((photo) => photo.id === item.id ? { ...photo, imageData: "", data: dados, sent: true, status: saved?.linkedExisting ? "linked" : "sent", error: "" } : photo));
        } catch (error) {
          failed += 1;
          const rawMessage = error instanceof Error ? error.message : "Não foi possível processar esta foto.";
          const message = storedPhotoId ? rawMessage + " A foto permaneceu salva no banco aguardando vínculo." : rawMessage;
          setBatchPhotos((current) => current.map((photo) => photo.id === item.id ? { ...photo, imageData: "", sent: false, status: "error", error: message } : photo));
        }
      }
      if (fixedCountMode) {
        const newTripsFromPhotos = Math.max(0, sent - linkedExisting);
        const remaining = Math.max(0, tripCountN - newTripsFromPhotos);
        for (let index = 0; index < remaining; index += 1) {
          await report.mutateAsync({ ticket: "", driverId, fleetId, km: 0, tons: 0, dailyValue: 0, freightMode });
          sent += 1;
        }
      }
      await queryClient.invalidateQueries({ queryKey: fleetKey });
      if (failed === 0 && linkedExisting === 0) toast.success(sent + (sent === 1 ? " viagem enviada automaticamente ao Caixa." : " viagens enviadas automaticamente ao Caixa."));
      else if (failed === 0) toast.success((sent - linkedExisting) + " nova(s) viagem(ns) e " + linkedExisting + " foto(s) vinculada(s) a lançamento(s) já existente(s).");
      else toast.warning((sent - linkedExisting) + " nova(s), " + linkedExisting + " vinculada(s) e " + failed + " foto(s) com erro. Confira a lista.");
    } finally {
      ticketBusy.current = false;
      setTicketReading(false);
    }
  }
  async function onDriverZipFile(file: File) {
    if (ticketBusy.current) return;
    if (!freightMode) return toast.error("Escolha primeiro o modo da viagem.");
    if (!ticketAccess?.authenticated) return toast.error("Entre com seu login para enviar o ZIP.");
    if (!ticketAccess.available) return toast.error("O envio de documentos não está disponível para este login.");
    if (file.size > 80_000_000) return toast.error("O ZIP deve ter no máximo 80 MB.");
    try {
      const JSZipModule: any = await import("jszip");
      const JSZip = JSZipModule.default ?? JSZipModule;
      const zip = await JSZip.loadAsync(await file.arrayBuffer());
      const images: File[] = [];
      let ignored = 0;
      for (const entry of Object.values(zip.files) as any[]) {
        if (images.length >= 100) break;
        const entryName = String(entry?.name || "");
        if (!entryName || entry.dir || entryName.startsWith("__MACOSX/") || /(?:^|\/)./.test(entryName)) continue;
        if (!/.(?:jpe?g|png|webp)$/i.test(entryName)) { ignored += 1; continue; }
        const bytes: Uint8Array = await entry.async("uint8array");
        if (!bytes.byteLength || bytes.byteLength > 10_000_000) { ignored += 1; continue; }
        const cleanName = entryName.replace(/^.*[\\/]/, "") || ("ticket-" + (images.length + 1) + ".jpg");
        const copy = new Uint8Array(bytes.length); copy.set(bytes);
        const mime = /.png$/i.test(cleanName) ? "image/png" : /.webp$/i.test(cleanName) ? "image/webp" : "image/jpeg";
        images.push(new File([copy.buffer], cleanName, { type: mime }));
      }
      if (!images.length) throw new Error("Não encontrei fotos JPG, JPEG, PNG ou WebP dentro do ZIP.");
      if (ignored > 0) toast.info(ignored + " arquivo(s) não compatível(is) do ZIP foram ignorados.");
      await onBatchTicketFiles(images);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível abrir o ZIP.");
    }
  }


  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (priceBatchMode) return;
    const tonsN = parseLocaleNumber(tons);
    const dailyValueN = parseLocaleNumber(dailyValue);
    const batchMode = freightMode === "cegonha" || freightMode === "caixinha";
    const tripCountN = Number.parseInt(tripCount, 10);
    if (!driverId) return toast.error("Escolha o motorista.");
    if (!fleetId) return toast.error("Escolha o conjunto.");
    if (!freightMode) return toast.error("Escolha o modo de frete.");
    if (freightMode === "trip" && (!(dailyValueN != null) || dailyValueN <= 0)) return toast.error("Informe o valor da diária.");
    if (batchMode && (!Number.isInteger(tripCountN) || tripCountN < 1 || tripCountN > 100)) {
      return toast.error("Informe obrigatoriamente quantas viagens de " + freightModeLabel(freightMode) + " deseja adicionar (1 a 100).");
    }
    if (batchPhotos.length > 0) {
      const pendingBatch = batchPhotos.filter((photo) => !photo.sent);
      if (pendingBatch.length > 0) return toast.error("Ainda há fotos processando ou com erro. Confira a lista.");
      return toast.info("As fotos selecionadas já foram enviadas automaticamente ao Caixa.");
    }
    if (ticketBusy.current) return;
    if (batchPhotos.length === 0 && !batchMode && ticketFileName && !ticketData) return toast.error("A foto foi selecionada, mas não foi lida. Tente ler novamente ou remova a foto para lançar manualmente.");
    if (batchPhotos.length === 0 && !batchMode && ticketData && !ticketImage) return toast.error("A foto foi lida, mas não ficou pronta para arquivamento. Selecione a foto novamente.");
    if (batchPhotos.length === 0 && !batchMode && ticketData && !ticketConfirmed) return toast.error("Confirme a conferência dos dados do ticket.");
    ticketBusy.current = true;
    setTicketSending(true);
    try {
      const count = batchPhotos.length > 0 ? batchPhotos.length : (batchMode ? tripCountN : 1);
      let firstTicket = "";
      let sentCount = count;
      let failedBatch: typeof batchPhotos = [];

      if (batchPhotos.length > 0) {
        sentCount = 0;
        for (const photo of batchPhotos.filter((item) => !item.sent)) {
          if (!photo.data) { failedBatch.push(photo); continue; }
          try {
            const saved = await salvarTicket({
              ...photo.data,
              conferido: true,
              driverId,
              fleetId,
              freightMode,
              dailyValue: freightMode === "trip" ? (dailyValueN ?? 0) : 0,
              km_carreta: Number.parseInt(kmCarreta.replace(/\D/g, ""), 10) || 0,
              imagem: photo.imageData,
              fileName: photo.fileName,
            });
            if (!firstTicket) firstTicket = saved.ticket;
            sentCount += 1;
          } catch (error) {
            failedBatch.push({ ...photo, error: error instanceof Error ? error.message : "Não foi possível salvar esta viagem." });
          }
        }
        if (sentCount === 0) throw new Error(failedBatch[0]?.error || "Nenhuma viagem foi salva.");
      } else if (ticketData) {
        if (count > 1) return toast.error("Com foto do ticket, envie uma viagem por vez para manter cada ticket ligado à viagem correta.");
        if (!ticketData.numero_ticket?.trim()) return toast.error("Confira o número do ticket.");
        if (freightMode === "ton" && !(ticketData.peso_liquido_kg != null && ticketData.peso_liquido_kg > 0)) {
          return toast.error("Confira o peso líquido do ticket.");
        }
        const saved = await salvarTicket({
          ...ticketData,
          conferido: true,
          driverId,
          fleetId,
          freightMode,
          dailyValue: freightMode === "trip" ? (dailyValueN ?? 0) : 0,
          km_carreta: Number.parseInt(kmCarreta.replace(/\D/g, ""), 10) || 0,
          imagem: ticketImage ?? undefined,
          fileName: ticketFileName || "ticket.jpg",
        });
        firstTicket = saved.ticket;
        sentCount = 1;
      } else {
        for (let index = 0; index < count; index += 1) {
          const res = await report.mutateAsync({
            ticket: "",
            driverId,
            fleetId,
            km: 0,
            tons: batchMode || freightMode === "trip" ? 0 : (tonsN ?? 0),
            dailyValue: freightMode === "trip" ? (dailyValueN ?? 0) : 0,
            freightMode,
          });
          if (!firstTicket) firstTicket = res.ticket;
        }
      }

      localStorage.setItem(DRIVER_KEY, driverId);
      localStorage.setItem(FLEET_KEY, fleetId);
      localStorage.setItem(MODE_KEY, freightMode);
      setSentTicket(sentCount > 1 ? firstTicket + " + " + (sentCount - 1) + " viagem(ns)" : firstTicket);
      setTons("");
      setDailyValue("");
      setTicketData(null);
      setTicketImage(null);
      setTicketConfirmed(false);
      setBatchPhotos(failedBatch);
      await queryClient.invalidateQueries({ queryKey: fleetKey });
      setTicketFileName("");
      setKmCarreta("");
      if (batchMode) setTripCount("1");
      toast.success(sentCount + (sentCount === 1 ? " viagem enviada ao Caixa da Gerência." : " viagens enviadas ao Caixa da Gerência."));
      if (failedBatch.length) toast.warning(failedBatch.length + " foto(s) ficaram na lista porque não puderam ser salvas.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Não foi possível enviar.");
    } finally {
      ticketBusy.current = false;
      setTicketSending(false);
    }

  }

  return (
    <main className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto max-w-md px-4 pb-16 pt-4">
        <header className="flex items-center justify-between gap-3">
          <Link
            to="/"
            className="inline-flex size-11 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-fg"
            aria-label="Voltar"
          >
            <ChevronLeft className="size-5" />
          </Link>
          <BrandLockup to="/" subtitle="Motorista" />
          <span className="size-11" />
        </header>

        <div className="mt-6">
        <h1 className="font-display text-4xl font-semibold tracking-tight">
          Lançar viagem
        </h1>
        <p className="mt-2 text-sm text-muted">
          Escolha motorista e conjunto. No leitor inteligente, o ChatGPT identifica automaticamente modalidade, preço, peso, data e hora de cada foto.
        </p>


        {sentTicket ? (
          <div className="mt-5 flex items-start gap-3 rounded-lg border border-ok/30 bg-ok/10 px-4 py-3">
            <CheckCircle2 className="mt-0.5 size-5 text-ok" />
            <div>
              <p className="text-sm font-medium text-fg">
                {freightMode === "cegonha" || freightMode === "caixinha" ? sentTicket : "Ticket " + sentTicket} depositado
              </p>
              <p className="text-sm text-muted">
                Já está na caixa de lançamentos da gerência.
              </p>
            </div>
          </div>
        ) : null}

        <form onSubmit={onSubmit} className="mt-8 flex flex-col gap-5">
          <fieldset disabled={ticketReading || ticketSending} className="contents">
          <Field label="Motorista">
            <Select
              value={driverId}
              onChange={(e) => { setDriverId(e.target.value); setTicketConfirmed(false); }}
              disabled={isLoading || drivers.length === 0 || priceBatchPending}
            >
              {drivers.length === 0 ? (
                <option value="">Nenhum motorista cadastrado</option>
              ) : (
                drivers.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))
              )}
            </Select>
          </Field>

          <Field
            label="Conjunto"
            hint={
              fleet
                ? `${fleet.tractorPlate} · carreta ${fleet.trailerPlate}${lastKm != null ? ` · último KM ${integer(lastKm)}` : ""}`
                : undefined
            }
          >
            <Select
              value={fleetId}
              onChange={(e) => { setFleetId(e.target.value); setTicketConfirmed(false); }}
              disabled={isLoading || fleets.length === 0 || priceBatchPending}
            >
              {fleets.length === 0 ? (
                <option value="">Nenhum conjunto cadastrado</option>
              ) : (
                fleets.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name} · {f.trailerPlate}
                  </option>
                ))
              )}
            </Select>
          </Field>

          <Field label="Modo de frete" hint="Obrigatório — toque em uma opção">
            <div className="grid grid-cols-2 gap-2">
              {(["ton", "trip", "cegonha", "caixinha"] as FreightMode[]).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  aria-pressed={freightMode === mode}
                  disabled={priceBatchPending}
                  onClick={() => {
                    setFreightMode(mode);
                    setTripCount(mode === "cegonha" || mode === "caixinha" ? "" : "1");
                    setTicketData(null); setTicketImage(null); setTicketFileName(""); setTicketConfirmed(false); setTicketReadError(""); setBatchPhotos([]);
                    try { localStorage.setItem(MODE_KEY, mode); } catch {}
                  }}
                  className={`min-h-14 rounded-xl border px-3 py-3 text-left transition ${
                    freightMode === mode
                      ? "border-fg bg-surface-2 text-fg ring-2 ring-fg"
                      : "border-border bg-surface text-muted"
                  }`}
                >
                  <span className="block font-medium">{freightModeLabel(mode)}</span>
                  <span className="mt-1 block text-[11px] opacity-70">
                    {freightMode === mode ? "✓ Selecionado" : "Selecionar"}
                  </span>
                </button>
              ))}
            </div>
          </Field>

          <section className="grid gap-4 rounded-xl border border-border bg-surface p-4">
              <div>
                <p className="text-sm font-semibold">Foto do ticket / documento da viagem</p>
                <p className="mt-1 text-xs text-muted">
                  {freightMode === "ton"
                    ? (priceBatchMode ? "Leia as fotos, confira as viagens e aplique o preço do grupo antes de enviar ao Caixa." : "Selecione uma ou várias fotos. Cada ticket válido é enviado automaticamente ao Caixa para a gerência definir o preço.")
                    : freightMode === "cegonha" || freightMode === "caixinha"
                      ? "Selecione 1 foto e digite quantas viagens ela representa. A mesma foto será a evidência do grupo de Cegonha/Caixinha."
                      : "Selecione uma ou várias fotos. O ChatGPT lê os dados de cada documento; pesos são ignorados neste modo."}
                </p>
              </div>

              {!freightMode ? (
                <p className="rounded-lg border border-warn/30 bg-warn/10 px-3 py-2 text-xs text-muted">
                  Escolha o modo da viagem antes de enviar a foto.
                </p>
              ) : null}
              <TicketPhotoAccess onAccess={setTicketAccess} />
              <div className="grid gap-2 sm:grid-cols-2">
                <Button
                  type="button"
                  variant="ghost"
                  className="min-h-14 whitespace-normal border border-border"
                  disabled={priceBatchPending || ticketSending}
                  onClick={() => {
                    setPriceBatchMode(false);
                    setFreightMode("cegonha");
                    setTripCount("");
                    setBatchPhotos([]);
                    setTicketData(null);
                    setTicketImage(null);
                    setTicketFileName("");
                    setTicketConfirmed(false);
                  }}
                >
                  Cegonha · 1 foto → várias viagens
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  className="min-h-14 whitespace-normal border border-border"
                  disabled={priceBatchPending || ticketSending}
                  onClick={() => {
                    setPriceBatchMode(false);
                    setFreightMode("caixinha");
                    setTripCount("");
                    setBatchPhotos([]);
                    setTicketData(null);
                    setTicketImage(null);
                    setTicketFileName("");
                    setTicketConfirmed(false);
                  }}
                >
                  Caixinha · 1 foto → várias viagens
                </Button>
              </div>
              <label className="flex min-h-12 items-center gap-3 rounded-lg border border-border p-3 text-sm font-semibold">
                <input type="checkbox" className="size-5" checked={priceBatchMode} disabled={priceBatchPending || batchPhotos.length > 0} onChange={event => setPriceBatchMode(event.target.checked)} />
                Identificar modalidade automaticamente pelas fotos
              </label>
              {priceBatchMode ? <DriverTonPriceBatch
                available={!!ticketAccess?.authenticated && ticketAccess.available && !!driverId && !!fleetId}
                upload={uploadSelectedPhotoFile}
                read={(image, fileName) => lerTicket(image, "ton", fleet ? { tractorPlate: fleet.tractorPlate, trailerPlate: fleet.trailerPlate } : undefined, fileName, true)}
                save={(dados, detectedMode, price) => salvarTicket({ ...dados, conferido: true, driverId, fleetId, freightMode: detectedMode, dailyValue: detectedMode === "ton" ? 0 : (price ?? 0), km_carreta: 0, pricePerTon: detectedMode === "ton" ? price : undefined })}
                link={(photoId, fileName, saved, dados) => linkSelectedPhoto(photoId, "", fileName, saved, dados)}
                onBusy={setTicketSending}
                onPending={setPriceBatchPending}
                onSaved={() => queryClient.invalidateQueries({ queryKey: fleetKey })}
              /> : <>
              <div className="grid grid-cols-2 gap-3">
                {[{ label: "Tirar foto", camera: true }, { label: "Escolher da galeria", camera: false }].map(option => (
                  <label key={option.label} className="relative flex min-h-28 cursor-pointer flex-col items-center justify-center overflow-hidden rounded-xl border border-dashed border-border bg-bg px-3 py-4 text-center">
                    {ticketReading ? <LoaderCircle className="size-6 animate-spin text-accent" /> : <Camera className="size-6 text-accent" />}
                    <strong className="mt-2 text-sm">{ticketReading ? "Lendo ticket…" : ((freightMode === "cegonha" || freightMode === "caixinha") && !option.camera ? "Selecionar 1 foto" : option.label)}</strong>
                    <input className="absolute inset-0 h-full w-full cursor-pointer opacity-0" type="file" aria-label={option.label} accept="image/*" capture={option.camera ? "environment" : undefined}
                      multiple={!option.camera && !(freightMode === "cegonha" || freightMode === "caixinha")}
                      disabled={ticketReading || ticketSending || !freightMode || !ticketAccess?.authenticated || !ticketAccess.available}
                      onChange={event => { const files = Array.from(event.currentTarget.files ?? []); event.currentTarget.value = ""; if (files.length) void onBatchTicketFiles(files); }} />
                  </label>
                ))}
                <label className="relative flex min-h-28 cursor-pointer flex-col items-center justify-center overflow-hidden rounded-xl border border-dashed border-border bg-bg px-3 py-4 text-center">
                  {ticketReading ? <LoaderCircle className="size-6 animate-spin text-accent" /> : <Archive className="size-6 text-accent" />}
                  <strong className="mt-2 text-sm">{ticketReading ? "Processando…" : "Enviar ZIP"}</strong>
                  <span className="mt-1 text-[11px] text-muted">Até 100 fotos de tickets</span>
                  <input className="absolute inset-0 h-full w-full cursor-pointer opacity-0" type="file" aria-label="Enviar ZIP de tickets" accept="application/zip,application/x-zip-compressed,.zip"
                    disabled={ticketReading || ticketSending || !freightMode || !ticketAccess?.authenticated || !ticketAccess.available}
                    onChange={event => { const file = event.currentTarget.files?.[0]; event.currentTarget.value = ""; if (file) void onDriverZipFile(file); }} />
                </label>
              </div>
              <ShareToChatGPT kind="trip" className="mt-2" />
              {batchPhotos.length > 0 ? (
                <div className="grid gap-2 rounded-lg border border-ok/30 bg-ok/10 p-3 text-sm">
                  <p className="font-semibold">{batchPhotos.length} foto{batchPhotos.length === 1 ? "" : "s"} selecionada{batchPhotos.length === 1 ? "" : "s"}</p>
                  <p className="text-xs text-muted">Cada foto é salva primeiro no banco. Depois o ChatGPT lê, cria ou encontra a viagem e vincula a imagem ao lançamento.</p>
                  <div className="max-h-48 space-y-2 overflow-auto">
                    {batchPhotos.map((photo, index) => (
                      <div key={index} className="rounded-md border border-border/70 bg-bg/70 p-2 text-xs">
                        <p className="truncate font-medium">{index + 1}. {photo.fileName}</p>
                        <p className="mt-1 text-[11px] font-semibold text-muted">{photo.status === "queued" ? "Na fila" : photo.status === "uploading" ? "Salvando foto no banco…" : photo.status === "saved" ? "Foto salva no banco" : photo.status === "reading" ? "Lendo com ChatGPT…" : photo.status === "sending" ? "Enviando ao Caixa…" : photo.status === "linked" ? "Vinculada ao lançamento existente" : photo.status === "sent" ? "Enviada ao Caixa" : "Erro"}</p>
                        {photo.error ? <p className="mt-1 text-danger">{photo.error}</p> : photo.data ? (
                          <p className="mt-1 text-muted">
                            Ticket {photo.data.numero_ticket || "—"}
                            {freightMode === "ton" ? " · " + (photo.data.peso_liquido_kg ? new Intl.NumberFormat("pt-BR").format(photo.data.peso_liquido_kg) + " kg" : "peso não identificado") : ""}
                            {photo.data.placa_veiculo ? " · " + photo.data.placa_veiculo : ""}
                          </p>
                        ) : null}
                        <Button type="button" size="sm" variant="ghost" className="mt-1" onClick={() => setBatchPhotos((current) => current.filter((_, itemIndex) => itemIndex !== index))}>Remover esta foto</Button>
                      </div>
                    ))}
                  </div>
                  <Button type="button" variant="ghost" disabled={ticketReading} onClick={() => setBatchPhotos([])}>Limpar lista</Button>
                </div>
              ) : null}
              {!(freightMode === "cegonha" || freightMode === "caixinha") && ticketFileName ? (
                <div className="grid gap-1 text-xs text-muted" role="status">
                  <p className="break-all">{ticketFileName}</p>
                  {ticketData && ticketImage ? <p>A foto será arquivada automaticamente junto do lançamento no Caixa.</p> : null}
                </div>
              ) : null}
              {!(freightMode === "cegonha" || freightMode === "caixinha") && ticketFileName && !ticketData && !ticketReading ? (
                <div className="grid gap-2 rounded-lg border border-warn/30 bg-warn/10 p-3 text-xs text-muted">
                  <p className="font-medium text-fg">A foto foi selecionada, mas a leitura não foi concluída.</p>
                  {ticketReadError ? <p role="alert" className="text-danger">{ticketReadError}</p> : null}
                  <p>O sistema não enviará um ticket automático sem os dados da foto.</p>
                  <Button type="button" variant="ghost" onClick={() => { setTicketFileName(""); setTicketImage(null); setTicketReadError(""); setTicketConfirmed(false); }}>
                    Remover foto e lançar manualmente
                  </Button>
                </div>
              ) : null}

              {!(freightMode === "cegonha" || freightMode === "caixinha") && ticketData ? (
                <div className="grid gap-3 rounded-xl border border-border bg-bg p-4">
                  <Field label="Número do ticket" hint="Confira com a foto">
                    <Input
                      value={ticketData.numero_ticket ?? ""}
                      onChange={(event) => { setTicketConfirmed(false); setTicketData({ ...ticketData, numero_ticket: event.target.value.toUpperCase() || null }); }}
                      autoCapitalize="characters"
                      className="h-12 font-display text-xl"
                    />
                  </Field>

                  {freightMode === "ton" ? (
                    <Field label="Peso líquido (kg)" hint="Usado somente no modo Por tonelada">
                      <Input
                        value={ticketData.peso_liquido_kg ?? ""}
                        inputMode="numeric"
                        onChange={(event) => {
                          setTicketConfirmed(false);
                          const raw = event.target.value.replace(/\D/g, "");
                          const kg = raw ? Number(raw) : null;
                          setTicketData({ ...ticketData, peso_liquido_kg: kg });
                          if (kg != null && kg > 0) {
                            setTons(new Intl.NumberFormat("pt-BR", {
                              minimumFractionDigits: 3,
                              maximumFractionDigits: 3,
                            }).format(kg / 1000));
                          } else { setTons(""); }
                        }}
                        className="h-12 font-display text-xl"
                      />
                    </Field>
                  ) : null}

                  <p className="text-sm font-semibold">Conferência dos dados</p>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {([
                      ["placa_veiculo", "Placa do veículo"], ["placa_carreta", "Placa da carreta"],
                      ["transportadora", "Transportadora"], ["operadora", "Operadora"],
                      ["contratante", "Empresa contratante"], ["destinatario", "Destinatário / recebedor"],
                      ["produto", "Produto"], ["data_ticket", "Data do ticket"], ["hora_ticket", "Horário do ticket"],
                    ] as const).map(([key, label]) => (
                      <Field key={key} label={label} hint={!ticketData[key] ? "Não identificado — confira na foto" : undefined}>
                        <Input value={ticketData[key] ?? ""}
                          className={!ticketData[key] ? "border-warn/60" : ""}
                          onChange={event => {
                            setTicketConfirmed(false);
                            const value = key.startsWith("placa_") ? event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "") : event.target.value;
                            setTicketData({ ...ticketData, [key]: value || null });
                          }} />
                      </Field>
                    ))}
                  </div>

                  {ticketData.alertas?.length ? (
                    <div className="rounded-lg border border-warn/30 bg-warn/10 p-3">
                      <div className="flex items-center gap-2 text-sm font-semibold">
                        <AlertTriangle className="size-4 text-warn" /> Confira antes de lançar
                      </div>
                      <ul className="mt-2 list-disc space-y-1 pl-5 text-xs text-muted">
                        {ticketData.alertas.map((alerta, index) => <li key={index}>{alerta}</li>)}
                      </ul>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 rounded-lg border border-ok/30 bg-ok/10 px-3 py-2 text-sm">
                      <CheckCircle2 className="size-4 text-ok" /> Leitura sem alertas automáticos.
                    </div>
                  )}

                  {fleet && ((ticketData.placa_veiculo && ticketData.placa_veiculo !== fleet.tractorPlate.replace(/[^a-z0-9]/gi, "").toUpperCase()) || (ticketData.placa_carreta && ticketData.placa_carreta !== fleet.trailerPlate.replace(/[^a-z0-9]/gi, "").toUpperCase())) ? <p role="alert" className="text-sm text-warn">A placa lida difere do conjunto selecionado. Confira a foto e o conjunto.</p> : null}
                  <label className="flex items-start gap-3 text-sm">
                    <input type="checkbox" className="mt-1 size-5" checked={ticketConfirmed} onChange={event => setTicketConfirmed(event.target.checked)} />
                    {freightMode === "ton"
                      ? "Conferi o número, o peso líquido, as placas e os dados do ticket."
                      : "Conferi o número, as placas, a transportadora e o destinatário. Nenhum peso será gravado neste modo."}
                  </label>
                  <Button type="button" variant="ghost" onClick={() => { setTicketData(null); setTicketImage(null); setTicketFileName(""); setTicketReadError(""); setTicketConfirmed(false); setTons(""); }}>
                    Descartar leitura
                  </Button>
                </div>
              ) : null}
              </>}
            </section>

          {!priceBatchMode ? <>
          {freightMode === "cegonha" || freightMode === "caixinha" ? (
            <Field label="Quantidade de viagens *" hint="Obrigatório — informe de 1 a 100">
              <Input
                type="number"
                inputMode="numeric"
                min={1}
                max={100}
                step={1}
                required
                value={tripCount}
                placeholder="Ex.: 16"
                onChange={(event) => setTripCount(event.target.value.replace(/\D/g, "").slice(0, 3))}
              />
              <p className="mt-2 text-xs text-muted">
                {batchPhotos.length > 0
                  ? batchPhotos.length + " foto(s) anexada(s). A quantidade acima define exatamente quantas viagens serão criadas."
                  : "O sistema criará exatamente esta quantidade de lançamentos separados no Caixa."}
              </p>
            </Field>
          ) : freightMode === "trip" ? (
            <Field label="Valor da diária (R$)" hint="Obrigatório — este valor será enviado para a Gerência">
              <Input
                value={dailyValue}
                onChange={(e) => setDailyValue(e.target.value)}
                inputMode="decimal"
                placeholder="0,00"
                className="h-14 font-display text-2xl tabular tracking-wide"
              />
              <p className="mt-2 text-xs text-muted">A comissão do motorista será calculada sobre o valor desta diária.</p>
            </Field>
          ) : (
            <Field label="Toneladas" hint={ticketData && freightMode === "ton" ? "Preenchido pela leitura do ticket — confira" : "Opcional"}>
              <Input
                readOnly={!!ticketData && freightMode === "ton"}
                value={tons}
                onChange={(e) => {
                  setTons(e.target.value);
                  const parsed = parseLocaleNumber(e.target.value);
                  if (ticketData && freightMode === "ton" && parsed != null) {
                    setTicketData({ ...ticketData, peso_liquido_kg: Math.round(parsed * 1000) });
                  }
                }}
                inputMode="decimal"
                placeholder="32,6"
                className="h-14 font-display text-2xl tabular tracking-wide"
              />
            </Field>
          )}

          <Button
            type="submit"
            size="lg"
            className="mt-2 h-16 font-display text-xl tracking-wide"
            disabled={report.isPending || ticketReading || ticketSending || drivers.length === 0 || (!!ticketData && !ticketConfirmed)}
          >
            {report.isPending || ticketSending ? "Enviando…" : "Depositar no painel"}
          </Button>
          </> : null}
          </fieldset>
        </form>

        <section className="mt-10">
          <h2 className="text-[11px] uppercase tracking-[0.16em] text-muted">
            Meus lançamentos
          </h2>
          {mine.length === 0 ? (
            <p className="mt-3 text-sm text-subtle">
              Nenhum ticket enviado ainda.
            </p>
          ) : (
            <ul className="mt-3 divide-y divide-border rounded-lg border border-border">
              {mine.map((r) => (
                <li
                  key={r.id}
                  className="flex items-center justify-between gap-3 px-4 py-3"
                >
                  <div>
                    <p className="font-display text-lg font-semibold tracking-wide">
                      {r.ticket}
                    </p>
                    <p className="text-xs text-muted">
                      {[
                        r.km > 0 ? `${integer(r.km)} km` : null,
                        r.tons > 0 ? `${new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 3 }).format(r.tons)} t` : null,
                        freightModeLabel(r.freightMode),
                      ].filter(Boolean).join(" · ")}
                    </p>
                  </div>
                  <Badge
                    tone={
                      r.status === "aceito"
                        ? "ok"
                        : r.status === "recusado"
                          ? "danger"
                          : "warn"
                    }
                  >
                    {r.status}
                  </Badge>
                </li>
              ))}
            </ul>
          )}
        </section>
        </div>
      </div>
    </main>
  );
}
