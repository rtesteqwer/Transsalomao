import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { BrandLockup } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { completeRequiredPasswordChange } from "@/lib/management-auth";

export const Route = createFileRoute("/trocar-senha")({ component: PasswordChangePage });

function PasswordChangePage() {
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  return (
    <main className="grid min-h-dvh place-items-center bg-bg px-5 py-8 text-fg">
      <section className="w-full max-w-md rounded-xl border border-border bg-surface p-6 shadow-panel sm:p-8">
        <BrandLockup to="/" subtitle="Segurança" />
        <h1 className="mt-7 font-display text-3xl font-semibold">Crie uma senha nova</h1>
        <p className="mt-2 text-sm text-muted">Sua senha antiga não poderá mais ser usada. Escolha uma senha exclusiva com pelo menos 10 caracteres.</p>
        <form className="mt-6 grid gap-4" onSubmit={async (event) => {
          event.preventDefault();
          if (password !== confirm) { toast.error("As senhas não são iguais."); return; }
          setBusy(true);
          try {
            const result = await completeRequiredPasswordChange({ data: { newPassword: password } });
            toast.success("Senha atualizada com segurança.");
            window.location.replace(result.role === "driver" ? "/klebersom" : "/dono");
          } catch (error) {
            toast.error(error instanceof Error ? error.message : "Não foi possível alterar a senha.");
          } finally { setBusy(false); }
        }}>
          <Field label="Nova senha"><Input type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={10} /></Field>
          <Field label="Confirmar nova senha"><Input type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} minLength={10} /></Field>
          <Button type="submit" size="lg" disabled={busy || password.length < 10 || confirm.length < 10}>{busy ? "Salvando…" : "Salvar nova senha"}</Button>
        </form>
      </section>
    </main>
  );
}
