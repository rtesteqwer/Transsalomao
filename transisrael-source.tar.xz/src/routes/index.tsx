import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Gauge, LayoutDashboard } from "lucide-react";
import type { ReactNode } from "react";
import { BrandLockup } from "@/components/brand";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh max-w-6xl flex-col px-5 py-6 sm:px-8">
        <header className="flex items-center justify-between gap-4">
          <BrandLockup />
          <p className="hidden sm:block text-[11px] uppercase tracking-[0.18em] text-muted">
            Transportadora
          </p>
        </header>

        <section className="mt-10 max-w-2xl sm:mt-16">
          <p className="text-[11px] uppercase tracking-[0.22em] text-muted">
            Do pátio ao painel
          </p>
          <h1 className="mt-3 font-display text-5xl font-semibold leading-[0.95] tracking-tight sm:text-6xl">
            Dois aplicativos.
            <span className="block text-muted">Uma operação.</span>
          </h1>
          <p className="mt-5 max-w-md text-base leading-relaxed text-muted">
            O motorista lança ticket, KM da carreta e toneladas. A gerência
            recebe na hora, fecha o frete e acompanha diesel, comissão e
            resultado.
          </p>
        </section>

        <div className="mt-10 grid flex-1 gap-4 lg:grid-cols-2 lg:gap-5">
          <AppCard
            to="/motorista"
            kicker="App do motorista"
            title="Lançar viagem"
            body="Três campos, tela grande, feito para a cabine. O ticket cai direto no Painel Gerência."
            icon={<Gauge className="size-5" />}
            cta="Abrir app do motorista"
            meta="Acesso do motorista com login"
          />
          <AppCard
            to="/dono"
            kicker="Painel Gerência"
            title="Gerência da frota"
            body="Caixa de lançamentos, viagens, totais por motorista e conjunto, combustível e resultado."
            icon={<LayoutDashboard className="size-5" />}
            cta="Abrir Painel Gerência"
            meta="Acesso restrito à gerência"
            invert
          />
        </div>

        <footer className="mt-8 pb-4 text-xs text-subtle">
          Os lançamentos do motorista aparecem automaticamente no Painel Gerência.
        </footer>
      </div>
    </main>
  );
}

function AppCard({
  to,
  kicker,
  title,
  body,
  icon,
  cta,
  meta,
  invert,
}: {
  to: string;
  kicker: string;
  title: string;
  body: string;
  icon: ReactNode;
  cta: string;
  meta: string;
  invert?: boolean;
}) {
  return (
    <Link
      to={to}
      className={
        invert
          ? "group flex min-h-[280px] flex-col rounded-xl border border-accent/20 bg-accent p-6 text-accent-fg sm:p-8"
          : "group flex min-h-[280px] flex-col rounded-xl border border-border bg-surface p-6 sm:p-8"
      }
    >
      <div className="flex items-center justify-between">
        <span
          className={
            invert
              ? "text-[11px] uppercase tracking-[0.18em] text-accent-fg/70"
              : "text-[11px] uppercase tracking-[0.18em] text-muted"
          }
        >
          {kicker}
        </span>
        <span
          className={
            invert
              ? "grid size-10 place-items-center rounded-md bg-accent-fg/10"
              : "grid size-10 place-items-center rounded-md bg-surface-2 text-accent"
          }
        >
          {icon}
        </span>
      </div>
      <h2 className="mt-8 font-display text-4xl font-semibold tracking-tight">
        {title}
      </h2>
      <p
        className={
          invert
            ? "mt-3 max-w-sm text-sm leading-relaxed text-accent-fg/75"
            : "mt-3 max-w-sm text-sm leading-relaxed text-muted"
        }
      >
        {body}
      </p>
      <div className="mt-auto flex items-end justify-between gap-3 pt-8">
        <span className="text-xs tabular">{meta}</span>
        <span className="inline-flex items-center gap-2 text-sm font-medium">
          {cta}
          <ArrowRight className="size-4 transition-transform duration-150 group-hover:translate-x-0.5" />
        </span>
      </div>
    </Link>
  );
}
