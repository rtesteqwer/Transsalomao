import { createFileRoute } from "@tanstack/react-router";
export const Route = createFileRoute("/api/assistant/programmer-proxy")({ server: { handlers: { POST: async () => Response.json({ok:false, message:"Integração não configurada nesta instalação."}, {status:403}) } } });
