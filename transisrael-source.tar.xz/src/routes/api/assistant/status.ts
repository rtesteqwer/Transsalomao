import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/assistant/status")({
  server: {
    handlers: {
      GET: async () => Response.json({
        ok: true,
        aiConfigured: Boolean(process.env.OPENAI_API_KEY?.trim()),
        model: process.env.OPENAI_ASSISTANT_MODEL?.trim() || "gpt-5.6-sol",
      }, { headers: { "Cache-Control": "no-store" } }),
    },
  },
});
