import { createFileRoute } from "@tanstack/react-router";
import { changeManagementPasswordWithCurrent } from "@/lib/management-auth.server";

export const Route = createFileRoute("/api/management/password")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: any = {};
        try { body = await request.json(); } catch {}
        const username = String(body?.username || "").trim();
        const currentPassword = String(body?.currentPassword || "");
        const newPassword = String(body?.newPassword || "");
        if (!username || !currentPassword || !newPassword) {
          return Response.json({ ok: false, code: "MISSING_FIELDS" }, { status: 400, headers: { "Cache-Control": "no-store" } });
        }
        try {
          const result = await changeManagementPasswordWithCurrent(username, currentPassword, newPassword);
          if (!result.ok) return Response.json({ ok: false, code: "INVALID_CREDENTIALS" }, { status: 401, headers: { "Cache-Control": "no-store" } });
          return Response.json({ ok: true, username: result.username }, { headers: { "Cache-Control": "no-store" } });
        } catch (error) {
          const message = error instanceof Error ? error.message : "Falha ao alterar senha.";
          return Response.json({ ok: false, code: "PASSWORD_CHANGE_FAILED", message }, { status: 400, headers: { "Cache-Control": "no-store" } });
        }
      },
    },
  },
});
