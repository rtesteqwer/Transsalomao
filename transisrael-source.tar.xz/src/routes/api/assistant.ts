import { createFileRoute } from "@tanstack/react-router";
import { getSql } from "@/lib/db";
import { authenticateAssistantRequest } from "@/lib/assistant-auth.server";
import { getSalomaoOpenAIKeys, salomaoModel } from "@/lib/salomao-ai.server";
import { hashPassword } from "@/lib/password-security.server";

export const Route = createFileRoute("/api/assistant")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const auth = await authenticateAssistantRequest(request);
        if (!auth) return out({ ok: false, authenticated: false }, 401);
        const aiKeys = await getSalomaoOpenAIKeys();
        return out({
          ok: true,
          authenticated: true,
          username: auth.username,
          via: auth.via,
          aiConfigured: aiKeys.length > 0,
          model: modelName(),
          capabilities: ["consultar", "criar", "editar", "lançar", "aprovar", "configurar acesso"],
        });
      },

      POST: async ({ request }) => {
        const auth = await authenticateAssistantRequest(request);
        if (!auth) return out({ ok: false, code: "LOGIN_REQUIRED", answer: "Faça a autenticação do Israel IA para liberar o acesso independente." }, 401);
        if (request.headers.get("x-salomao-app") !== "1") return out({ ok: false, code: "APP_HEADER_REQUIRED" }, 403);

        let body: any = {};
        try { body = await request.json(); } catch { return out({ ok: false, code: "INVALID_JSON" }, 400); }
        const message = String(body?.message ?? "").trim().slice(0, 5000);
        if (!message) return out({ ok: false, code: "EMPTY_MESSAGE" }, 400);

        const history: Turn[] = Array.isArray(body?.history)
          ? body.history.slice(-30).map((x: any) => ({
              role: x?.role === "assistant" ? "assistant" : "user",
              content: String(x?.content ?? "").slice(0, 2800),
            })).filter((x: Turn) => x.content.trim())
          : [];

        // Toda ação operacional passa primeiro pelo GPT com ferramentas estritas.
        // O modo local permanece somente para consultas; ele nunca grava dados.
        const apiKeys = await getSalomaoOpenAIKeys();
        let lastAiError = "";
        for (const apiKey of apiKeys) {
          try {
            return out({ ok: true, mode: "gpt", answer: await gptAnswer(message, history, apiKey, auth.username) });
          } catch (error: any) {
            lastAiError = String(error?.message ?? error ?? "");
            console.error("[salomao-ai-v5] GPT unavailable", error);
          }
        }

        if (apiKeys.length) {
          if (lastAiError.includes("billing_not_active") || lastAiError.includes("credit_balance_exhausted") || lastAiError.includes("insufficient_quota")) {
            return out({
              ok: false,
              mode: "gpt-unavailable",
              code: "OPENAI_BILLING_INACTIVE",
              answer: "A Israel IA está conectada à OpenAI, mas a conta da API está sem créditos. Não vou executar comandos por um modo inferior para evitar alterações erradas."
            }, 503);
          }
          if (lastAiError.includes("invalid_api_key") || lastAiError.includes("Incorrect API key")) {
            return out({
              ok: false,
              mode: "gpt-unavailable",
              code: "OPENAI_KEY_INVALID",
              answer: "A chave da OpenAI configurada foi recusada. Não vou executar comandos por um modo inferior até existir uma chave válida."
            }, 503);
          }
          return out({
            ok: false,
            mode: "gpt-unavailable",
            code: "OPENAI_UNAVAILABLE",
            answer: "A OpenAI está temporariamente indisponível. Nenhuma alteração foi executada."
          }, 503);
        }

        if (isWriteIntent(norm(message))) {
          return out({
            ok: false,
            mode: "gpt-required",
            code: "OPENAI_REQUIRED_FOR_WRITE",
            answer: "A API da OpenAI precisa estar ativa para executar comandos que alteram o Trans Israel. Nenhuma alteração foi feita."
          }, 503);
        }

        const local = await localAnswer(message, history);
        return out({ ok: true, mode: "local-readonly", ...local });
      },
    },
  },
});

type Row = Record<string, any>;
type Turn = { role: "user" | "assistant"; content: string };
type Snapshot = { drivers: Row[]; fleets: Row[]; trips: Row[]; fuelings: Row[]; expenses: Row[]; reports: Row[]; prices: Row[]; maintenance: Row[]; odometers: Row[] };

function out(value: unknown, status = 200) {
  return Response.json(value, { status, headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
}
function modelName() { return salomaoModel(); }
function n(v: unknown) { const x = Number(v ?? 0); return Number.isFinite(x) ? x : 0; }
function norm(v: unknown) { return String(v ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR").replace(/\s+/g, " ").trim(); }
function brl(v: number) { return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v); }
function dec(v: number, d = 2) { return new Intl.NumberFormat("pt-BR", { minimumFractionDigits: d, maximumFractionDigits: d }).format(v); }
function iso(v: unknown) { const s = String(v ?? "").slice(0, 10); return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : ""; }
function todayBR() { return new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date()); }
function newId(prefix: string) { return `${prefix}_${crypto.randomUUID().replace(/-/g, "").slice(0, 10)}`; }
function hasAny(t: string, words: string[]) { return words.some((w) => t.includes(w)); }
function isWriteIntent(t: string) {
  return hasAny(t, ["adicionar", "adicione", "criar", "crie", "cadastrar", "cadastre", "registrar", "registre", "lancar", "lance", "editar", "edite", "alterar", "altere", "mudar", "mude", "aprovar", "aprove", "aceitar", "aceite", "rejeitar", "rejeite", "excluir", "exclua", "apagar", "apague", "desativar", "desative", "remover"]);
}
function isDestructive(t: string) { return hasAny(t, ["excluir", "exclua", "apagar", "apague", "remover tudo", "deletar", "delete"]); }
function explicitlyConfirmed(t: string) { return hasAny(t, ["confirmo", "confirmar", "pode executar", "pode apagar", "pode excluir", "sim, execute", "sim execute"]); }
function redactSecrets(text: string) {
  return text.replace(/(senha\s*(?:é|e|:|=)?\s*)(\S+)/gi, "$1••••••").replace(/(password\s*[:=]?\s*)(\S+)/gi, "$1••••••");
}

async function isFelipeDeveloperIdentity(actor:string){
  const sql=await getSql();
  const rows=await sql<Row>`select id,status from management_users where lower(username)=lower(${String(actor??"").trim()}) limit 1`;
  return rows[0]?.id==="adm_felipe"&&rows[0]?.status==="ativo";
}

async function ensureDeveloperQueue(){
  const sql=await getSql();
  await sql`
    create table if not exists salomao_code_changes(
      id text primary key,
      requested_by text not null,
      title text not null,
      request_text text not null,
      scope text not null default 'full',
      publish_requested boolean not null default false,
      status text not null default 'queued',
      branch text,
      commit_sha text,
      pull_request_url text,
      result_summary text,
      error_text text,
      created_at timestamptz not null default now(),
      started_at timestamptz,
      completed_at timestamptz,
      updated_at timestamptz not null default now()
    )
  `;
  await sql`create index if not exists salomao_code_changes_status_idx on salomao_code_changes(status,created_at)`;
}

async function developerSystemChange(args:Row,actor:string){
  if(!(await isFelipeDeveloperIdentity(actor)))throw new Error("DEVELOPER_FORBIDDEN");
  await ensureDeveloperQueue();
  const sql=await getSql();
  const action=String(args.action??"request");
  if(action==="request"){
    const title=String(args.title??"").trim().slice(0,180);
    const requestText=String(args.request??"").trim().slice(0,12000);
    const scope=["web","android","backend","database","full"].includes(String(args.scope))?String(args.scope):"full";
    const publish=args.publish_to_production===true;
    if(!title||!requestText)throw new Error("Informe o título e a alteração que deve ser programada.");
    const id="chg_"+crypto.randomUUID().replace(/-/g,"").slice(0,12);
    await sql`insert into salomao_code_changes(id,requested_by,title,request_text,scope,publish_requested,status,updated_at)
      values(${id},${actor},${title},${requestText},${scope},${publish},'queued',now())`;
    return{ok:true,action:"queued",id,title,scope,publishRequested:publish,status:"queued"};
  }
  if(action==="list"){
    const rows=await sql<Row>`select id,title,scope,publish_requested,status,branch,commit_sha,pull_request_url,result_summary,error_text,created_at,completed_at from salomao_code_changes where requested_by=${actor} order by created_at desc limit 25`;
    return{ok:true,action:"list",rows};
  }
  const id=String(args.change_id??"").trim();
  if(!id)throw new Error("Informe o identificador da alteração.");
  if(action==="cancel"){
    const rows=await sql<Row>`update salomao_code_changes set status='cancelled',updated_at=now(),completed_at=now() where id=${id} and requested_by=${actor} and status='queued' returning id,title,status`;
    if(!rows[0])throw new Error("Alteração não encontrada ou já em processamento.");
    return{ok:true,action:"cancelled",...rows[0]};
  }
  const rows=await sql<Row>`select id,title,scope,publish_requested,status,branch,commit_sha,pull_request_url,result_summary,error_text,created_at,started_at,completed_at from salomao_code_changes where id=${id} and requested_by=${actor} limit 1`;
  if(!rows[0])throw new Error("Alteração não encontrada.");
  return{ok:true,action:"status",change:rows[0]};
}

async function snapshot(): Promise<Snapshot> {
  const sql = await getSql();
  await sql`create table if not exists fleet_odometer_history (id text primary key, fleet_id text not null, driver_id text, odometer_km integer not null, observed_date date not null, source_name text, source_hash text, notes text, created_at timestamptz not null default now())`;
  await sql`create table if not exists fleet_maintenance_history (id text primary key, fleet_id text not null, driver_id text, observed_date date not null, description text not null, amount numeric, odometer_km integer, source_name text, source_hash text, raw_data jsonb, created_at timestamptz not null default now())`;
  const [drivers, fleets, trips, fuelings, expenses, reports, prices, maintenance, odometers] = await Promise.all([
    sql<Row>`select * from drivers order by name`,
    sql<Row>`select * from fleets order by name`,
    sql<Row>`select * from trips order by date desc, code desc`,
    sql<Row>`select * from fuelings order by date desc, created_at desc`,
    sql<Row>`select * from expenses order by date desc, created_at desc`,
    sql<Row>`select * from reports order by created_at desc`,
    sql<Row>`select * from freight_prices`,
    sql<Row>`select * from fleet_maintenance_history order by observed_date desc, created_at desc`,
    sql<Row>`select * from fleet_odometer_history order by observed_date desc, created_at desc`,
  ]);
  return { drivers, fleets, trips, fuelings, expenses, reports, prices, maintenance, odometers };
}

function score(name: unknown, query: unknown) {
  const a = norm(name), b = norm(query);
  if (!a || !b) return 0;
  if (a === b) return 100;
  if (a.startsWith(b) || b.startsWith(a)) return 92;
  if (a.includes(b) || b.includes(a)) return 82;
  const bt = b.split(" ").filter((x) => x.length > 2), at = a.split(" ");
  const hits = bt.filter((x) => at.some((y) => y === x || y.startsWith(x) || x.startsWith(y))).length;
  return bt.length ? Math.round(hits / bt.length * 70) : 0;
}
function findDriver(s: Snapshot, query: string) {
  const ranked = s.drivers.map((x) => ({ x, s: score(x.name, query) })).filter((x) => x.s > 0).sort((a,b)=>b.s-a.s);
  return { value: ranked[0]?.x ?? null, score: ranked[0]?.s ?? 0, candidates: ranked.slice(0,5).map((x)=>x.x.name) };
}
function findFleet(s: Snapshot, query: string) {
  const ranked = s.fleets.map((x) => ({ x, s: Math.max(score(x.name,query),score(x.tractor_plate,query),score(x.trailer_plate,query),score(x.model,query)) })).filter((x)=>x.s>0).sort((a,b)=>b.s-a.s);
  return { value: ranked[0]?.x ?? null, score: ranked[0]?.s ?? 0, candidates: ranked.slice(0,5).map((x)=>x.x.name) };
}
function resolveUniqueDriver(s: Snapshot, query: string) {
  const ranked = s.drivers.map((x) => ({ x, s: score(x.name, query) })).filter((x) => x.s > 0).sort((a,b)=>b.s-a.s);
  const first = ranked[0], second = ranked[1];
  if (!first || first.s < 70) throw new Error(`Não encontrei um motorista com segurança para “${query}”.`);
  if (second && first.s < 100 && second.s >= first.s - 8) {
    throw new Error(`Há mais de um motorista parecido com “${query}”: ${ranked.slice(0,4).map((x)=>x.x.name).join(", ")}. Informe o nome completo.`);
  }
  return first.x;
}
function resolveUniqueFleet(s: Snapshot, query: string) {
  const ranked = s.fleets.map((x) => ({ x, s: Math.max(score(x.name,query),score(x.tractor_plate,query),score(x.trailer_plate,query),score(x.model,query)) })).filter((x)=>x.s>0).sort((a,b)=>b.s-a.s);
  const first = ranked[0], second = ranked[1];
  if (!first || first.s < 70) throw new Error(`Não encontrei um conjunto com segurança para “${query}”.`);
  if (second && first.s < 100 && second.s >= first.s - 8) {
    throw new Error(`Há mais de um conjunto parecido com “${query}”: ${ranked.slice(0,4).map((x)=>x.x.name).join(", ")}. Informe o conjunto ou a placa completa.`);
  }
  return first.x;
}
function freight(t: Row) { return t.freight_mode === "ton" ? n(t.net_weight) * n(t.price_per_ton) : n(t.price_per_trip); }
function dateOk(row: Row, from?: string | null, to?: string | null) { const d=iso(row.date); return (!from||!d||d>=from)&&(!to||!d||d<=to); }
function labelMode(m: unknown) { return m === "trip" ? "Diária" : m === "cegonha" ? "Cegonha" : m === "caixinha" ? "Caixinha" : "Por tonelada"; }

function enrichTrip(s: Snapshot, t: Row) {
  const d=s.drivers.find((x)=>x.id===t.driver_id), f=s.fleets.find((x)=>x.id===t.fleet_id), value=freight(t);
  return { id:t.id,code:t.code,date:iso(t.date),client:t.client,origin:t.origin,destination:t.destination,driverId:t.driver_id,driver:d?.name??"Motorista removido",fleetId:t.fleet_id,fleet:f?.name??"Conjunto removido",tractorPlate:f?.tractor_plate??"",trailerPlate:f?.trailer_plate??"",mode:labelMode(t.freight_mode),freightMode:t.freight_mode,loadedTons:n(t.loaded_tons),grossWeight:n(t.gross_weight),netWeight:n(t.net_weight),pricePerTon:n(t.price_per_ton),pricePerTrip:n(t.price_per_trip),kmStart:n(t.km_start),kmEnd:n(t.km_end),km:Math.max(0,n(t.km_end)-n(t.km_start)),freight:value,commission:value*n(d?.commission_pct) };
}

async function querySystem(args: Row) {
  const s=await snapshot(), op=String(args.operation??"system_summary");
  const from=iso(args.date_from)||null,to=iso(args.date_to)||null,limit=Math.max(1,Math.min(100,Math.floor(n(args.limit)||30)));
  const driverQ=String(args.driver??"").trim(),fleetQ=String(args.fleet??"").trim();
  const dm=driverQ?findDriver(s,driverQ):{value:null,score:0,candidates:[] as string[]};
  const fm=fleetQ?findFleet(s,fleetQ):{value:null,score:0,candidates:[] as string[]};
  if(driverQ&&(!dm.value||dm.score<55))return{found:false,entity:"motorista",candidates:dm.candidates};
  if(fleetQ&&(!fm.value||fm.score<55))return{found:false,entity:"conjunto",candidates:fm.candidates};
  const d=dm.value,f=fm.value;
  const trips=s.trips.filter((t)=>(!d||t.driver_id===d.id)&&(!f||t.fleet_id===f.id)&&dateOk(t,from,to)).map((t)=>enrichTrip(s,t));
  const fuels=s.fuelings.filter((x)=>(!d||x.driver_id===d.id)&&(!f||x.fleet_id===f.id)&&dateOk(x,from,to)).map((x)=>{const fl=s.fleets.find((y)=>y.id===x.fleet_id),dr=s.drivers.find((y)=>y.id===x.driver_id);return{id:x.id,date:iso(x.date),driverId:x.driver_id,driver:dr?.name??"",fleetId:x.fleet_id,fleet:fl?.name??"",station:x.station,km:n(x.km),liters:n(x.liters),pricePerLiter:n(x.price_per_liter),total:n(x.liters)*n(x.price_per_liter),notes:x.notes};});
  const expenses=s.expenses.filter((x)=>(!d||x.driver_id===d.id)&&(!f||x.fleet_id===f.id)&&dateOk(x,from,to)).map((x)=>{const fl=s.fleets.find((y)=>y.id===x.fleet_id),dr=s.drivers.find((y)=>y.id===x.driver_id);return{id:x.id,date:iso(x.date),driverId:x.driver_id,driver:dr?.name??"",fleetId:x.fleet_id,fleet:fl?.name??"",assetType:x.asset_type??null,category:x.category,description:x.description,amount:n(x.amount),notes:x.notes};});
  const pending=s.reports.filter((x)=>x.status==="pendente"&&(!d||x.driver_id===d.id)&&(!f||x.fleet_id===f.id)).map((x)=>({id:x.id,ticket:x.ticket,driver:s.drivers.find((y)=>y.id===x.driver_id)?.name??"",fleet:s.fleets.find((y)=>y.id===x.fleet_id)?.name??"",mode:labelMode(x.freight_mode),tons:n(x.tons),dailyValue:n(x.daily_value),km:n(x.km),createdAt:String(x.created_at??"")}));
  const tripFreight=trips.reduce((a,x)=>a+x.freight,0),commissions=trips.reduce((a,x)=>a+x.commission,0),fuelCost=fuels.reduce((a,x)=>a+x.total,0),expenseTotal=expenses.reduce((a,x)=>a+x.amount,0);
  const summary={tripCount:trips.length,netTons:trips.reduce((a,x)=>a+x.netWeight,0),km:trips.reduce((a,x)=>a+x.km,0),freight:tripFreight,commission:commissions,afterCommission:tripFreight-commissions,fuelCost,expenses:expenseTotal,pendingReports:pending.length};

  if(op==="driver_overview")return{found:!!d,driver:d?{id:d.id,name:d.name,phone:d.phone,category:d.category,status:d.status,commissionPct:n(d.commission_pct)}:null,summary,fleets:[...new Set(s.trips.filter((t)=>d&&t.driver_id===d.id).map((t)=>s.fleets.find((x)=>x.id===t.fleet_id)?.name).filter(Boolean))],recentTrips:trips.slice(0,limit),recentFuelings:fuels.slice(0,limit),recentExpenses:expenses.slice(0,limit),pending:pending.slice(0,limit),period:{from,to}};
  if(op==="fleet_overview"){
    const maintenance=f?s.maintenance.filter((x)=>x.fleet_id===f.id&&dateOk({date:x.observed_date},from,to)).slice(0,limit).map((x)=>({id:x.id,date:iso(x.observed_date),description:x.description,amount:n(x.amount),odometerKm:n(x.odometer_km),source:x.source_name})): [];
    const odometers=f?s.odometers.filter((x)=>x.fleet_id===f.id&&dateOk({date:x.observed_date},from,to)).slice(0,limit).map((x)=>({id:x.id,date:iso(x.observed_date),odometerKm:n(x.odometer_km),driver:s.drivers.find((d)=>d.id===x.driver_id)?.name??"",notes:x.notes,source:x.source_name})): [];
    return{found:!!f,fleet:f?{id:f.id,name:f.name,tractorPlate:f.tractor_plate,trailerPlate:f.trailer_plate,model:f.model,status:f.status}:null,summary,recentTrips:trips.slice(0,limit),recentFuelings:fuels.slice(0,limit),recentExpenses:expenses.slice(0,limit),maintenance,odometerHistory:odometers,lastOdometer:odometers[0]??null,period:{from,to}};
  }
  if(op==="trips")return{count:trips.length,totalFreight:tripFreight,rows:trips.slice(0,limit),period:{from,to}};
  if(op==="fuelings")return{count:fuels.length,totalCost:fuelCost,rows:fuels.slice(0,limit),period:{from,to}};
  if(op==="expenses")return{count:expenses.length,total:expenseTotal,rows:expenses.slice(0,limit),period:{from,to}};
  if(op==="pending")return{count:pending.length,rows:pending.slice(0,limit)};
  if(op==="management_users"){
    const sql=await getSql();
    const rows=await sql<Row>`select username,role,status,created_at,updated_at from management_users order by lower(username)`;
    return{count:rows.length,rows};
  }
  if(op==="drivers")return{count:s.drivers.length,rows:s.drivers.slice(0,limit).map((x)=>({id:x.id,name:x.name,phone:x.phone,category:x.category,status:x.status,commissionPct:n(x.commission_pct)}))};
  if(op==="fleets")return{count:s.fleets.length,rows:s.fleets.slice(0,limit).map((x)=>({id:x.id,name:x.name,tractorPlate:x.tractor_plate,trailerPlate:x.trailer_plate,model:x.model,status:x.status}))};
  if(op==="fleet_history"){
    const maintenance=s.maintenance.filter((x)=>(!f||x.fleet_id===f.id)&&(!d||x.driver_id===d.id)&&dateOk({date:x.observed_date},from,to)).slice(0,limit).map((x)=>({id:x.id,date:iso(x.observed_date),fleet:s.fleets.find((y)=>y.id===x.fleet_id)?.name??"",driver:s.drivers.find((y)=>y.id===x.driver_id)?.name??"",description:x.description,amount:n(x.amount),odometerKm:n(x.odometer_km),source:x.source_name}));
    const odometers=s.odometers.filter((x)=>(!f||x.fleet_id===f.id)&&(!d||x.driver_id===d.id)&&dateOk({date:x.observed_date},from,to)).slice(0,limit).map((x)=>({id:x.id,date:iso(x.observed_date),fleet:s.fleets.find((y)=>y.id===x.fleet_id)?.name??"",driver:s.drivers.find((y)=>y.id===x.driver_id)?.name??"",odometerKm:n(x.odometer_km),notes:x.notes,source:x.source_name}));
    return{maintenance,odometers,lastOdometer:odometers[0]??null,period:{from,to}};
  }
  if(op==="freight_prices")return{rows:s.prices.map((x)=>({mode:x.mode,price:n(x.price),updatedAt:String(x.updated_at??"")}))};
  if(op==="reports"){
    const rows=s.reports.filter((x)=>(!d||x.driver_id===d.id)&&(!f||x.fleet_id===f.id)).slice(0,limit).map((x)=>({
      id:x.id,ticket:x.ticket,status:x.status,driverId:x.driver_id,driver:s.drivers.find((y)=>y.id===x.driver_id)?.name??"",
      fleetId:x.fleet_id,fleet:s.fleets.find((y)=>y.id===x.fleet_id)?.name??"",freightMode:x.freight_mode??null,
      tons:n(x.tons),dailyValue:n(x.daily_value),km:n(x.km),loadingDate:iso(x.loading_date),tripId:x.trip_id??null,createdAt:String(x.created_at??"")
    }));
    return{count:rows.length,rows};
  }
  if(op==="financial_by_driver"){
    const rows=s.drivers.map((dr)=>{const tt=s.trips.filter((t)=>t.driver_id===dr.id&&dateOk(t,from,to)).map((t)=>enrichTrip(s,t));const fr=tt.reduce((a,x)=>a+x.freight,0),co=tt.reduce((a,x)=>a+x.commission,0);return{driver:dr.name,commissionPct:n(dr.commission_pct),trips:tt.length,netTons:tt.reduce((a,x)=>a+x.netWeight,0),km:tt.reduce((a,x)=>a+x.km,0),freight:fr,commission:co,afterCommission:fr-co};}).sort((a,b)=>b.freight-a.freight);
    return{period:{from,to},rows,totals:{trips:rows.reduce((a,x)=>a+x.trips,0),freight:rows.reduce((a,x)=>a+x.freight,0),commission:rows.reduce((a,x)=>a+x.commission,0)}};
  }
  return{period:{from,to},activeDrivers:s.drivers.filter((x)=>x.status==="ativo").length,activeFleets:s.fleets.filter((x)=>x.status==="ativo").length,summary,pendingReports:s.reports.filter((x)=>x.status==="pendente").length,freightPrices:Object.fromEntries(s.prices.map((x)=>[x.mode,n(x.price)]))};
}

async function nextTicketCode() {
  const sql=await getSql();
  const rows=await sql<{next:string}>`select nextval('transisrael_ticket_seq')::text as next`;
  return String(rows[0]?.next ?? "1");
}
async function globalPrice(mode:string){
  const sql=await getSql();
  const rows=await sql<{price:number}>`select price from freight_prices where mode=${mode} limit 1`;
  return n(rows[0]?.price);
}

async function mutateSystem(args: Row, actor: string) {
  const op=String(args.operation??"");
  const sql=await getSql();
  const s=await snapshot();

  if(op==="management_user_upsert"){
    const username=String(args.username??"").trim();
    const password=String(args.password??"");
    const role=String(args.role??"admin").trim()||"admin";
    if(!username)throw new Error("Informe o login que deve ser criado ou alterado.");
    const existing=await sql<Row>`select id,username from management_users where lower(username)=lower(${username}) limit 1`;
    if(!existing[0]&&!password)throw new Error("Informe também a senha do novo login.");
    if(password && password.length < 10) throw new Error("Use uma senha com pelo menos 10 caracteres.");
    const id=existing[0]?.id||newId("adm");
    if(password){
      await sql`
        insert into management_users(id,username,password_hash,role,status,updated_at)
        values(${id},${username},${await hashPassword(password)},${role},'ativo',now())
        on conflict(id) do update set username=excluded.username,password_hash=excluded.password_hash,role=excluded.role,status='ativo',updated_at=now()
      `;
    }else{
      await sql`update management_users set username=${username},role=${role},status='ativo',updated_at=now() where id=${id}`;
    }
    return{ok:true,action:existing[0]?"updated":"created",username,role,actor};
  }

  if(op==="management_user_disable"){
    const username=String(args.username??"").trim();
    if(!username)throw new Error("Informe o login que deve ser desativado.");
    if(norm(username)===norm(actor))throw new Error("O Salomão não desativa o próprio login usado nesta sessão.");
    const rows=await sql<Row>`update management_users set status='inativo',updated_at=now() where lower(username)=lower(${username}) returning username`;
    if(!rows[0])throw new Error("Login não encontrado.");
    return{ok:true,action:"disabled",username:rows[0].username};
  }

  if(op==="driver_upsert"){
    const name=String(args.name??"").trim();
    if(!name)throw new Error("Informe o nome do motorista.");
    const existing=s.drivers.find((x)=>norm(x.name)===norm(name));
    const id=String(args.id??existing?.id??newId("drv"));
    const phone=String(args.phone??existing?.phone??"");
    const category=String(args.category??existing?.category??"E");
    const status=String(args.status??existing?.status??"ativo")==="inativo"?"inativo":"ativo";
    let pct=n(args.commission_pct ?? args.commissionPct ?? existing?.commission_pct ?? 0.2);
    if(pct>1)pct=pct/100;
    if(pct<0||pct>1)throw new Error("Comissão inválida.");
    await sql`
      insert into drivers(id,name,phone,category,status,commission_pct)
      values(${id},${name},${phone},${category},${status},${pct})
      on conflict(id) do update set name=excluded.name,phone=excluded.phone,category=excluded.category,status=excluded.status,commission_pct=excluded.commission_pct
    `;
    return{ok:true,action:existing?"updated":"created",entity:"driver",id,name,commissionPct:pct};
  }

  if(op==="fleet_upsert"){
    const name=String(args.name??"").trim();
    const tractor=String(args.tractor_plate??args.tractorPlate??"").trim();
    const trailer=String(args.trailer_plate??args.trailerPlate??"").trim();
    if(!name)throw new Error("Informe o nome do conjunto.");
    const existing=s.fleets.find((x)=>norm(x.name)===norm(name));
    if(!existing&&!tractor)throw new Error("Informe a placa do cavalo.");
    if(!existing&&!trailer)throw new Error("Informe a placa da carreta.");
    const id=String(args.id??existing?.id??newId("flt"));
    const model=String(args.model??existing?.model??"");
    const status=String(args.status??existing?.status??"ativo")==="inativo"?"inativo":"ativo";
    await sql`
      insert into fleets(id,name,tractor_plate,trailer_plate,model,status)
      values(${id},${name},${tractor||existing?.tractor_plate||""},${trailer||existing?.trailer_plate||""},${model},${status})
      on conflict(id) do update set name=excluded.name,tractor_plate=excluded.tractor_plate,trailer_plate=excluded.trailer_plate,model=excluded.model,status=excluded.status
    `;
    return{ok:true,action:existing?"updated":"created",entity:"fleet",id,name};
  }

  if(op==="freight_prices_update"){
    const trip=n(args.trip),cegonha=n(args.cegonha),caixinha=n(args.caixinha);
    if(trip<=0||cegonha<=0||caixinha<=0)throw new Error("Informe valores maiores que zero para Diária, Cegonha e Caixinha.");
    for(const [mode,price] of [["trip",trip],["cegonha",cegonha],["caixinha",caixinha]] as const){
      await sql`insert into freight_prices(mode,price,updated_at) values(${mode},${price},now()) on conflict(mode) do update set price=excluded.price,updated_at=now()`;
      await sql`update trips set price_per_trip=${price} where freight_mode=${mode}`;
    }
    return{ok:true,trip,cegonha,caixinha};
  }

  if(op==="fueling_upsert"){
    const fleet=resolveUniqueFleet(s,String(args.fleet??args.fleet_name??""));
    const driverQ=String(args.driver??args.driver_name??"").trim();
    const driver=driverQ?resolveUniqueDriver(s,driverQ):null;
    const liters=n(args.liters),price=n(args.price_per_liter??args.pricePerLiter);
    if(liters<=0)throw new Error("Informe os litros abastecidos.");
    if(price<=0)throw new Error("Informe o preço por litro.");
    const id=String(args.id??newId("fuel"));
    const date=iso(args.date)||todayBR();
    await sql`
      insert into fuelings(id,date,driver_id,fleet_id,station,km,liters,price_per_liter,notes)
      values(${id},${date},${driver?.id??null},${fleet.id},${String(args.station??"")},${n(args.km)},${liters},${price},${String(args.notes??"")})
      on conflict(id) do update set date=excluded.date,driver_id=excluded.driver_id,fleet_id=excluded.fleet_id,station=excluded.station,km=excluded.km,liters=excluded.liters,price_per_liter=excluded.price_per_liter,notes=excluded.notes
    `;
    return{ok:true,entity:"fueling",id,date,driver:driver?.name??null,fleet:fleet.name,total:liters*price};
  }

  if(op==="expense_upsert"){
    const category=String(args.category??"").trim(),description=String(args.description??"").trim(),amount=n(args.amount);
    if(!category||!description||amount<=0)throw new Error("Informe categoria, descrição e valor da despesa.");
    const isAdvance=norm(category)==="adiantamento";
    const driverQ=String(args.driver??"").trim(),fleetQ=String(args.fleet??"").trim();
    const driver=driverQ?resolveUniqueDriver(s,driverQ):null;
    const fleet=fleetQ?resolveUniqueFleet(s,fleetQ):null;
    if(isAdvance&&!driver)throw new Error("Informe o motorista que recebeu o adiantamento.");
    if(!isAdvance&&!fleet)throw new Error("Informe o conjunto da despesa.");
    const assetType=String(args.asset_type??args.assetType??"tractor")==="trailer"?"trailer":"tractor";
    const id=String(args.id??newId("exp")),date=iso(args.date)||todayBR();
    await sql`
      insert into expenses(id,date,fleet_id,asset_type,driver_id,category,description,amount,notes)
      values(${id},${date},${isAdvance?null:fleet?.id??null},${isAdvance?null:assetType},${isAdvance?driver?.id??null:null},${category},${description},${amount},${String(args.notes??"")})
      on conflict(id) do update set date=excluded.date,fleet_id=excluded.fleet_id,asset_type=excluded.asset_type,driver_id=excluded.driver_id,category=excluded.category,description=excluded.description,amount=excluded.amount,notes=excluded.notes
    `;
    return{ok:true,entity:"expense",id,date,amount};
  }

  if(op==="trip_upsert"){
    const driver=resolveUniqueDriver(s,String(args.driver??""));
    const fleet=resolveUniqueFleet(s,String(args.fleet??""));
    const requestedMode=String(args.freight_mode??"");
    if(!["ton","trip","cegonha","caixinha"].includes(requestedMode))throw new Error("Informe o modo da viagem: por tonelada, diária, cegonha ou caixinha.");
    const mode=requestedMode;
    const id=String(args.id??newId("trip"));
    const code=args.id?String(args.code??"").trim():await nextTicketCode();
    const date=iso(args.date)||todayBR();
    const net=n(args.net_weight??args.tons),loaded=n(args.loaded_tons??args.net_weight??args.tons),gross=n(args.gross_weight);
    const pricePerTon=n(args.price_per_ton);
    let pricePerTrip=0;
    if(mode==="ton"&&pricePerTon<=0)throw new Error("Informe o preço por tonelada.");
    if(mode!=="ton"){pricePerTrip=await globalPrice(mode);if(pricePerTrip<=0)throw new Error(`Configure o preço de ${labelMode(mode)} antes de lançar.`);}
    await sql`
      insert into trips(id,code,date,client,origin,destination,driver_id,fleet_id,loaded_tons,gross_weight,net_weight,freight_mode,price_per_ton,price_per_trip,km_start,km_end,diesel_liters,diesel_price)
      values(${id},${code},${date},${String(args.client??"")},${String(args.origin??"")},${String(args.destination??"")},${driver.id},${fleet.id},${loaded},${gross},${net},${mode},${pricePerTon},${pricePerTrip},${n(args.km_start)},${n(args.km_end)},0,0)
      on conflict(id) do update set code=excluded.code,date=excluded.date,client=excluded.client,origin=excluded.origin,destination=excluded.destination,driver_id=excluded.driver_id,fleet_id=excluded.fleet_id,loaded_tons=excluded.loaded_tons,gross_weight=excluded.gross_weight,net_weight=excluded.net_weight,freight_mode=excluded.freight_mode,price_per_ton=excluded.price_per_ton,price_per_trip=excluded.price_per_trip,km_start=excluded.km_start,km_end=excluded.km_end
    `;
    return{ok:true,entity:"trip",id,code,date,driver:driver.name,fleet:fleet.name,freight:mode==="ton"?net*pricePerTon:pricePerTrip};
  }

  if(op==="report_update"){
    const ticket=String(args.ticket??"").trim();
    if(!ticket)throw new Error("Informe o ticket do lançamento pendente.");
    const rows=await sql<Row>`select * from reports where ticket=${ticket} and status='pendente' limit 1`;
    const report=rows[0];
    if(!report)throw new Error("Lançamento pendente não encontrado.");

    const driverQ=String(args.driver??"").trim();
    const fleetQ=String(args.fleet??"").trim();
    const modeRaw=args.freight_mode==null?"":String(args.freight_mode);
    if(driverQ){const driver=resolveUniqueDriver(s,driverQ);await sql`update reports set driver_id=${driver.id} where id=${String(report.id)}`;}
    if(fleetQ){const fleet=resolveUniqueFleet(s,fleetQ);await sql`update reports set fleet_id=${fleet.id} where id=${String(report.id)}`;}
    if(modeRaw){
      if(!["ton","trip","cegonha","caixinha"].includes(modeRaw))throw new Error("Modalidade inválida.");
      await sql`update reports set freight_mode=${modeRaw} where id=${String(report.id)}`;
    }
    if(args.tons!=null)await sql`update reports set tons=${n(args.tons)} where id=${String(report.id)}`;
    if(args.km!=null)await sql`update reports set km=${n(args.km)} where id=${String(report.id)}`;
    if(args.loading_date!=null){
      const date=iso(args.loading_date);if(!date)throw new Error("Data inválida.");
      await sql`update reports set loading_date=${date} where id=${String(report.id)}`;
    }
    if(args.daily_value!=null)await sql`update reports set daily_value=${n(args.daily_value)} where id=${String(report.id)}`;

    const updated=await sql<Row>`select id,ticket,status,driver_id,fleet_id,freight_mode,tons,daily_value,km,loading_date from reports where id=${String(report.id)} limit 1`;
    return{ok:true,entity:"report",action:"updated",...updated[0]};
  }

  if(op==="report_accept"){
    const ticket=String(args.ticket??"").trim();
    if(!ticket)throw new Error("Informe o ticket a aceitar.");
    const rows=await sql<Row>`select * from reports where ticket=${ticket} and status='pendente' limit 1`;
    const report=rows[0];
    if(!report)throw new Error("Lançamento pendente não encontrado.");
    const mode=String(report.freight_mode??"");
    if(!["ton","trip","cegonha","caixinha"].includes(mode))throw new Error("O lançamento precisa de modo de frete antes de ser aceito.");
    let pricePerTrip=0;
    if(mode==="trip")pricePerTrip=n(report.daily_value);
    else if(mode!=="ton")pricePerTrip=await globalPrice(mode);
    if(mode!=="ton"&&pricePerTrip<=0)throw new Error("O preço desse modo de frete não está configurado.");
    const tripId=newId("trip"),code=await nextTicketCode(),date=iso(report.loading_date)||todayBR();
    const fleetId=String(report.fleet_id),kmEnd=n(report.km);
    const prev=await sql<Row>`select km_end from trips where fleet_id=${fleetId} and km_end<=${kmEnd} order by km_end desc limit 1`;
    const kmStart=n(prev[0]?.km_end),tons=n(report.tons);
    await sql`
      insert into trips(id,code,date,client,origin,destination,driver_id,fleet_id,loaded_tons,gross_weight,net_weight,freight_mode,price_per_ton,price_per_trip,km_start,km_end,diesel_liters,diesel_price)
      values(${tripId},${code},${date},'','','',${String(report.driver_id)},${fleetId},${tons},0,${tons},${mode},0,${pricePerTrip},${kmStart},${kmEnd},0,0)
    `;
    await sql`update reports set status='aceito',trip_id=${tripId},ticket=${code} where id=${String(report.id)}`;
    return{ok:true,entity:"report",action:"accepted",ticket:code,tripId};
  }

  if(op==="report_reject"){
    const ticket=String(args.ticket??"").trim();
    if(!ticket)throw new Error("Informe o ticket a rejeitar.");
    const rows=await sql<Row>`update reports set status='recusado' where ticket=${ticket} and status='pendente' returning ticket`;
    if(!rows[0])throw new Error("Lançamento pendente não encontrado.");
    return{ok:true,entity:"report",action:"rejected",ticket:rows[0].ticket};
  }

  const destructive=["delete_trip","delete_fueling","delete_expense","delete_report","delete_driver","delete_fleet","delete_all_trips"];
  if(destructive.includes(op)){
    if(!args.confirmed)throw new Error("CONFIRMATION_REQUIRED");
    if(op==="delete_all_trips"){
      const count=await sql<{count:number}>`select count(*)::int as count from trips`;
      await sql`update reports set trip_id=null,status='pendente' where trip_id is not null`;
      await sql`delete from trips`;
      return{ok:true,deleted:Number(count[0]?.count??0)};
    }
    const id=String(args.id??"").trim();
    if(!id)throw new Error("Informe o identificador do registro.");
    if(op==="delete_trip"){await sql`update reports set trip_id=null,status='pendente' where trip_id=${id}`;await sql`delete from trips where id=${id}`;}
    if(op==="delete_fueling")await sql`delete from fuelings where id=${id}`;
    if(op==="delete_expense")await sql`delete from expenses where id=${id}`;
    if(op==="delete_report")await sql`delete from reports where id=${id}`;
    if(op==="delete_driver"){
      const linked=await sql<{count:number}>`select ((select count(*) from trips where driver_id=${id})+(select count(*) from reports where driver_id=${id})+(select count(*) from fuelings where driver_id=${id}))::int as count`;
      if(Number(linked[0]?.count??0)>0)throw new Error("Este motorista possui histórico. Altere o status para inativo em vez de excluir.");
      await sql`delete from drivers where id=${id}`;
    }
    if(op==="delete_fleet"){
      const linked=await sql<{count:number}>`select ((select count(*) from trips where fleet_id=${id})+(select count(*) from reports where fleet_id=${id})+(select count(*) from fuelings where fleet_id=${id})+(select count(*) from expenses where fleet_id=${id}))::int as count`;
      if(Number(linked[0]?.count??0)>0)throw new Error("Este conjunto possui histórico. Altere o status para inativo em vez de excluir.");
      await sql`delete from fleets where id=${id}`;
    }
    return{ok:true,action:op,id};
  }

  throw new Error("Ação ainda não implementada.");
}

const queryTool = {
  type:"function",name:"query_trans_salomao",
  description:"Consulta dados reais do Trans Israel, incluindo IDs e campos necessários para editar registros. Use para planejar, localizar, conferir e verificar ações.",
  strict:true,
  parameters:{type:"object",properties:{
    operation:{type:"string",enum:["driver_overview","fleet_overview","fleet_history","drivers","fleets","trips","fuelings","expenses","pending","reports","financial_by_driver","freight_prices","system_summary","management_users"]},
    driver:{type:["string","null"]},fleet:{type:["string","null"]},date_from:{type:["string","null"]},date_to:{type:["string","null"]},limit:{type:"number",minimum:1,maximum:100}
  },required:["operation","driver","fleet","date_from","date_to","limit"],additionalProperties:false}
};

const driverTool = {
  type:"function",name:"save_driver",
  description:"Cria ou edita um motorista. Se o nome puder apontar para mais de um cadastro, não escolha por aproximação: consulte e peça o nome completo.",
  strict:true,
  parameters:{type:"object",properties:{
    id:{type:["string","null"]},name:{type:"string"},phone:{type:["string","null"]},category:{type:["string","null"]},
    status:{type:["string","null"],enum:["ativo","inativo",null]},commission_pct:{type:["number","null"],minimum:0,maximum:100}
  },required:["id","name","phone","category","status","commission_pct"],additionalProperties:false}
};

const fleetTool = {
  type:"function",name:"save_fleet",
  description:"Cria ou edita um conjunto/carreta. Para editar, identifique o conjunto sem ambiguidade.",
  strict:true,
  parameters:{type:"object",properties:{
    id:{type:["string","null"]},name:{type:"string"},tractor_plate:{type:["string","null"]},trailer_plate:{type:["string","null"]},
    model:{type:["string","null"]},status:{type:["string","null"],enum:["ativo","inativo",null]}
  },required:["id","name","tractor_plate","trailer_plate","model","status"],additionalProperties:false}
};

const tripTool = {
  type:"function",name:"save_trip",
  description:"Cria ou edita uma viagem. freight_mode: ton=por tonelada, trip=diária, cegonha=cegonha, caixinha=caixinha. Nunca adivinhe motorista, conjunto ou modalidade.",
  strict:true,
  parameters:{type:"object",properties:{
    id:{type:["string","null"]},driver:{type:"string"},fleet:{type:"string"},date:{type:["string","null"]},
    client:{type:["string","null"]},origin:{type:["string","null"]},destination:{type:["string","null"]},
    net_weight:{type:["number","null"],minimum:0},gross_weight:{type:["number","null"],minimum:0},loaded_tons:{type:["number","null"],minimum:0},
    freight_mode:{type:"string",enum:["ton","trip","cegonha","caixinha"]},price_per_ton:{type:["number","null"],minimum:0},
    km_start:{type:["number","null"],minimum:0},km_end:{type:["number","null"],minimum:0}
  },required:["id","driver","fleet","date","client","origin","destination","net_weight","gross_weight","loaded_tons","freight_mode","price_per_ton","km_start","km_end"],additionalProperties:false}
};

const fuelingTool = {
  type:"function",name:"save_fueling",
  description:"Cria ou edita um abastecimento. Exige conjunto, litros e preço por litro; não invente valores ausentes.",
  strict:true,
  parameters:{type:"object",properties:{
    id:{type:["string","null"]},driver:{type:["string","null"]},fleet:{type:"string"},date:{type:["string","null"]},
    station:{type:["string","null"]},km:{type:["number","null"],minimum:0},liters:{type:"number",exclusiveMinimum:0},
    price_per_liter:{type:"number",exclusiveMinimum:0},notes:{type:["string","null"]}
  },required:["id","driver","fleet","date","station","km","liters","price_per_liter","notes"],additionalProperties:false}
};

const expenseTool = {
  type:"function",name:"save_expense",
  description:"Cria ou edita despesa ou adiantamento. Para adiantamento use category='Adiantamento' e informe o motorista. Para outra despesa informe o conjunto.",
  strict:true,
  parameters:{type:"object",properties:{
    id:{type:["string","null"]},driver:{type:["string","null"]},fleet:{type:["string","null"]},date:{type:["string","null"]},
    category:{type:"string"},description:{type:"string"},amount:{type:"number",exclusiveMinimum:0},
    asset_type:{type:["string","null"],enum:["tractor","trailer",null]},notes:{type:["string","null"]}
  },required:["id","driver","fleet","date","category","description","amount","asset_type","notes"],additionalProperties:false}
};

const pricesTool = {
  type:"function",name:"update_freight_prices",
  description:"Atualiza os preços globais de Diária, Cegonha e Caixinha. Só use quando os três valores estiverem claros.",
  strict:true,
  parameters:{type:"object",properties:{
    trip:{type:"number",exclusiveMinimum:0},cegonha:{type:"number",exclusiveMinimum:0},caixinha:{type:"number",exclusiveMinimum:0}
  },required:["trip","cegonha","caixinha"],additionalProperties:false}
};

const userTool = {
  type:"function",name:"manage_management_user",
  description:"Cria/edita ou desativa login administrativo. Nunca exponha a senha na resposta.",
  strict:true,
  parameters:{type:"object",properties:{
    action:{type:"string",enum:["upsert","disable"]},username:{type:"string"},password:{type:["string","null"]},role:{type:["string","null"]}
  },required:["action","username","password","role"],additionalProperties:false}
};

const reportTool = {
  type:"function",name:"process_pending_report",
  description:"Aceita ou rejeita um lançamento pendente da Caixa pelo ticket. Se o ticket estiver incerto, consulte antes.",
  strict:true,
  parameters:{type:"object",properties:{
    action:{type:"string",enum:["accept","reject"]},ticket:{type:"string"}
  },required:["action","ticket"],additionalProperties:false}
};

const reportUpdateTool = {
  type:"function",name:"update_pending_report",
  description:"Atualiza dados de um lançamento pendente da Caixa antes de aceitar. Use para definir/corrigir motorista, conjunto, modalidade, toneladas, km, data ou valor da diária.",
  strict:true,
  parameters:{type:"object",properties:{
    ticket:{type:"string"},
    driver:{type:["string","null"]},fleet:{type:["string","null"]},
    freight_mode:{type:["string","null"],enum:["ton","trip","cegonha","caixinha",null]},
    tons:{type:["number","null"],minimum:0},km:{type:["number","null"],minimum:0},
    loading_date:{type:["string","null"]},daily_value:{type:["number","null"],minimum:0}
  },required:["ticket","driver","fleet","freight_mode","tons","km","loading_date","daily_value"],additionalProperties:false}
};

const bulkReportTool = {
  type:"function",name:"process_pending_reports_bulk",
  description:"Aceita ou rejeita vários lançamentos pendentes da Caixa em sequência. Use quando o usuário pedir ação em lote ou em todos os tickets explicitamente listados.",
  strict:true,
  parameters:{type:"object",properties:{
    action:{type:"string",enum:["accept","reject"]},
    tickets:{type:"array",items:{type:"string"},minItems:1,maxItems:100}
  },required:["action","tickets"],additionalProperties:false}
};

const deleteTool = {
  type:"function",name:"delete_trans_salomao_record",
  description:"Exclui um registro ou todas as viagens. Só pode ser usado após confirmação explícita do usuário no pedido atual.",
  strict:true,
  parameters:{type:"object",properties:{
    entity:{type:"string",enum:["trip","fueling","expense","report","driver","fleet","all_trips"]},
    id:{type:["string","null"]},confirmed:{type:"boolean"}
  },required:["entity","id","confirmed"],additionalProperties:false}
};

const assistantTools=[queryTool,driverTool,fleetTool,tripTool,fuelingTool,expenseTool,pricesTool,userTool,reportTool,reportUpdateTool,bulkReportTool,deleteTool];

async function verifyMutation(operation:string,result:Row){
  const sql=await getSql();
  if(operation==="driver_upsert"&&result.id){
    const rows=await sql<Row>`select id,name,phone,category,status,commission_pct from drivers where id=${String(result.id)} limit 1`;
    return{verified:!!rows[0],record:rows[0]??null};
  }
  if(operation==="fleet_upsert"&&result.id){
    const rows=await sql<Row>`select id,name,tractor_plate,trailer_plate,model,status from fleets where id=${String(result.id)} limit 1`;
    return{verified:!!rows[0],record:rows[0]??null};
  }
  if(operation==="trip_upsert"&&result.id){
    const rows=await sql<Row>`select id,code,date,driver_id,fleet_id,freight_mode,net_weight,price_per_ton,price_per_trip from trips where id=${String(result.id)} limit 1`;
    return{verified:!!rows[0],record:rows[0]??null};
  }
  if(operation==="fueling_upsert"&&result.id){
    const rows=await sql<Row>`select id,date,driver_id,fleet_id,liters,price_per_liter,km,station from fuelings where id=${String(result.id)} limit 1`;
    return{verified:!!rows[0],record:rows[0]??null};
  }
  if(operation==="expense_upsert"&&result.id){
    const rows=await sql<Row>`select id,date,driver_id,fleet_id,category,description,amount,asset_type from expenses where id=${String(result.id)} limit 1`;
    return{verified:!!rows[0],record:rows[0]??null};
  }
  if(operation==="report_update"||operation==="report_accept"||operation==="report_reject"){
    const ticket=String(result.ticket??"");
    const rows=ticket?await sql<Row>`select id,ticket,status,trip_id,freight_mode,driver_id,fleet_id,tons,km from reports where ticket=${ticket} limit 1`:[];
    return{verified:!!rows[0],record:rows[0]??null};
  }
  if(operation==="management_user_upsert"||operation==="management_user_disable"){
    const username=String(result.username??"");
    const rows=username?await sql<Row>`select username,role,status from management_users where lower(username)=lower(${username}) limit 1`:[];
    return{verified:!!rows[0],record:rows[0]??null};
  }
  if(operation==="freight_prices_update"){
    const rows=await sql<Row>`select mode,price from freight_prices where mode in ('trip','cegonha','caixinha') order by mode`;
    return{verified:rows.length>=3,record:rows};
  }
  if(operation.startsWith("delete_")){
    return{verified:true,record:null};
  }
  return{verified:true,record:null};
}

async function mutateVerified(args:Row,actor:string){
  const operation=String(args.operation??"");
  const result:any=await mutateSystem(args,actor);
  const verification=await verifyMutation(operation,result);
  return{...result,verification};
}

async function executeAssistantTool(name:string,args:Row,actor:string,userMessage:string){
  if(name==="query_trans_salomao")return querySystem(args);
  if(name==="save_driver")return mutateVerified({operation:"driver_upsert",...args},actor);
  if(name==="save_fleet")return mutateVerified({operation:"fleet_upsert",...args},actor);
  if(name==="save_trip")return mutateVerified({operation:"trip_upsert",...args},actor);
  if(name==="save_fueling")return mutateVerified({operation:"fueling_upsert",...args},actor);
  if(name==="save_expense")return mutateVerified({operation:"expense_upsert",...args},actor);
  if(name==="update_freight_prices")return mutateVerified({operation:"freight_prices_update",...args},actor);
  if(name==="manage_management_user"){
    if(args.action==="disable")return mutateVerified({operation:"management_user_disable",username:args.username},actor);
    return mutateVerified({operation:"management_user_upsert",username:args.username,password:args.password??"",role:args.role??"admin"},actor);
  }
  if(name==="process_pending_report"){
    return mutateVerified({operation:args.action==="accept"?"report_accept":"report_reject",ticket:args.ticket},actor);
  }
  if(name==="update_pending_report"){
    return mutateVerified({operation:"report_update",...args},actor);
  }
  if(name==="process_pending_reports_bulk"){
    const results:any[]=[];
    for(const ticket of Array.isArray(args.tickets)?args.tickets:[]){
      try{
        results.push(await mutateVerified({operation:args.action==="accept"?"report_accept":"report_reject",ticket},actor));
      }catch(error:any){
        results.push({ok:false,ticket,error:String(error?.message||error)});
      }
    }
    return{ok:results.every((x)=>x.ok!==false),action:args.action,total:results.length,results};
  }
  if(name==="delete_trans_salomao_record"){
    if(!explicitlyConfirmed(norm(userMessage)))throw new Error("CONFIRMATION_REQUIRED");
    const map:Record<string,string>={trip:"delete_trip",fueling:"delete_fueling",expense:"delete_expense",report:"delete_report",driver:"delete_driver",fleet:"delete_fleet",all_trips:"delete_all_trips"};
    const operation=map[String(args.entity??"")];
    if(!operation)throw new Error("Tipo de exclusão inválido.");
    return mutateVerified({operation,id:args.id??"",confirmed:true},actor);
  }
  throw new Error("Ferramenta não autorizada.");
}

async function gptAnswer(message:string,history:Turn[],key:string,actor:string){
  const prior=history.map((x)=>`${x.role==="user"?"Usuário":"Salomão"}: ${x.role==="user"?redactSecrets(x.content):x.content}`).join("\n")||"(sem histórico)";
  const instructions=`Você é Israel IA, agente operacional autônomo da transportadora Trans Israel. Fale em português do Brasil, natural, curto e preciso.

MISSÃO:
- Trate cada mensagem como um OBJETIVO a ser concluído, não como uma única ação.
- Faça internamente um plano de execução, consulte o estado real do sistema, execute quantas ferramentas forem necessárias, confira os resultados e continue até concluir.
- Preserve o contexto da conversa para referências como "ele", "essa viagem", "o mesmo motorista" e "agora lance o abastecimento".
- Não exponha cadeia de raciocínio interna. Na resposta final, informe somente o que fez, resultados e qualquer pendência objetiva.

REGRAS OPERACIONAIS:
1. Dados reais sempre vêm das ferramentas. Nunca invente valores, IDs, nomes, placas, preços, datas ou totais.
2. Antes de alterar um registro existente, consulte o registro quando precisar completar campos ou resolver qual registro é.
3. Depois de cada gravação, use o retorno de verificação. Só diga que concluiu se verification.verified não for false.
4. Você pode encadear consultas e alterações no mesmo pedido. Exemplo: encontrar motorista → encontrar conjunto → lançar viagem → consultar e confirmar que apareceu.
5. Use padrões já definidos pelo sistema quando forem inequívocos: data ausente pode ser hoje; preços de Diária/Cegonha/Caixinha vêm da configuração global. Não invente modalidade, peso, litros, preço por litro, motorista ou conjunto.
6. Se faltar um dado realmente obrigatório e ele não puder ser obtido do sistema nem do histórico, faça UMA pergunta objetiva. Não peça dados opcionais.
7. Se uma ferramenta der erro, tente diagnosticar consultando o sistema e corrigir o plano quando houver uma solução segura. Não repita a mesma ação cegamente.
8. Para Caixa, você pode corrigir um pendente com update_pending_report e depois aceitar/rejeitar. Para vários tickets, use process_pending_reports_bulk quando apropriado.
9. Para despesas: categoria "Adiantamento" pertence ao motorista; "Mecânica" e demais despesas operacionais normalmente pertencem ao conjunto.
10. Nunca escolha entre motoristas ou conjuntos ambíguos. Consulte candidatos e peça identificação somente se ainda houver mais de uma possibilidade real.
11. Exclusões continuam exigindo confirmação explícita NO PEDIDO ATUAL. Não use confirmação antiga do histórico.
12. Nunca revele, repita ou registre senhas ou segredos na resposta.
13. Se o usuário pedir várias ações, execute todas as que forem independentes e seguras; não pare depois da primeira.
14. Ao final, faça uma resposta curta com: o que foi executado, o que foi verificado e, se houver, o único item que ainda precisa de informação.

Usuário autenticado: ${actor}. Hoje: ${todayBR()}.`;
  const common={model:modelName(),reasoning:{effort:"high"},instructions,tools:assistantTools,tool_choice:"auto",parallel_tool_calls:false,max_output_tokens:4000};
  let response=await openAI(key,{...common,input:`Histórico:\n${prior}\n\nPedido atual:\n${message}`});
  for(let i=0;i<24;i++){
    const calls=(Array.isArray(response.output)?response.output:[]).filter((x:any)=>x?.type==="function_call");
    if(!calls.length){const text=outputText(response);if(text)return text;throw new Error("Resposta vazia");}
    const call=calls[0];
    let args:Row={};
    try{args=JSON.parse(call.arguments||"{}");}catch{throw new Error("A OpenAI retornou argumentos inválidos.");}
    let result:any;
    try{
      result=await executeAssistantTool(call.name,args,actor,message);
    }catch(error:any){
      result={ok:false,error:String(error?.message||error)};
    }
    response=await openAI(key,{...common,previous_response_id:response.id,input:[{type:"function_call_output",call_id:call.call_id,output:JSON.stringify(result)}]});
  }
  throw new Error("Limite de ferramentas excedido");
}
async function openAI(key:string,payload:Row){
  const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{Authorization:`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const data=await r.json();if(!r.ok)throw new Error(`OpenAI ${r.status}: ${JSON.stringify(data).slice(0,800)}`);return data as any;
}
function outputText(r:any){if(typeof r?.output_text==="string"&&r.output_text.trim())return r.output_text.trim();const p:string[]=[];for(const x of Array.isArray(r?.output)?r.output:[])if(x?.type==="message")for(const c of Array.isArray(x.content)?x.content:[])if(c?.type==="output_text"&&typeof c.text==="string")p.push(c.text);return p.join("\n").trim();}

function parseLoginCommand(message:string){
  const t=norm(message);
  if(!hasAny(t,["login","usuario","acesso","administrador","operador"]))return null;
  const raw=message.trim();
  const userMatch=raw.match(/(?:login|usu[aá]rio|administrador|operador)\s+([A-Za-zÀ-ÿ0-9._-]+)/i) || raw.match(/(?:nome)\s+([A-Za-zÀ-ÿ0-9._-]+)/i);
  const passMatch=raw.match(/senha\s*(?:é|e|:|=)?\s*([^\s,;]+)/i);
  return{t,username:userMatch?.[1]?.trim()||"",password:passMatch?.[1]||""};
}

async function highPriorityAction(message:string,history:Turn[],actor:string){
  const text=norm(message);
  if(!isWriteIntent(text))return null;

  const login=parseLoginCommand(message);
  if(login){
    if(hasAny(text,["listar","mostrar","quais","ver logins","usuarios cadastrados"])) {
      const r:any=await querySystem({operation:"management_users",driver:null,fleet:null,date_from:null,date_to:null,limit:100});
      return{answer:r.rows.length?`Logins cadastrados: ${r.rows.map((x:any)=>x.username+" ("+x.status+")").join(", ")}.`:"Não há logins cadastrados."};
    }
    if(hasAny(text,["desativar","desative","bloquear","bloqueie"])){
      if(!login.username)return{answer:"Qual login você quer desativar?"};
      try{const r:any=await mutateSystem({operation:"management_user_disable",username:login.username},actor);return{answer:`Login ${r.username} desativado.`};}
      catch(e:any){return{answer:String(e?.message||e)};}
    }
    if(hasAny(text,["adicionar","adicione","criar","crie","cadastrar","cadastre","alterar","altere","mudar","mude","editar","edite"])){
      if(!login.username&&!login.password)return{answer:"Para criar o acesso, diga o nome do login e a senha. Exemplo: “adicionar login João senha UmaSenhaForte2026!”."};
      if(!login.username)return{answer:"Qual será o nome do login?"};
      if(!login.password)return{answer:`Qual senha devo definir para o login ${login.username}?`};
      try{
        const r:any=await mutateSystem({operation:"management_user_upsert",username:login.username,password:login.password,role:"admin"},actor);
        return{answer:r.action==="created"?`Login ${r.username} criado como administrador.`:`Login ${r.username} atualizado. A senha foi alterada e não será exibida.`};
      }catch(e:any){return{answer:String(e?.message||e)};}
    }
  }

  // Em modo local, para outras ações não arriscar uma operação errada: explicar o que falta.
  if(hasAny(text,["motorista"])&&hasAny(text,["adicionar","criar","cadastrar"])){
    return{answer:"Posso cadastrar o motorista. Informe pelo menos nome, categoria da CNH e comissão; telefone é opcional."};
  }
  if(hasAny(text,["conjunto","carreta"])&&hasAny(text,["adicionar","criar","cadastrar"])){
    return{answer:"Posso cadastrar o conjunto. Informe nome do conjunto, placa do cavalo e placa da carreta."};
  }
  if(hasAny(text,["abastecimento","abastecer"])&&hasAny(text,["adicionar","registrar","lancar"])){
    return{answer:"Posso registrar o abastecimento. Informe conjunto, litros e preço por litro; motorista, posto, km e data podem ser incluídos."};
  }
  if(hasAny(text,["viagem"])&&hasAny(text,["adicionar","registrar","lancar","criar"])){
    return{answer:"Posso lançar a viagem. Informe motorista, conjunto, modo de frete e os valores necessários (toneladas/preço por tonelada ou modo fixo)."};
  }
  if(isDestructive(text)&&!explicitlyConfirmed(text))return{answer:"Essa é uma ação destrutiva. Repita o pedido incluindo “confirmo” para eu executar."};
  return{answer:"Entendi que você quer executar uma ação no sistema. Com a IA avançada conectada eu consigo extrair os campos do seu pedido e chamar a função correta; no modo local, diga a ação e os dados principais de forma explícita para eu não alterar o registro errado."};
}

function mentionedDriver(s:Snapshot,text:string){
  const t=norm(text);
  if(!t)return null;
  const exact=s.drivers
    .filter((d)=>norm(d.name).length>=3&&t.includes(norm(d.name)))
    .sort((a,b)=>norm(b.name).length-norm(a.name).length);
  if(exact.length)return exact[0];

  const words=new Set(t.split(/[^a-z0-9]+/).filter((x)=>x.length>=4));
  const candidates=s.drivers.filter((d)=>{
    const tokens=norm(d.name).split(/[^a-z0-9]+/).filter((x)=>x.length>=4);
    return tokens.some((x)=>words.has(x));
  });
  return candidates.length===1?candidates[0]:null;
}

function mentionedFleet(s:Snapshot,text:string){
  const t=norm(text);
  if(!t)return null;
  const compact=(v:unknown)=>norm(v).replace(/[^a-z0-9]/g,"");
  const tc=compact(text);
  const candidates=s.fleets.filter((f)=>{
    const name=norm(f.name);
    const tractor=compact(f.tractor_plate);
    const trailer=compact(f.trailer_plate);
    return (name.length>=4&&t.includes(name)) ||
      (tractor.length>=5&&tc.includes(tractor)) ||
      (trailer.length>=5&&tc.includes(trailer));
  });
  return candidates.length===1?candidates[0]:null;
}

function localPeriod(text:string){
  const t=norm(text), today=todayBR();
  if(t.includes("hoje"))return{from:today,to:today,label:" hoje"};
  if(t.includes("este mes")||t.includes("esse mes")||t.includes("mes atual")){
    return{from:`${today.slice(0,7)}-01`,to:today,label:" neste mês"};
  }
  return{from:null as string|null,to:null as string|null,label:""};
}

async function localAnswer(message:string,history:Turn[]){
  const s=await snapshot(),text=norm(message);
  const userHistory=history.filter((x)=>x.role==="user").slice(-5).map((x)=>x.content).join(" ");
  const needsContext=hasAny(text,["ele","dele","dela","esse motorista","essa motorista","esse conjunto","desse motorista","desse conjunto"]);
  const contextText=needsContext?`${message} ${userHistory}`:message;
  const d=mentionedDriver(s,contextText),f=mentionedFleet(s,contextText);
  const period=localPeriod(text);
  const qbase={date_from:period.from,date_to:period.to,limit:50};

  if(hasAny(text,["login","usuario","acesso","administrador","operador"])){
    const r:any=await querySystem({operation:"management_users",driver:null,fleet:null,...qbase});
    return{answer:r.rows.length?`Há ${r.rows.length} login(s) de gerenciamento: ${r.rows.map((x:any)=>x.username+" ("+x.status+")").join(", ")}.`:"Não há logins cadastrados."};
  }

  if((text.includes("quantos")||text.includes("quantas"))&&hasAny(text,["motorista","motoristas"])){
    const active=s.drivers.filter((x)=>x.status==="ativo");
    return{answer:`Há ${active.length} motorista(s) ativo(s) cadastrado(s).`,data:{rows:active.map((x)=>({name:x.name,status:x.status}))}};
  }

  if(hasAny(text,["quais motoristas","listar motoristas","lista de motoristas","mostrar motoristas","motoristas cadastrados"])){
    const rows=s.drivers.map((x)=>({name:x.name,status:x.status,category:x.category,commissionPct:n(x.commission_pct)}));
    return{answer:rows.length?`Motoristas cadastrados: ${rows.map((x)=>x.name+" ("+x.status+")").join(", ")}.`:"Não há motoristas cadastrados.",data:{rows}};
  }

  if((text.includes("quantos")||text.includes("quantas"))&&hasAny(text,["conjunto","conjuntos","carreta","carretas"])){
    const active=s.fleets.filter((x)=>x.status==="ativo");
    return{answer:`Há ${active.length} conjunto(s) ativo(s) cadastrado(s).`,data:{rows:active.map((x)=>({name:x.name,status:x.status}))}};
  }

  if(hasAny(text,["quais conjuntos","listar conjuntos","lista de conjuntos","mostrar conjuntos","carretas cadastradas","conjuntos cadastrados"])){
    const rows=s.fleets.map((x)=>({name:x.name,tractorPlate:x.tractor_plate,trailerPlate:x.trailer_plate,status:x.status}));
    return{answer:rows.length?`Conjuntos cadastrados: ${rows.map((x)=>x.name+" — cavalo "+x.tractorPlate+", carreta "+x.trailerPlate).join("; ")}.`:"Não há conjuntos cadastrados.",data:{rows}};
  }

  if(text.includes("abastec")||text.includes("diesel")||text.includes("combustivel")){
    const r:any=await querySystem({operation:"fuelings",driver:d?.name||null,fleet:f?.name||null,...qbase});
    return{answer:`Encontrei ${r.count} abastecimento(s)${d?" de "+d.name:""}${f?" do conjunto "+f.name:""}${period.label}, totalizando ${brl(r.totalCost)}.`,data:r};
  }

  if(text.includes("despesa")||text.includes("gasto")){
    const r:any=await querySystem({operation:"expenses",driver:d?.name||null,fleet:f?.name||null,...qbase});
    return{answer:`Encontrei ${r.count} despesa(s)${d?" relacionadas a "+d.name:""}${f?" do conjunto "+f.name:""}${period.label}, somando ${brl(r.total)}.`,data:r};
  }

  if(text.includes("pendente")||text.includes("caixa")||text.includes("lancamento")){
    const r:any=await querySystem({operation:"pending",driver:d?.name||null,fleet:f?.name||null,...qbase});
    return{answer:`Há ${r.count} lançamento(s) pendente(s)${d?" de "+d.name:""}${f?" do conjunto "+f.name:""}.`,data:r};
  }

  if((text.includes("fatur")||text.includes("comissao"))&&d){
    const r:any=await querySystem({operation:"driver_overview",driver:d.name,fleet:null,...qbase});
    return{answer:`${d.name}${period.label} possui ${r.summary.tripCount} viagem(ns) e ${brl(r.summary.freight)} de faturamento. Comissão: ${brl(r.summary.commission)}; após comissão: ${brl(r.summary.afterCommission)}.`,data:r};
  }

  if(hasAny(text,["faturamento por motorista","faturamento dos motoristas","comissao por motorista","comissoes por motorista"]) ||
     ((text.includes("fatur")||text.includes("comissao"))&&!d)){
    const r:any=await querySystem({operation:"financial_by_driver",driver:null,fleet:null,...qbase});
    return{answer:`O faturamento total${period.label} é ${brl(r.totals.freight)}, com ${brl(r.totals.commission)} em comissões e ${r.totals.trips} viagem(ns).`,data:r};
  }

  if(text.includes("viagem")||text.includes("frete")){
    const r:any=await querySystem({operation:"trips",driver:d?.name||null,fleet:f?.name||null,...qbase});
    if(hasAny(text,["ultima viagem","última viagem","mais recente"])&&r.rows?.length){
      const x=r.rows[0];
      return{answer:`A viagem mais recente é ${x.code||"sem código"}, em ${x.date||"data não informada"}, ${x.driver} / ${x.fleet}, com frete de ${brl(n(x.freight))}.`,data:x};
    }
    return{answer:`Encontrei ${r.count} viagem(ns)${d?" de "+d.name:""}${f?" do conjunto "+f.name:""}${period.label}, totalizando ${brl(r.totalFreight)} de frete.`,data:r};
  }

  if(f){
    const r:any=await querySystem({operation:"fleet_overview",driver:null,fleet:f.name,...qbase});
    if(!r.found)return{answer:"Não consegui identificar esse conjunto com segurança."};
    return{answer:`${r.fleet.name}: cavalo ${r.fleet.tractorPlate}, carreta ${r.fleet.trailerPlate}, modelo ${r.fleet.model||"não informado"}. Possui ${r.summary.tripCount} viagem(ns)${period.label} e ${brl(r.summary.freight)} de faturamento.`,data:r};
  }

  if(d){
    const r:any=await querySystem({operation:"driver_overview",driver:d.name,fleet:null,...qbase});
    if(!r.found)return{answer:"Não consegui identificar o motorista com segurança."};
    return{answer:`${r.driver.name} — ${r.driver.status}, categoria ${r.driver.category||"não informada"}, telefone ${r.driver.phone||"não informado"}, comissão ${dec(r.driver.commissionPct*100,0)}%. Possui ${r.summary.tripCount} viagem(ns)${period.label}, ${dec(r.summary.netTons,3)} t líquidas, ${dec(r.summary.km,0)} km e ${brl(r.summary.freight)} de faturamento. Comissão calculada: ${brl(r.summary.commission)}. Há ${r.summary.pendingReports} lançamento(s) pendente(s).`,data:r};
  }

  if(text.includes("motorista")){
    return{answer:"Diga o nome do motorista para eu consultar os dados corretos. Se quiser a lista, diga “listar motoristas”."};
  }

  if(hasAny(text,["conjunto","carreta","placa"])){
    return{answer:"Diga o nome do conjunto ou a placa para eu consultar o registro correto. Se quiser a lista, diga “listar conjuntos”."};
  }

  return{answer:"Não tenho segurança para responder essa pergunta pelo roteador local. A IA avançada ainda não está conectada neste servidor; prefiro não inventar uma resposta. Para dados do Trans Israel, diga claramente o que deseja consultar, por exemplo: “faturamento hoje”, “listar motoristas”, “viagens do Clóvis” ou “abastecimentos do conjunto X”."};
}
