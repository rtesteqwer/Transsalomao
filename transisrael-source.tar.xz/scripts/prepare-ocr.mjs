import fs from 'node:fs';
import path from 'node:path';
const out='public/ocr';fs.mkdirSync(out+'/core',{recursive:true});fs.mkdirSync(out+'/lang',{recursive:true});
fs.copyFileSync('node_modules/tesseract.js/dist/worker.min.js',out+'/worker.min.js');
for(const name of fs.readdirSync('node_modules/tesseract.js-core'))if(/^tesseract-core.*\.(wasm|js)$/.test(name))fs.copyFileSync('node_modules/tesseract.js-core/'+name,out+'/core/'+name);
fs.copyFileSync('node_modules/@tesseract.js-data/por/4.0.0/por.traineddata.gz',out+'/lang/por.traineddata.gz');
