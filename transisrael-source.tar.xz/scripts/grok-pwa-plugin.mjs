import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const VIRTUAL_ID = 'virtual:grok-og-identity';
const RESOLVED_ID = '\0virtual:grok-og-identity';

function readSite(root) {
  try {
    const raw = readFileSync(join(root, 'src/lib/og/site.json'), 'utf8');
    return JSON.parse(raw);
  } catch {
    return { title: 'Trans Israel', color: '0C0D0F' };
  }
}

export function grokPwaPlugin() {
  let root = process.cwd();
  return {
    name: 'grok-pwa',
    enforce: 'pre',
    configResolved(config) {
      root = config.root || root;
    },
    resolveId(id) {
      if (id === VIRTUAL_ID) return RESOLVED_ID;
      return null;
    },
    load(id) {
      if (id !== RESOLVED_ID) return null;
      return `export const grokOgIdentity = ${JSON.stringify({ site: readSite(root) })};`;
    },
  };
}
