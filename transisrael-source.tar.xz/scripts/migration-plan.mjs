/**
 * Build an ordered list of unapplied top-level SQL migrations.
 * Accepts either filenames from fs.readdir() or Vite glob paths.
 */
export function pendingMigrations(entries, applied = []) {
  const done = new Set(applied);
  return entries
    .filter((entry) => typeof entry === "string" && entry.endsWith(".sql"))
    .map((path) => ({
      path,
      name: path.split("/").filter(Boolean).at(-1),
    }))
    .filter((item) => item.name && !done.has(item.name))
    .sort((a, b) => a.name.localeCompare(b.name));
}


export function isMigrationFile(entry) {
  return typeof entry === "string" && entry.endsWith(".sql");
}
