// No inherited group bindings.
