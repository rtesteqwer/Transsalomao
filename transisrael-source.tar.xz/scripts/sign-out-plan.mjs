const PREVIEW_TIMEOUT_MS = 1500;
const DEPLOYED_TIMEOUT_MS = 10000;

function withTimeout(promise, ms) {
  return Promise.race([
    Promise.resolve(promise),
    new Promise((_, reject) => setTimeout(() => reject(new Error('Sign-out timed out')), ms)),
  ]);
}

export async function runPreSignInSignOut({ livePreview, hasBearer, requestSignOut, clearToken }) {
  try {
    await withTimeout(requestSignOut(), livePreview ? PREVIEW_TIMEOUT_MS : DEPLOYED_TIMEOUT_MS);
  } catch (error) {
    if (!livePreview && !hasBearer) throw error;
  } finally {
    clearToken();
  }
}

export async function runSignOut({ livePreview, hasBearer, requestSignOut, clearToken, redirect }) {
  let failure = null;
  try {
    await withTimeout(requestSignOut(), livePreview ? PREVIEW_TIMEOUT_MS : DEPLOYED_TIMEOUT_MS);
  } catch (error) {
    failure = error;
  } finally {
    clearToken();
  }

  if (failure && !livePreview && !hasBearer) throw failure;
  redirect();
}
