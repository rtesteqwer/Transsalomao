const APP_NAME = 'Trans Israel';
const encoder = new TextEncoder();
const decoder = new TextDecoder();

export function acceptsHtml(accept) {
  if (!accept) return true;
  const value = String(accept).toLowerCase();
  return value.includes('text/html') || value.includes('application/xhtml+xml') || value.includes('*/*');
}

export function isDocumentPath(pathname) {
  if (!pathname || pathname === '/') return true;
  if (pathname.endsWith('/')) return true;
  const last = pathname.split('/').pop() || '';
  return !last.includes('.') || last.endsWith('.html');
}

export function isInstallQuery(urlWithQuery) {
  try {
    const url = new URL(urlWithQuery, 'https://local.invalid');
    return url.searchParams.get('install') === '1';
  } catch {
    return false;
  }
}

export function renderInstallPageHtml(template, { host = '', url = '' } = {}) {
  return String(template)
    .replaceAll('{{APP_NAME}}', APP_NAME)
    .replaceAll('{{HOST}}', String(host))
    .replaceAll('{{URL}}', String(url));
}

export function renderWebManifest(host = '') {
  return JSON.stringify({
    name: APP_NAME,
    short_name: 'Trans Israel',
    description: 'Gestão de viagens, abastecimentos e despesas da Trans Israel.',
    id: '/',
    start_url: '/',
    scope: '/',
    display: 'standalone',
    background_color: '#0C0D0F',
    theme_color: '#0C0D0F',
    icons: [
      { src: '/__grok/icon-180.png', sizes: '180x180', type: 'image/png' },
    ],
    ...(host ? { related_applications: [] } : {}),
  });
}

function escapeAttr(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('"', '&quot;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

function headTags({ host = '', site = {} } = {}) {
  const title = site?.title || APP_NAME;
  const colorRaw = site?.color || '0C0D0F';
  const color = String(colorRaw).startsWith('#') ? String(colorRaw) : `#${colorRaw}`;
  const origin = host ? `https://${host}` : '';
  return [
    `<meta name="application-name" content="${escapeAttr(title)}">`,
    `<meta name="theme-color" content="${escapeAttr(color)}">`,
    `<meta property="og:title" content="${escapeAttr(title)}">`,
    `<meta property="og:type" content="website">`,
    origin ? `<meta property="og:url" content="${escapeAttr(origin)}">` : '',
    `<link rel="manifest" href="/__grok/manifest.webmanifest">`,
    `<link rel="apple-touch-icon" href="/__grok/icon-180.png">`,
  ].filter(Boolean).join('');
}

export function createHeadInjector(options = {}) {
  const chunks = [];
  return {
    push(chunk) {
      chunks.push(chunk instanceof Uint8Array ? chunk : encoder.encode(String(chunk)));
      return [];
    },
    flush() {
      let size = 0;
      for (const c of chunks) size += c.byteLength;
      const all = new Uint8Array(size);
      let offset = 0;
      for (const c of chunks) {
        all.set(c, offset);
        offset += c.byteLength;
      }
      let html = decoder.decode(all);
      const tags = headTags(options);
      if (/<\/head>/i.test(html)) html = html.replace(/<\/head>/i, `${tags}</head>`);
      else html = `${tags}${html}`;
      return [encoder.encode(html)];
    },
  };
}
