alter table trips add column if not exists freight_mode text not null default 'ton';
alter table trips add column if not exists price_per_trip double precision not null default 0;

update trips set freight_mode = 'ton' where freight_mode is null or freight_mode = '';
