create table if not exists drivers (
  id text primary key,
  name text not null,
  phone text not null default '',
  category text not null default 'E',
  status text not null default 'ativo',
  commission_pct double precision not null default 0.10
);

create table if not exists fleets (
  id text primary key,
  name text not null,
  tractor_plate text not null,
  trailer_plate text not null,
  model text not null default '',
  status text not null default 'ativo'
);

create table if not exists trips (
  id text primary key,
  code text not null unique,
  date date not null,
  client text not null default '',
  origin text not null default '',
  destination text not null default '',
  driver_id text not null references drivers(id),
  fleet_id text not null references fleets(id),
  loaded_tons double precision not null default 0,
  gross_weight double precision not null default 0,
  net_weight double precision not null default 0,
  price_per_ton double precision not null default 0,
  km_start double precision not null default 0,
  km_end double precision not null default 0,
  diesel_liters double precision not null default 0,
  diesel_price double precision not null default 0
);

create table if not exists reports (
  id text primary key,
  ticket text not null,
  driver_id text not null references drivers(id),
  fleet_id text not null references fleets(id),
  km double precision not null,
  tons double precision not null,
  status text not null default 'pendente',
  created_at timestamptz not null default now(),
  trip_id text references trips(id)
);

create index if not exists trips_date_idx on trips (date desc);
create index if not exists trips_driver_idx on trips (driver_id);
create index if not exists trips_fleet_idx on trips (fleet_id);
create index if not exists reports_status_idx on reports (status, created_at desc);

insert into drivers (id, name, phone, category, status, commission_pct) values
  ('drv_jose', 'José Almeida', '(66) 99912-4401', 'E', 'ativo', 0.12),
  ('drv_marcos', 'Marcos Pereira', '(65) 98821-7730', 'E', 'ativo', 0.10),
  ('drv_ana', 'Ana Souza', '(66) 98400-2218', 'E', 'ativo', 0.08)
on conflict (id) do nothing;

insert into fleets (id, name, tractor_plate, trailer_plate, model, status) values
  ('flt_01', 'Conjunto 01', 'QWE1A23', 'RST2B45', 'Scania R450 + graneleira', 'ativo'),
  ('flt_02', 'Conjunto 02', 'LKM3C67', 'NOP4D89', 'Volvo FH 540 + sider', 'ativo')
on conflict (id) do nothing;

insert into trips (
  id, code, date, client, origin, destination, driver_id, fleet_id,
  loaded_tons, gross_weight, net_weight, price_per_ton,
  km_start, km_end, diesel_liters, diesel_price
) values
  (
    'trip_1', 'TK-1041', current_date - 12, 'Cereal Sul', 'Sorriso/MT', 'Santos/SP',
    'drv_jose', 'flt_01', 32.4, 48.1, 32.4, 185,
    184200, 186310, 412, 6.18
  ),
  (
    'trip_2', 'TK-1042', current_date - 8, 'Agro Norte', 'Lucas do Rio Verde/MT', 'Paranaguá/PR',
    'drv_marcos', 'flt_02', 31.8, 47.6, 31.8, 192,
    221040, 223180, 428, 6.22
  ),
  (
    'trip_3', 'TK-1043', current_date - 5, 'Cereal Sul', 'Nova Mutum/MT', 'Santos/SP',
    'drv_ana', 'flt_01', 33.1, 48.9, 33.1, 178,
    186310, 188420, 405, 6.15
  ),
  (
    'trip_4', 'TK-1044', current_date - 2, 'Grãos Centro', 'Sorriso/MT', 'Rondonópolis/MT',
    'drv_jose', 'flt_01', 32.0, 47.8, 32.0, 95,
    188420, 189110, 148, 6.20
  )
on conflict (id) do nothing;

insert into reports (id, ticket, driver_id, fleet_id, km, tons, status, created_at, trip_id) values
  (
    'rep_1', 'TK-1045', 'drv_marcos', 'flt_02', 223540, 32.6, 'pendente',
    now() - interval '40 minutes', null
  )
on conflict (id) do nothing;
