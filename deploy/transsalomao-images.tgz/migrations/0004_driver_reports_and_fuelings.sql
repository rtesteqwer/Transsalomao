alter table reports add column if not exists freight_mode text not null default 'ton';
update reports set freight_mode = 'ton' where freight_mode is null or freight_mode not in ('ton', 'trip');

create table if not exists fuelings (
  id text primary key,
  date date not null default current_date,
  driver_id text references drivers(id),
  fleet_id text not null references fleets(id),
  station text not null default '',
  km double precision not null default 0,
  liters double precision not null default 0,
  price_per_liter double precision not null default 0,
  notes text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists fuelings_date_idx on fuelings (date desc);
create index if not exists fuelings_driver_idx on fuelings (driver_id);
create index if not exists fuelings_fleet_idx on fuelings (fleet_id);
